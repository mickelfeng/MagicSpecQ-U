/*
    This file is part of qsopcast project.
    Copyright (C) 2005, 2006  Liu Di <liudidi@gmail.com>
    Copyright (C) 2007  Wei Lian <lianwei3@gmail.com>
    Copyright (C) 2009  Ni Hui <shuizhuyuanluo@126.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QApplication>
#include <QSettings>

#include "config.h"

#include "menubar.h"

MenuBar::MenuBar( QWidget* parent ):
        QMenuBar( parent )
{
    ///initialization
    QSettings settings;

    ///menu file
    menu_file = addMenu( tr( "&File" ) );
    QAction* exitAct = new QAction( tr( "&Quit" ), this );
    exitAct->setShortcut( QKeySequence( Qt::CTRL + Qt::Key_Q ) );
    connect( exitAct, SIGNAL( triggered() ), qApp, SLOT( quit() ) );
    menu_file->addAction( exitAct );

    ///menu config
    menu_config = addMenu( tr( "&Setting" ) );
//     menu_config->setCheckable( true );

    ///channel color
//     submenu_color = menu_config->addMenu( tr( "Channel Color" ) );
//     submenu_color->setCheckable( true );
//     submenu_color->addAction( tr( "User" ) );
//     submenu_color->addAction( tr( "Visit" ) );
//     submenu_color->addAction( tr( "Qs" ) );
//     submenu_color->addAction( tr( "Qc" ) );
//     submenu_color->addAction( tr( "Kbps" ) );

//     color_column = settings.readNumEntry( "/qsopcast/ChannelColor", USER_COLUMN );//FIXME:port

//     submenu_color->setItemChecked( color_column, true );//FIXME:port
//     connect( submenu_color, SIGNAL( activated( int ) ), this, SLOT( onSwitchColor( int ) ) );
//     menu_config->insertItem( tr( "Channel Color" ), submenu_color,
//                              CHANNEL_COLOR );
    //show null channel
//     QAction* shownullchannelAct = new QAction( tr( "&Show Null Channel" ), this );
//     shownullchannelAct->setShortcut( QKeySequence( Qt::CTRL + Qt::Key_N ) );
//     connect( shownullchannelAct, SIGNAL( triggered() ), this, SLOT( onNullChannelToggled() ) );
//     menu_config->addAction( shownullchannelAct );
//     menu_config->insertItem( tr( "&Show Null Channel" ), this,
//                              SLOT( onNullChannelToggled() ), Qt::CTRL + Qt::Key_N,
//                              NULL_CHANNEL );
//     menu_config->setItemChecked( NULL_CHANNEL,
//                                  settings.
//                                  readBoolEntry( "/qsopcast/shownullchannels",
//                                                 FALSE ) );//FIXME:port
    //enabel channel sorting
//     QAction* sortchannelAct = new QAction( tr( "&Enable Channel Sorting" ), this );
//     sortchannelAct->setShortcut( QKeySequence( Qt::CTRL + Qt::Key_S ) );
//     connect( sortchannelAct, SIGNAL( triggered() ), this, SLOT( onChannelSortToggled() ) );
//     menu_config->addAction( sortchannelAct );
//     menu_config->insertItem( tr( "&Enable Channel Sorting" ), this,
//                              SLOT( onChannelSortToggled() ), Qt::CTRL + Qt::Key_S,
//                              CHANNEL_SORT );
//     menu_config->setItemChecked( CHANNEL_SORT,
//                                  settings.
//                                  readBoolEntry
//                                  ( "/qsopcast/enablechannelsorting", FALSE ) );//FIXME: port
    //enable auto restart player
//     QAction* autorestartplayerAct = new QAction( tr( "&Enable Auto Restarting Player" ), this );
//     autorestartplayerAct->setShortcut( QKeySequence( Qt::CTRL + Qt::Key_P ) );
//     connect( autorestartplayerAct, SIGNAL( triggered() ), this, SLOT( onAutoRestartPlayerToggled() ) );
//     menu_config->addAction( autorestartplayerAct );
//     menu_config->insertItem( tr( "&Enable Auto Restarting Player" ), this,
//                              SLOT( onAutoRestartPlayerToggled() ),
//                              Qt::CTRL + Qt::Key_P, AUTO_RESTART_PLAYER );
//     menu_config->setItemChecked( AUTO_RESTART_PLAYER,
//                                  settings.
//                                  readBoolEntry
//                                  ( "/qsopcast/enableautorestartplayer", FALSE ) );//FIXME: port
    //configuration
    QAction* configAct = new QAction( tr( "&Configure..." ), this );
    configAct->setShortcut( QKeySequence( Qt::CTRL + Qt::Key_F ) );
    connect( configAct, SIGNAL( triggered() ), this, SLOT( onconfigclicked() ) );
    menu_config->addAction( configAct );

    ///menu history
//     history = addMenu( tr( "&History" ) );
//     history->setCheckable( true );

//     QAction* clearAct = new QAction( tr( "&Clear" ), this );
//     clearAct->setShortcut( QKeySequence( Qt::CTRL + Qt::Key_K ) );
//     connect( clearAct, SIGNAL( triggered() ), this, SLOT( clearHistory() ) );
//     history->addAction( clearAct );
//     history->insertItem( tr( "&Clear" ), this, SLOT( clearHistory() ),
//                          Qt::CTRL + Qt::Key_K, 0 );
//     history->addSeparator();
//     connect( history, SIGNAL( triggered( QAction* ) ), this, SLOT( onChooseHistory( int ) ) );
//     insertItem( tr( "&History" ), history, id++ );

    ///menu bookmark
//     bookmark = addMenu( tr( "&Bookmark" ) );
//     QAction* addbookmarkAct = new QAction( tr( "&Add" ), this );
//     addbookmarkAct->setShortcut( QKeySequence( Qt::CTRL + Qt::Key_B ) );
//     connect( addbookmarkAct, SIGNAL( triggered() ), this, SLOT( addToBookmark() ) );
//     bookmark->addAction( addbookmarkAct );
//     bookmark->insertItem( tr( "&Add" ), this,
//                           SLOT( addToBookmark() ), Qt::CTRL + Qt::Key_B, 0 );
//     bookmark->addSeparator();
//     connect( bookmark, SIGNAL( triggered( QAction* ) ), this, SLOT( onChooseBookmark( int ) ) );
//     insertItem( tr( "&Bookmark" ), bookmark, id++ );

    ///menu help
    menu_help = addMenu( tr( "&Help" ) );
    QAction* aboutAct = new QAction( tr( "&About..." ), this );
    aboutAct->setShortcut( QKeySequence( Qt::CTRL + Qt::Key_H ) );
    connect( aboutAct, SIGNAL( triggered() ), this, SLOT( about() ) );
    menu_help->addAction( aboutAct );
}


MenuBar::~MenuBar()
{
//     QSettings settings;
//     settings.setValue( "/qsopcast/ChannelColor", color_column );
//     settings.setValue( "/qsopcast/shownullchannels",//FIXME: port
//                          menu_config->isItemChecked( NULL_CHANNEL ) );
//     settings.setValue( "/qsopcast/enableautorestartplayer",
//                          menu_config->isItemChecked( AUTO_RESTART_PLAYER ) );
}


// void
// MenuBar::clearHistory()
// {
    /*
    for ( int index = history->count() - 1; index >= 2; index-- ) {
        history->removeItemAt( index );
    }*/
// }

// void
// MenuBar::onSwitchColor( int id )
// {/*
//     mainwindow->channel->switchChannelColor( id );
//     color_column = id;
//     for ( uint index = 0; index < submenu_color->count(); index++ )
//         submenu_color->setItemChecked( submenu_color->idAt( index ), false );
//     submenu_color->setItemChecked( id, true );*/
// }

// void
// MenuBar::onNullChannelToggled()
// {/*
//     menu_config->setItemChecked( NULL_CHANNEL,
//                                  !menu_config->isItemChecked( NULL_CHANNEL ) );
//     mainwindow->channel->toggleNullChannel();*/
// }


// void
// MenuBar::onAutoRestartPlayerToggled()
// {/*
//     menu_config->setItemChecked( AUTO_RESTART_PLAYER,
//                                  !menu_config->
//                                  isItemChecked( AUTO_RESTART_PLAYER ) );*/
// }

void MenuBar::onconfigclicked()
{
    Config cfgdlg( this );
    cfgdlg.exec();
}

#include <QMessageBox>
#include <QPixmap>
#include <QImage>
#include "version.h"
void MenuBar::about()
{
    QMessageBox m;
    m.setWindowTitle( QString( tr( "About qsopcast %1" ) ).arg( QString( qsopcast_version ) ) );
    m.setIconPixmap( QPixmap::fromImage( QImage( "/usr/share/pixmaps/mozart.png" ) ) );//FIXME use relative path!!
    m.setText( QString( tr( "qsopcast: A QT front-end to p2p TV.\n"
                   "version: %1\n"
                   "Copyright (C) 2005, 2006, 2009 Liu Di\n"
                   "Copyright (C) 2007 Wei Lian\n"
                   "Copyright (C) 2009 Ni Hui\n"
                   "http://code.google.com/p/qsopcast/" ) ).arg( QString( qsopcast_version ) ) );
    m.exec();
}

#include "menubar.moc"
