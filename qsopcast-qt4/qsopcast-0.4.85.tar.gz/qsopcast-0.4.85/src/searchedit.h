#ifndef SEARCHEDIT_H
#define SEARCHEDIT_H

#include <QLineEdit>

class SearchEdit : public QLineEdit
{
    Q_OBJECT
    public:
        SearchEdit();
        bool no_text;
    protected:
        virtual void focusInEvent( QFocusEvent* e );
        virtual void focusOutEvent( QFocusEvent* e );
    private slots:
        void onTextEdited( const QString& text );
};

#endif // SEARCHEDIT_H
 