#include <QLineEdit>
#include "searchedit.h"

SearchEdit::SearchEdit()
{
    no_text = true;
    setText( tr( "Type here to search..." ) );
    connect( this, SIGNAL( textEdited( const QString& ) ),
             this, SLOT( onTextEdited( const QString& ) ) );
}

void SearchEdit::focusInEvent( QFocusEvent* e )
{
    if ( no_text )
        clear();
    QLineEdit::focusInEvent( e );
}

void SearchEdit::focusOutEvent( QFocusEvent* e )
{
    if ( text().isEmpty() ) {
        no_text = true;
        setText( tr( "Type here to search..." ) );
    }
    else
        no_text = false;
    QLineEdit::focusOutEvent( e );
}

 void SearchEdit::onTextEdited( const QString& text )
 {
     if ( !text.isEmpty() )
         no_text = false;
 }

#include "searchedit.moc"
