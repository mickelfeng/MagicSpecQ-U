/* define it to 0, if you have it, config.h will have it defined to 1 and that will be used*/
#define HAVE_FSEEK0 0 

#include <config.h>

#define HAVE_T1LIB_H 0
#define HAVE_FREETYPE_H HAVE_FREETYPE
#define HAVE_FREETYPE_FREETYPE_H HAVE_FREETYPE
#define OPI_SUPPORT 0
#define TEXTOUT_WORD_LIST 0
#define HAVE_MKSTEMPS 1 //libkdefakes provides it
