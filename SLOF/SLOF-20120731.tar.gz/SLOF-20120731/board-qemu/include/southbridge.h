/******************************************************************************
 * Copyright (c) 2011 IBM Corporation
 * All rights reserved.
 * This program and the accompanying materials
 * are made available under the terms of the BSD License
 * which accompanies this distribution, and is available at
 * http://www.opensource.org/licenses/bsd-license.php
 *
 * Contributors:
 *     IBM Corporation - initial implementation
 *****************************************************************************/

/* Not used */
#define SB_NVRAM_adr 	0
#define SB_FLASH_adr 	0
#define NVRAM_LENGTH	0x10000
#define FLASH_LENGTH 	0
#define SB_MAILBOX_adr	0

#define SECONDARY_CPUS_STOPPED
