/*
 * Copyright (C) 2008 Instituto Nokia de Tecnologia. All rights reserved.
 *
 * This file is part of QZion.
 *
 * QZion is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * QZion is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with QZion.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __QZIONTEXTBLOCK_P_H__
#define __QZIONTEXTBLOCK_P_H__

#include <QApplication>

#include "qzionmacros.h"
#include "qziontext.h"
#include "qziontextblock.h"

#include <QWebPage>
#include <QWebFrame>

class QZionTextBlockPrivate : public QObject
{
    Q_OBJECT

public:
    QZionTextBlock *owner;

    QZionTextBlockPrivate() : QObject(), scale(1.0), preferredWidth(0) {};
    void refresh();

    QWebPage page;
    QString text;
    double scale;
    QSize size;
    int preferredWidth;

public Q_SLOTS:
    inline void resizeContents();
};

inline void QZionTextBlockPrivate::refresh()
{
    if (owner->visible() && owner->canvas())
        owner->changed();
}

inline void QZionTextBlockPrivate::resizeContents()
{
    page.setViewportSize(page.mainFrame()->contentsSize());
}

#endif
