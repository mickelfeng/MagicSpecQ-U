#ifndef __ACTOR_H__
#define __ACTOR_H__

#include <QtGui>
#include "qzion.h"

class Scene : public QObject
{
    Q_OBJECT

private:
    int ncount;
    QZionCanvas *canvas;
    QZionRectangle *rectangle;
    QList<QZionImage *> images;

public:
    Scene(QZionCanvas *cnv = NULL, int item_count=128);

public Q_SLOTS:
    void tick_all();
};

#endif
