import sys
from PyQt4.QtCore import QSize
from PyQt4.QtGui import QApplication
from qzion import QZionCanvas, QZionImage, QZionClippedGroup

if __name__ == "__main__":
    app = QApplication(sys.argv)
    canvas = QZionCanvas()

    canvas.show()

    image = QZionImage(canvas, "bg.jpg")
    image.show()

    image2 = QZionImage(canvas, "ico.png")
    image2.setPos(20, 20)
    image2.show()

    sm = QZionClippedGroup(canvas)
    sm.setPos(0, 0)
    sm.setSize(QSize(150, 200))
    sm.addObject(image2)
    sm.show()

    sys.exit(app.exec_())
