# Defaults for smplayer initscript
# sourced by /etc/init.d/smplayer
# installed at /etc/default/smplayer by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
