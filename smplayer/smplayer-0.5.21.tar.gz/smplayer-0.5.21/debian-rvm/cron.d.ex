#
# Regular cron jobs for the smplayer package
#
0 4	* * *	root	smplayer_maintenance
