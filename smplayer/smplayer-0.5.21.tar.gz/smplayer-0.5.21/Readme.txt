    smplayer, GUI front-end for mplayer.
    Copyright (C) 2007 Ricardo Villalba <rvm@escomposlinux.org>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    -------------------------------------------------------------------------

SMPlayer intends to be a complete front-end for MPlayer, from basic
features like playing videos, DVDs, and VCDs to more advanced features
like support for MPlayer filters and more.

...

Well, you've probably read the rest in the web, haven't you?

To the point:

To know how to compile and install smplayer please read INSTALL.txt.

There's available an optional package called smplayer-themes. It contains
some icon themes for smplayer and it's highly recommended that you install it 
too.

Visit http://smplayer.sourceforge.net/ for updates.

    -------------------------------------------------------------------------

Third-party:

I took some icons from:

 * Vista-Inspirate 
    url: http://www.kde-look.org/content/show.php/Vista-Inspirate?content=31585
    license: GPL

 * ricebowl-0.2.0
    url: http://www.deviantart.com/deviation/22605468/
    license: LGPL 

 * rulesPlayer
   url: http://www.dsource.org/projects/rulesplayer
   license: "use without restrictions at your own risk"

 * mplayer (gmplayer)
   url: http://www.mplayerhq.hu/design7/news.html
   license: GPL

 * kplayer
   url: http://kplayer.sourceforge.net/
   license: GPL
