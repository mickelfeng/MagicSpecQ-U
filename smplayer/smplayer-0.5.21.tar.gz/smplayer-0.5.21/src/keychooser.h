/*  smplayer, GUI front-end for mplayer.
    Copyright (C) 2007 Ricardo Villalba <rvm@escomposlinux.org>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* 
    Note: most of the code in this class has been taken from the source 
    code of Qt-3 Designer (propertyeditor.h and propertyeditor.cpp).
	Copyright (C) 2000 Trolltech AS.
*/


#ifndef _KEYCHOOSER_H_
#define _KEYCHOOSER_H_

#include <qlineedit.h>

class KeyChooser : public QLineEdit
{
	Q_OBJECT

public:
	KeyChooser( QWidget * parent, const char * name = 0 );
	~KeyChooser();

public slots:
	virtual void clear();

protected:
	virtual void keyPressEvent ( QKeyEvent * e );
	virtual bool event ( QEvent * e );

private:
	int translateModifiers( int state );

    int k1, k2, k3, k4;
    int num;
	bool mouseEnter;
};

#endif
