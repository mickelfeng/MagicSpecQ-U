<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>mplayer 用のフロントエンド</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>開くファイル</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>開発者</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>Ok(&amp;O)</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>バージョン: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt のバージョン: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>このプログラムはフリー ソフトウェアです; あなたは Free Software Foundation によって発行されている GNU General Public License の条件の下で再配布することができます; License のバージョン 2 か、(あなたの選択で) すべてのより後のバージョンのどちらか。</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>翻訳者:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>ドイツ語</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>スロバキア語</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>イタリア語</translation>
    </message>
    <message>
        <source>French</source>
        <translation>フランス語</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>簡体中国語</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>ロシア語</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>ハンガリー語</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>日本語</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>オランダ語</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>ウクライナ語</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">ブラジルのポルトガル語</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>グルジア語</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>チェコ語</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo designed by %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>更新の取得: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>SMPlayer のバージョン情報</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 と %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>ポーランド語</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>KDE support でコンパイルされました</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>ブルガリア語</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>トルコ語</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>スウェーデン語</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>セルビア語</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>ショートカット</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>保存(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>読み込み(&amp;L)</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>キー ファイル</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>ファイル名の選択</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>上書きを確認しますか?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>ファイル %1 がすでに存在します。
上書きしますか?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>ファイルの選択</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>ファイルを保存できませんでした</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>ファイルを読み込めませんでした</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer のログ</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer のログ</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>開く(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>再生(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>ビデオ(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>オーディオ(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>字幕(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>参照(&amp;B)</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>オプション(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>ヘルプ(&amp;H)</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>ファイル(&amp;F)...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>ディレクトリ(&amp;I)...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>プレイリスト(&amp;P)...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>ドライブから DVD(&amp;D)</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>フォルダから DVD(&amp;V)...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>URL(&amp;U)...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>クリア(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>最近使ったファイル(&amp;R)</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>再生(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>一時停止(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>停止(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>フレーム ステップ(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>標準の速度(&amp;N)</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>半分の速度(&amp;H)</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>2 倍の速度(&amp;D)</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>-10% の速度(&amp;-)</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>+10% の速度(&amp;+)</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>速度(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>繰り返し(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>全画面表示(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>コンパクト モード(&amp;C)</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>サイズ(&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>自動検出(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>4:3(&amp;4)</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>5:4(&amp;5)</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>14:9(&amp;1)</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:9(&amp;9)</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>16:10(&amp;6)</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>2.35:1(&amp;2)</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 レターボックス(&amp;L)</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 レターボックス(&amp;E)</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 パンスキャン(&amp;P)</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 から 16:9 へ(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>アスペクト比(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>なし(&amp;N)</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>Lowpass5(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">Yadif(&amp;Y)</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>リニア ブレンド(&amp;B)</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>インターレイスの解除(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>処理後(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>位相の自動検出(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>ブロックの除去(&amp;D)</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>リングの除去(&amp;R)</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>ノイズの追加(&amp;O)</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>フィルタ(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>イコライザ(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>スクリーンショット(&amp;S)</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>常に手前に表示(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>トラック(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>エクストラステレオ(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>カラオケ(&amp;K)</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>フィルタ(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>既定(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>ステレオ(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>4.0 サラウンド(&amp;4)</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>5.1 サラウンド(&amp;5)</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>チャンネル(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>左チャンネル(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>右チャンネル(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>ステレオ モード(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>ミュート(&amp;M)</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>音量 &amp;-(&amp;-)</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>音量 &amp;+(&amp;+)</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>遅延 -(&amp;D)</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>遅延 +(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>選択(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>読み込み(&amp;L)...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>遅延 -(&amp;-)</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>遅延 +(&amp;+)</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>上へ(&amp;U)</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>下へ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>タイトル(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>チャプタ(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>角度(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>プレイリスト(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>フレーム カウンタの表示(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>無効(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>シーク バー(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>時間(&amp;T)</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>時間 + 全体の時間(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>OSD(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>ログの表示(&amp;V)</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>環境設定(&amp;R)</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Qt のバージョン情報(&amp;Q)</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>SMPlayer のバージョン情報(&amp;S)</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;空&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>ビデオ</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>オーディオ</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>プレイリスト</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>すべてのファイル</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>ファイルの選択</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - 情報</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM / DVD ドライブがまだ構成されていません。
構成ダイアログが今すぐ表示されます、そうすることができます。</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>ディレクトリの選択</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>字幕</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Qt のバージョン情報</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>%1 を再生中</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>一時停止</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>ノイズの除去(&amp;N)</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>通常(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>ソフト(&amp;S)</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>再生 / 一時停止</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>一時停止 / フレーム ステップ</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>読み込みの解除(&amp;N)</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - 警告</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>ポート %1 はすでに別のアプリケーションによって使用されています。
サーバーを開始できません。</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>ポート %1 でのサーバーが応答しません。
単一のオプションは無効です。</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>VCD(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">終了(&amp;Q)</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>閉じる(&amp;L)</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>情報とプロパティの表示(&amp;I)...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>縮小(&amp;-)</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>拡大(&amp;+)</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>リセット(&amp;R)</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>左へ移動(&amp;L)</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>右へ移動(&amp;R)</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>上へ移動(&amp;U)</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>下へ移動(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>パン &amp;&amp; スキャン(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>前の字幕のライン(&amp;P)</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>次の字幕のライン(&amp;E)</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>音量を下げる (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>音量を上げる (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>全画面表示の終了</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - 次のレベル</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>コントラストを下げる</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>コントラストを上げる</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>明るさを下げる</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>明るさを上げる</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>色合いを下げる</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>色合いを上げる</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>鮮やかさを下げる</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>ガンマを下げる</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>次のオーディオ</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>次の字幕</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>次のチャプタ</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>前のチャプタ</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>鮮やかさを上げる</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>ガンマを上げる</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">次へ(&amp;N)</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">前へ(&amp;V)</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer はまだここで起動しています</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>システム トレイにアイコンを表示する(&amp;H)</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>非表示(&amp;H)</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>復元(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>最近使ったファイル(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">終了(&amp;Q)</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>明るさ: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>コントラスト: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>ガンマ: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>色合い: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>鮮やかさ: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>音量: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>拡大率: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>SMPlayer へようこそ</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>音量</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>オーディオ</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>字幕</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>プレイリスト</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>メイン ツール バー(&amp;M)</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>言語ツール バー(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>ツール バー(&amp;T)</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>西ヨーロッパ言語</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>ユーロ地域の西ヨーロッパ言語</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>スラブ/中央ヨーロッパ言語</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>エスペラント語、ガリシア語、マルタ語、トルコ語</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>古バルト語文字セット</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>キリル文字</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>アラビア語</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>現代ギリシャ語</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>トルコ語</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>バルト語</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>ケルト語</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>ヘブライ文字セット</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>ロシア語</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>ウクライナ語、ベラルーシ語</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>簡体中国語文字セット</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>繁体中国語文字セット</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>日本語文字セット</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>韓国語文字セット</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>タイ語文字セット</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>キリル文字 Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>スラブ/中央ヨーロッパ言語 Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqSlider</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>アイコン</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - ファイルのプロパティ</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>情報(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>デミュクサ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>このファイルに使用するデミュクサを選択します(&amp;S):</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>リセット(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>ビデオ コーデック(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>ビデオ コーデックを選択します(&amp;S):</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>オーディオ コーデック(&amp;U)</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>オーディオ コーデックを選択します(&amp;S):</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>MPlayer のオプション(&amp;M)</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>オプション(&amp;O):</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>追加ビデオ フィルタも渡すことができます。
&quot;,&quot; で区切ります。スペースは使用しません!
例: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>ビデオ フィルタ(&amp;I):</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>そして最後はビデオ フィルタです。ビデオ フィルタと同じ規則です。
例: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>オーディオ フィルタ(&amp;F):</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>OK(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>適用(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>キャンセル(&amp;C)</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>MPlayer の追加オプション</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>ここで MPlayer へのエクストラ オプションを下すことができます。
スペースによって区切ってそれらを書き込みます。
例: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>一般</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>パス</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>サイズ</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>長さ</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>デミュクサ</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>アーティスト</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>アルバム</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>ジャンル</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>日付</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>トラック</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>著作権</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>コメント</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>ソフトウェア</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>クリップ情報</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>ビデオ</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>解像度</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>アスペクト比</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>フォーマット</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>ビットレート</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>秒あたりのフレーム</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>選択済みコーデック</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>初期オーディオ ストリーム</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>率</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>チャンネル</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>オーディオ ストリーム</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>言語</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>空</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>字幕</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>種類</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>番号</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>ストリームのタイトル</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>ストリームの URL</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>ディレクトリの選択</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - フォルダから DVD を再生</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>お使いのハード ディスクから dvd を再生できます。VIDEO_TS および AUDIO_TS ディレクトリを含むフォルダを選択します。</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>ディレクトリの選択...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>Ok(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>キャンセル(&amp;C)</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>以下に保存するファイル名を選択します</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>上書きを確認しますか?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>ファイルがすでに存在します。
上書きしますか?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>ファイルの保存中のエラー</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>ログを保存することができませんでした</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>ログ ウィンドウ</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>クリップボードへコピー</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>閉じる(&amp;C)</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>長さ</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>再生(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>編集(&amp;E)</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>プレイリスト</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>ファイルの選択</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>ファイル名の選択</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>上書きを確認しますか?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>ファイル %1 がすでに存在します。
上書きしますか?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>すべてのファイル</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>1 つ以上の開くファイルを選択します</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>ディレクトリの選択</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>名前の編集</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>このファイルのためのプレイリストに表示する名前を入力します:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>読み込み(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>保存(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>次へ(&amp;N)</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>前へ(&amp;V)</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>上へ移動(&amp;U)</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>下へ移動(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>繰り返し(&amp;R)</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>シャッフル(&amp;H)</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>現在のファイルの追加(&amp;C)</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>ファイルの追加(&amp;F)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>ディレクトリの追加(&amp;D)</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>選択済みの削除(&amp;S)</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>すべて削除(&amp;A)</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - プレイリスト</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>追加...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>削除...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>プレイリストが変更されました</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>未保存の変更があります、プレイリストを保存しますか?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>一般</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>ドライブ</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>パフォーマンス</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>字幕</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>高度</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>実行ファイル</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>すべてのファイル</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>mplayer の実行ファイルを選択します</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>ディレクトリの選択</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype フォント</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Ttf ファイルの選択</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>短いジャンプ</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>中ジャンプ</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>長いジャンプ</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>マウス ホイール ジャンプ</translation>
    </message>
    <message>
        <source>None</source>
        <translation>なし</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>インターフェイス</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">マウスとキーボード</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>ここで smplayer によって取得されたスクリーンショットが格納されるフォルダを指定できます。このフィールドが空である場合はスクリーンショット機能は無効になります。</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>ビデオの出力ドライバを選択します。通常 xv (linux) と directx (windows) が最高のパフォーマンスを供給します。</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>オーディオの出力ドライバを選択します。</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>ビデオ イコライザがお使いのグラフィック カードまたは選択されたビデオの出力ドライバによってサポートされていない場合にこのオプションをチェックします。&lt;br&gt;&lt;b&gt;注意:&lt;/b&gt; このオプションはいくつかのビデオの出力ドライバとは互換性がない可能性があります。</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>サウンド カード ミキサを使用する代わりに、ソフトウェア ミキサを使用するにはこのオプションをチェックします。</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>このオプションをチェックすると、smplayer はすべてのファイルを最初から再生します。</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>このオプションがチェックされている場合、すべてのビデオは全画面表示モードで開始されます。</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>再生中にスクリーンセーバーを無効にするにはこのオプションをチェックします。&lt;br&gt;スクリーンセーバーは再生の完了時に再び有効になります。&lt;br&gt;&lt;b&gt;注意:&lt;/b&gt;このオプションは X11 と Windows のみで機能します。</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>ここで smplayer が使用する mplayer の実行ファイルを指定する必要があります。&lt;br&gt;smplayer は少なくとも mplayer 1.0rc1 (svn が推奨されます) を必要とします。&lt;br&gt;&lt;b&gt;この設定が間違っていると、smplayer は何も再生することができません!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>チェックされている場合、smplayer は mplayer の出力 (&lt;b&gt;オプション-&gt;ログの表示-&gt;mplayer&lt;/b&gt; でご覧できます) を格納します。このログは重要な情報を含む可能性があるので、このオプションのチェックを保持することが推奨されます。</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>このオプションがチェックされている場合、smplayer は smplayer が出力するデバッグ メッセージ (&lt;b&gt;オプション-&gt;ログの表示-&gt;smplayer&lt;/b&gt; でご覧できます) を格納します。この情報はバグを検索する場合に開発者のために非常に有用です。</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>このオプションはログに格納される smplayer のメッセージをフィルタすることを許可します。ここで何か正規表現を書き込むことができます。&lt;br&gt;例: &lt;i&gt;^Core::.*&lt;/i&gt; では &lt;i&gt;Core::&lt;/i&gt; で始まる行のみが表示されます</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">ログ</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;注意:&lt;/b&gt; このオプションは Windows のみのためのものです。</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>既定</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Windows 下で利用可能な所定の優先度に従って mplayer のプロセス優先度を設定します。&lt;br&gt;&lt;b&gt;警告:&lt;/b&gt; リアルタイム優先度の使用はシステム ロックアップを引き起こす可能性があります。</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>通常 smplayer は再生するファイル (選択されたオーディオ トラック、音量、フィルタ...) ごとに設定を記憶します。この機能を好まないならこのオプションのチェックを解除します。</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>ここでオーディオ ストリームの優先言語を入力できます。複数のオーディオ ストリームを持つメディアが見つかったとき、smplayer は優先言語の使用を試行します。&lt;br&gt;これは DVD または mkv ファイルのような、オーディオ ストリームの言語についての情報が提供されているメディアでのみ機能します。&lt;br&gt;このフィールドは正規表現を受け入れます。例: &lt;b&gt;es|esp|spa&lt;/b&gt; では &lt;i&gt;es&lt;/i&gt;、&lt;i&gt;esp&lt;/i&gt; または &lt;i&gt;spa&lt;/i&gt; に一致する場合にオーディオ トラックが選択されます。</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>ここで字幕ストリームの優先言語を入力できます。複数の字幕ストリームを持つメディアが見つかったとき、smplayer は優先言語の使用を試行します。&lt;br&gt;これは DVD または mkv ファイルのような、字幕ストリームの言語についての情報が提供されているメディアでのみ機能します。&lt;br&gt;このフィールドは正規表現を受け入れます。例: &lt;b&gt;es|esp|spa&lt;/b&gt; では &lt;i&gt;es&lt;/i&gt;、&lt;i&gt;esp&lt;/i&gt; または &lt;i&gt;spa&lt;/i&gt; に一致する場合に字幕ストリームが選択されます。</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>このオプションはファイルまたは URL をプリキャッチしたときにメモリ (k バイト) をどのくらい使用するかを指定します。特に遅いメディアにおいて有用です。</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>いくつかのフレームの表示をスキップして遅いシステムでの A/V 同期を維持させます。</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>より強烈なフレーム ドロップです (デコードが破損します)。イメージの歪曲の原因となります!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>徐々にオーディオの遅延測定を基準にして A/V 同期を調整します。</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>動的に利用可能なスペア CPU 時間次第で処理後のレベルを変更します。指定する番号は使用される最大レベルになります。通常いくらかの大きい番号を私用します。</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>チェコ語</translation>
    </message>
    <message>
        <source>German</source>
        <translation>ドイツ語</translation>
    </message>
    <message>
        <source>English</source>
        <translation>英語</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>スペイン語</translation>
    </message>
    <message>
        <source>French</source>
        <translation>フランス語</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>ハンガリー語</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>イタリア語</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>日本語</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>グルジア語</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>オランダ語</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>ポーランド語</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">ブラジルのポルトガル語</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>ロシア語</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>スロバキア語</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>ウクライナ語</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>簡体中国語</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;自動検出&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>ブルガリア語</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>このオプションのチェックはちらつきを減少させる可能性がありますが、ビデオが適切に表示されなくなることを生む可能性もあります。</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>トルコ語</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>ギリシャ語</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>フィンランド語</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>スウェーデン語</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>このオプションはビデオ ウィンドウ上の字幕の位置を指定します。&lt;i&gt;100&lt;/i&gt; は最下を意味しますが、&lt;i&gt;0&lt;/i&gt; は最上を意味します。</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">ここで SSA/ASS 字幕のスタイルを優先的に指定できます。SSA/ASS ライブラリによる srt とサブ字幕の描画の微調整にも使用されます。&lt;br&gt;例: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>セルビア語</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - 環境設定</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>OK(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>適用(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>キャンセル(&amp;C)</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">一般</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>パス</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>検索...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>選択...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>スクリーンショットを格納するフォルダ:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>ドライバの出力</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>ビデオ:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>オーディオ:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>ソフトウェアのビデオ イコライザを使用する</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>ソフトウェアのボリューム コントロールを使用する</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>メディアの設定</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>すべてのファイルの設定を記憶する (オーディオ トラック、字幕...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>時間の位置を記憶しない (ファイルは最初から再生が開始されます)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>全画面表示でビデオを開始する</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">字幕</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>フォント</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>字幕 (と OSD) に使用するフォントを選択します:</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF フォント:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>選択...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>システム フォント:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>サイズ</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>オートスケール:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>オートスケールなし</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>ムービーの高さに比例する</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>ムービーの幅に比例する</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>ムービーの対角線に比例する</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>スケール:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>自動読み込み</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">自動的に最初に利用可能な字幕を選択する</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>ムービーと同じ名前</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>ムービーの名前を含むすべての字幕</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>ディレクトリ内のすべての字幕</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>自動読み込みする字幕ファイル (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>既定の字幕エンコード:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>字幕の描画に SSA/ASS ライブラリを使用する</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>テキストの色:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>枠の色:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>スクリーンショットに字幕を含める</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">高度</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>オプション:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>追加ビデオ フィルタも渡すことができます。
&quot;,&quot; で区切ります。スペースは使用しません!
例: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>ビデオ フィルタ:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>そして最後はビデオ フィルタです。ビデオ フィルタと同じ規則です。
例: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>オーディオ フィルタ:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>パフォーマンス</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>優先度:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>リアルタイム</translation>
    </message>
    <message>
        <source>high</source>
        <translation>高</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>通常の上</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>通常</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>通常の下</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>アイドル</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>キャッシュの設定は遅いメディアでのパフォーマンスを向上させる可能性があります</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">キャッシュ:</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>フレーム ドロップを許可する</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>ハード メディア ドロップを許可する (イメージの歪曲の原因となる可能性があります)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>同期化</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>オーディオ/ビデオの自動同期化</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>要因:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">フィルタ処理後の自動品質:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">レベル:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">最低</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">最高</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>オーディオ トラックの高速切り替え</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Dvd のチャプタを高速シークする</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(キャッシュは無効にされますし本当に機能するのか保証されません)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>スクリーンセーバーを無効にする</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>モニタの比率:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>メイン ウィンドウのサイズの変更方法:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>しない</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>必要なときはいつも</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>新しいビデオの読み込み後のみ</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>単一</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>SMPlayer の 1 つのみの起動を使用する</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer はその他からのコマンドの受信にこのポートを聴きます:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(このグループの変更は SMPlayer の再起動を必要とします)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>スタイル:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>ドライブ</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>現在 SMPlayer は cdrom または dvd デバイスを自動検出しません。Cdroms または dvd を再生するには最初にお使いの cdrom および dvd ドライブ (同じにすることができます) を選択する必要があります。</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>アイコン</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>お使いの CD デバイスを選択します:</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>お使いの DVD デバイスを選択します:</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>最近使ったファイル</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>最大アイテム数</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>一覧のクリア</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>シーク</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>音量</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>既定の音量:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">マウス</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>ボタンの機能:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>ダブル クリック</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>左クリック</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>ウィンドウ サイズ</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>インターフェイス</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>ホイールの機能:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>メディア シーク</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>ボリューム コントロール</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">マウスとキーボード</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">キーボード</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">ログ</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>このオプションは主にアプリケーションのデバッグが対象です。</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>言語:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>アイコン セット:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>優先オーディオおよび字幕</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>字幕:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>優先度</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>MPlayer の実行ファイルを選択します:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>MPlayer を自身のウィンドウで起動します</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>MPlayer の追加オプション</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>ここで MPlayer へのエクストラ オプションを下すことができます。スペースによって区切ってそれらを書き込みます。例: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>MPlayer プロセスの優先度を選択します。</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>MPlayer の出力を記録します</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>SMPlayer の出力を記録します</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>SMPlayer ログのフィルタ:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>ビデオ ウィンドウの背景を再描画しない</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>ここですべてのショートカットを変更できます。</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>まず利用可能な字幕を選択する</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>画面上の字幕の既定の位置</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>カラーキー:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>変更...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>先頭へ</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>末尾へ</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>スタイル:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">字幕(&amp;S)</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">ビデオ</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">オーディオ</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 秒</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 秒</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 分</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 分と %2 秒</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 分</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 分と 2 秒</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 分と %1 秒</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 分と 1 秒</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>アイコン</translation>
    </message>
    <message>
        <source>label</source>
        <translation>ラベル</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>イコライザ</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>コントラスト</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>明るさ</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>色合い</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>鮮やかさ</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>ガンマ</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>リセット(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>既定の値として設定(&amp;S)</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>現在の値を新しいビデオの既定の値として使用します。</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>すべてのコントロールを 0 に設定します。</translation>
    </message>
</context>
</TS>
