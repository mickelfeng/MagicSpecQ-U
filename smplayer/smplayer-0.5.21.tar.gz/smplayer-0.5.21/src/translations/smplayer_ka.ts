<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Developer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>ვერსია: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt-ს ვერსია: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>ეს პროგრამა წარმოადგენს თავისუფალ პროგრამულ უზრუნველყოფას; თქვენ შეგიძლიათ გაავრცელოთ ის და/ან შეცვალოთ ის Free Software Foundation ფონდის მიერ გამოქვეყნებული GNU GPL ლიცენზიაში გათვალისწინებული წესების მიხედვით; როგორც ლიცენზიის მეორე ვერსიით, ასევე (თქვენი გადაწყვეტილებით) ნებისმიერი უფრო ახალი ვერსიით.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>თარჯიმნები:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>გერმანული</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>სლოვაკური</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>იტალიური</translation>
    </message>
    <message>
        <source>French</source>
        <translation>ფრანგული</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>გამარტივებული ჩინური</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>რუსული</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>უნგრული</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>იაპონური</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>ჰოლანდიური</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>უკრაინული</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">ბრაზილური პორტუგალიური</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>ქართული</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>ჩეხური</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>ლოგოს ავტორი - %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>მიიღეთ განახლებები გვერდიდან: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>SMPlayer-ის შესახებ</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="unfinished">პოლონური</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">თურქული</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">დასახელება</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished">შენა&amp;ხვა</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation type="unfinished">ჩა&amp;ტვირთვა</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation type="unfinished">აირჩიეთ ფაილის სახელი</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished">დავადასტუროთ შეცვლა?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished">ფაილი %1 უკვე არსებობს.
გსურთ მისი შეცვლა?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished">აირჩიეთ ფაილი</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;ფაილი...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>დ&amp;ირექტორია...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>რე&amp;პერტუარი...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD ამძრავიდან</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD დასტიდან...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>და&amp;კვრა</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;პაუზა</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;გაჩერება</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>კადრული ბი&amp;ჯი</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>გამეო&amp;რება</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;ნორმალური სიჩქარე</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>ნა&amp;ხევარი სიჩქარე</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;ორმაგი სიჩქარე</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>სიჩქარე &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>სიჩქარე &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>სი&amp;ჩქარე</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>მთელს ეკრან&amp;ზე</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;კომპაქტური რეჟიმი</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;ეკვალაიზერი</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>ეკრანი&amp;ს ანაბეჭდი</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>&amp;ყოველთვის ზემოდან</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;შემდგომი დამუშავება</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>ფაზის &amp;ავტოამოცნობა</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>&amp;ხმაურის დამატება</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>ფ&amp;ილტრები</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>გა&amp;ჩუმება</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>ხმა &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>ხმა &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;დაყოვნება -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>და&amp;ყოვნება +</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;ექსტრასტერეო</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;კარაოკე</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;ფილტრები</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>ჩა&amp;ტვირთვა...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>დაყოვნება &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>დაყოვნება &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;ზევით</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;ქვევით</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>რე&amp;პერტუარი</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>კადრების მ&amp;თვლელის ჩვენება</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>პა&amp;რამეტრები</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;ჟურნალების ჩვენება</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>&amp;Qt-ს შესახებ</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>&amp;SMPlayer-ის შესახებ</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;გახსნა</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>და&amp;კვრა</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;ვიდეო</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;აუდიო</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;სუბტიტრები</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;ნუსხა</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>პარამე&amp;ტრები</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>და&amp;ხმარება</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;წინა ფაილები</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;გასუფთავება</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;ზომა</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;ფარდობა</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;დეინტერლაცია</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>&amp;ხმაურის მოხსნა</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;ავტოამოცნობა</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 -&gt; 16:9-&amp;ზე</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;არაა</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>სწრფივი &amp;შერევა</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>ნ&amp;ორმალური</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>რ&amp;ბილი</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;ჩანაწერი</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>არ&amp;ხები</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;სტერეორეჟიმი</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;ნაგულისხმები</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;სტერეო</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>მარ&amp;ცხენა არცი</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>მარ&amp;ჯვენა არხი</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>ა&amp;რჩევა</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;სათაური</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;თავი</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;კუთხე</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>გათი&amp;შულია</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>გადა&amp;სვლის ზოლი</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;დრო</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>დრო + &amp;ჯამური დრო</translation>
    </message>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer-ის ჟურნალი</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer-ის ჟურნალი</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;ცარიელია&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>ვიდეო</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>აუდიო</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>რეპერტუარები</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>ყველა ფაილი</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>აირჩიეთ ფაილი</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - ინფორმაცია</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM / DVD ამძრავები ჯერ არ არის გამართული.(new line)კონფიგურაციის დიალოგი ახლა გამოჩნდება, შეგიძლიათ გამართოთ ისინი.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>აირჩიეთ დასტა</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>სუბტიტრები</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Qt-ს შესახებ</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>ვუკრავ %1-ს</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>პაუზა</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>შეჩერება</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>დაკვრა / პაუზა</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>პაუზა / კადრული ბიჯი</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;გამოტვირთვა</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">&amp;საწყისი პარამეტრები</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation type="unfinished">&amp;ზევით აწევა</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation type="unfinished">&amp;ქვევით ჩაწევა</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;შემდეგი</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">&amp;წინა</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation type="unfinished">&amp;წინა ფაილები</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>სიკაშკაშე: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>კონტრასტი: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>გამა: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>ტონი: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>ინტენსივობა: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>ხმა: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>მოგესალმებათ SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>ხმა</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>აუდიო</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>სუბტიტრები</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>რეპერტუარი</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;ძირითადი პანელი</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>ენის პა&amp;ნელი</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;ინსრუმენტთა პანელები</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>დასავლეთევროპული ენები</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>დასავლეთევროპული ენები ევროს მხარდაჭერით</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>სლავური/ცენტრალურევროპული ენები</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>ესპერანტო, გალიციური, მალტური, თურქული</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>ძველი ბალტიური სიმბოლოების ნაკრები</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>კირილიცა</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>არაბული</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>თანამედროვე ბერძნული</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>თურქული</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>ბალტიური</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>კელტური</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>ებრაულ სიმბოლოთა ნაკრები</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>რუსული</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>უკრაინული, ბელორუსული</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>გამარტივებული ჩინურის სიმბოლოთა ნაკრები</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>ტრადიციული ჩინურის სიმბოლოთა ნაკრები</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>იაპონურ სიმბოლოთა ნაკრები</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>კორეულ სიმბოლოთა ნაკრები</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>ტაილანდურ სიმბოლოთა ნაკრები</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Windows-ის კირილიცა</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Windows-ის სლავური/დენტრალურევროპული</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>ეკვზოლი</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ხატულა</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation type="unfinished">&amp;დემულტიპლექსორი</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation type="unfinished">აირჩიეთ ამ ფაილის დემულტიპლექ&amp;სორი:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">&amp;საწყისი პარამეტრები</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation type="unfinished">&amp;ვიდეო კოდეკი</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation type="unfinished">აირ&amp;ჩიეთ ვიდეო კოდეკი:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation type="unfinished">ა&amp;უდიო კოდეკი</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation type="unfinished">აირჩიეთ აუდიო &amp;კოდეკი:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation type="unfinished">&amp;MPlayer-ის პარამეტრები</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation type="unfinished">&amp;პარამეტრები:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="unfinished">აგრეთქე შეგიძლიათ დამატებითი ვიდეოფილრების მითითება.
გამოყავით ისინი &quot;,&quot; სიმბოლოს საშუალებით. არ გამოტოვოთ ადგილი!
მაგალითი: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation type="unfinished">ვ&amp;იდეოფილტრები:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="unfinished">და ბოლოს - აუდიოფილრტრები. იგივე წესით როგორც ვიდეოფილრები.
მაგალითი: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation type="unfinished">აუდიო&amp;ფილტრები:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished">გამო&amp;ყენება</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;შეწყვეტა</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation type="unfinished">ძირითადი</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished">გეზი</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">ზომა</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation type="unfinished">%1 კბ (%2 მბ)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished">URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished">ხანგრძლივობა</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation type="unfinished">დემულტიპლექსორი</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">დასახელება</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation type="unfinished">შემსრულებელი</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished">ავტორი</translation>
    </message>
    <message>
        <source>Album</source>
        <translation type="unfinished">ალბომი</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation type="unfinished">ჟანრი</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">თარიღი</translation>
    </message>
    <message>
        <source>Track</source>
        <translation type="unfinished">ჩანაწერი</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation type="unfinished">საავტორო უფლებები</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">კომენტარი</translation>
    </message>
    <message>
        <source>Software</source>
        <translation type="unfinished">პროგრამა</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation type="unfinished">ინფორმაცია - კლიპი</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">ვიდეო</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="unfinished">გარჩევადობა</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation type="unfinished">თანაფარდობა</translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished">ფორმატი</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation type="unfinished">ბიტური სიხშირე</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation type="unfinished">%1 კბწმ</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation type="unfinished">კადრი წამში</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation type="unfinished">არჩეული კოდეკი</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation type="unfinished">საწყისი აუდიონაკადი</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished">სიხშირე</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation type="unfinished">%1 ჰც</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation type="unfinished">არხები</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation type="unfinished">აუდიონაკადები</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">ენა</translation>
    </message>
    <message>
        <source>empty</source>
        <translation type="unfinished">ცარიელია</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="unfinished">სუბტიტრები</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">ტიპი</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation type="unfinished">#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>აირჩიეთ დირექტორია</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - დაუკარით DVD დასტიდან</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>თქვენ შეგიძლიათ გაუშვათ dvd თქვენი მყარი დისკიდან. უბრალოდ აირჩიეთ დასტა რომელიც შეიცვს VIDEO_TS და AUDIO_TS დირექტორიებს.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>აირჩიეთ დირექტორია...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;შეწყვეტა</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>აირჩიეთ ჩასაწერი ფაილის სახელი</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>დავადასტუროთ შეცვლა?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>ფაილი უკვე არსებობს.
გსურთ მისი შეცვლა?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>შეცდომა ფაილის შენახვისას</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>ჟურნალის შენახვა ვერ მოხერხდა</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>ჟურნალის ფანჯარა</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>შენახვა</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>გაცვლის ბუფერში შენახვა</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>დაკეტვა</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>და&amp;კეტვა</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>დასახელება</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>ხანგრძლივობა</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>და&amp;კვრა</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>რ&amp;ედაქტირება</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>რეპერტუარები</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>აირჩიეთ ფაილი</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>აირჩიეთ ფაილის სახელი</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>დავადასტუროთ შეცვლა?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>ფაილი %1 უკვე არსებობს.
გსურთ მისი შეცვლა?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>ყველა ფაილი</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>გასახსნელად აირჩიეთ ერთი ან რამოდენიმე ფაილი</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>აირჩიეთ დირექტორია</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>სახელის რედაქტირება</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>შეიყვანეთ სახელი რომელიც იქნება გამოსახული რეპერტუარიში ამ ფაილისთვის:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>ჩა&amp;ტვირთვა</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>შენა&amp;ხვა</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;შემდეგი</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;წინა</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>&amp;ზევით აწევა</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>&amp;ქვევით ჩაწევა</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>გამეო&amp;რება</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>არე&amp;ვა</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>&amp;მიმდინარე ფაილის დამატება</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>&amp;ფაილ(ებ)ის დამატება</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>&amp;დირექტორიის დამატება</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>ა&amp;რჩეულის ამოღება</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>ყველ&amp;ას ამოღება</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - რეპერტუარი</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>დამატება...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>ამოღება...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>ძირითადი</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>ამძრავები</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>წარმადობა</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>სუბტიტრები</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>დამატებითი</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>გაშვებადი ფაილები</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>ყველა ფაილი</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>აირჩიეთ mplayer-ის გაშვებადი ფაილი</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>აირჩიეთ დირექტორია</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype შრიფტები</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>აირჩიეთ ttf ფაილი</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>ინტერფეისი</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">თაგუნა და კლავიატურა</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">ჟურნალები</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>მოკლე ნახტომი</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>საშუალო ნახტომი</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>გრძელი ნახტომი</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>თაგვის ბორბალის მგრძნობიარობა</translation>
    </message>
    <message>
        <source>None</source>
        <translation>არაა</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>ნაგულისხმები</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>აქ თქვენ უნდა მიუთითოთ mplayer-ის გაშვებადი ფაილი რომელსაც smplayer გამოიყენებს..&lt;br&gt;smplayer მოითხოვს mplayer-ის 1.0rc1 ვერსიას მაინც (რეკომენდირებულია svn).&lt;br&gt;&lt;b&gt;თუ ეს პარამეტრი არასწორია, smplayer ვერაფერს ვერ დაუკრავს!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>აქ თქვენ შეგიძლიათ მიუთითოთ დასტა სადაც შეინახება smplayer-ის ეკრანის ანაბეჭდები. თu ეს ველი ცარიელია, მაშინ ეკრანის ანაბეჭის მოხსნა შეუძლებელი იქნება.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>აირჩიეთ ვიდეოგამომყვანის დრაივერი. როგორც წესი xv (linux) და directx (windows) საუკეთესო წარმადობისაა.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>აირჩიეთ აუდიოგამომყვანის დრაივერი</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>თქვენ შეგიძლიათ მონიშნოთ ეს პარამეტრი თუ თქვენს გრაფიკულ დაფას ან გამომყვან დრაივერს არ აქვს ვიდეოეკვალაიზერი.&lt;br&gt;&lt;b&gt;შენიშვნა:&lt;/b&gt; ეს პარამეტრში შეიძლება არათავსებადი აღმოჩნდეს ზოგიერთ გამომყვან დრაივერთან.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>მონიშნეთ ეს პარამეტრი აუდიოდაფის მიქშერის მაგივრად პროგრამული მიქშერის გამოსაყენებლად.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>როგორც წესი smplayer იმახსოვრებს პარამეტრებს ყოველი დაკრული ფაილისათვის (არჩეული აუდიოჩანაწერს, ხმას, ფილტრებს...). გამორთეთ ეს პარამეტრი თუ თქვენ არ მოგწონთ ის.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>თუ თქვენ მონიშნავთ ამ პარამეტრს, მაშინ smplayer დაუკრავს ყველა ფაილს დასაწყისიდან.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>თუ ეს პარამეტრი მონიშნულია, მაშინ ყველა ვიდეო გაიშვებს სრულეკრანიან რეჟიმში.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>მონიშნეთ ეს პარამეტრი ეკრანმზოგის დაკვრის დროს გათიშვისთვის.&lt;br&gt;ეკრანმზოგი ისევ ჩაირთვება როდესაც დაკვრას დაასრულებთ.&lt;br&gt;&lt;b&gt;შენიშვნა:&lt;/b&gt; ეს პარამეტრი მუშაობს მხოლოდ X11-ში და Windows-ში.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>აქ თქვენ შეგიძლიათ მიუთითოთ თქვენი პრიორიტეტული ენა აუდიონაკადებისთვის. როდესაც აღმოჩენილი იქნება მატარებელი რამოდენიმე აუდიონაკადით, smplayer ეცდება გამოიყენოს პრიორიტეტული ენა.&lt;br&gt;ეს პარაემეტრი იმუშავებს მხოლოდ იმ მატარებლებთან სადაც მითითებულია ინფორმაცია აუდიონაკადების ენების შესახებ, როგორიცაა DVD ან mkv ფაილები.&lt;br&gt;შესაძლებელია რეგულარული გამოსახულებების შეყვანა. მაგალითად: &lt;b&gt;es|esp|spa&lt;/b&gt; აირჩევს აუდიონაკადს რომელიც ემთხვევა &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; ან &lt;i&gt;spa&lt;/i&gt;-ს.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>აქ თქვენ შეგიძლიათ მიუთითოთ თქვენი პრიორიტეტული ენა სუბტიტრებისათვის. როდესაც აღმოჩენილი იქნება მატარებელი რამოდენიმე სუბტიტრით, smplayer ეცდება გამოიყენოს პრიორიტეტული ენა.&lt;br&gt;ეს პარაემეტრი იმუშავებს მხოლოდ იმ მატარებლებთან სადაც მითითებულია ინფორმაცია სუბტიტრების ენების შესახებ, როგორიცაა DVD ან mkv ფაილები.&lt;br&gt;შესაძლებელია რეგულარული გამოსახულებების შეყვანა. მაგალითად: &lt;b&gt;es|esp|spa&lt;/b&gt; აირჩევს აუდიონაკადს რომელიც ემთხვევა &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; ან &lt;i&gt;spa&lt;/i&gt;-ს.</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>აირჩიოთ mplayer-ის პრიორიტეტი Windows-ში წინასწარ განსაზღვრული მნიშნელობებიდან.&lt;br&gt;&lt;b&gt;ყურადღება:&lt;/b&gt; რეალური დროის პრიორიტეტის გამოყენებამ შეიძლება გამოიწვიოს სისტემის უმოქმედობა.</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;შენიშვნა:&lt;/b&gt; ეს პარამეტრი განკუთვნილია მხოლოდ Windows-თვის.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>ეს პარამეტრი უთითებს თუ რამდენი მეხსიერება შეიძლება იყოს გამოყენებული (კილობაიტებში) ფაილის ან URL-ის ბუფერირებისთვის. გამოიყენება ნელ მატარებლებში.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>ზოგიერთი კადრის გამოტოვება A/V სინქრონიზაციის ნელ სისტემებზე შესანარჩუნებლად.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>კადრების უფრო ინტენსიური გამოტოვება (არღვევს დეკოდირებას). ამახინჯებს გამოსახულებას!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>ნაბიჯნაბიჯ არეგულირებს A/V სინქრონიზაციას ხმის დაყოვნებების გაზომვით.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>დინამიურად ცვლის შემდგომი დამუშავების დონეს პროცესორის დატვირთვის მიხედვით. თქვენს მიერ მითითებული რიცხვი იქნება მაქსიმალური დონე. როგორც წესი უთითებენ რაღაც დიდ რიცხვს.</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>თუ მონიშნულია, მაშინ smplayer შეინახავს mplayer-ის გამონატანს (შეგიძლიათ იხილოთ მენიუში &lt;b&gt;პარამეტრები-&gt;ჟურანლების ჩვენება-&gt;mplayer&lt;/b&gt;). პრობლემების შემთხვევაში ამ ჟურნალში შეიძლება იყოს მნიშვნელოვანი ინფორმაცია, ამიტომ რეკომენდირებულია მისი ჩართვა.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>თუ ეს პარამეტრი მონიშნულია, smplayer შეინახავს გამართვის შეტყობინებებს smplayer-ის გამონატანიდან (შეგიძლიათ იხილოთ მენიუში &lt;b&gt;პარამეტრები-&gt;ჟურნალების ჩვენება-&gt;smplayer&lt;/b&gt;). ეს ინფორმაცია შეიძლება იყოს ძალიან მნიშვნელოვანი შემმუშავებლისთვის იმ შემთხვევაში თუ თქვენ პრობლემას აღმოაჩენთ.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>ეს პარამეტრი გაძლევთ smplayer-ის ჟურნალში შესანახი ელემენტების ფილტრაციის საშუალებას. აქ თქვენ შეგიძლიათ მიუთითოთ ნებისმიერი რეგულარული გამოსახულება.&lt;br&gt;მაგალითად: &lt;i&gt;^Core::.*&lt;/i&gt; აჩვენებს მხოლოდ იმ სტრიქონებს რომელიც იწყება როგორც &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>ჩეხური</translation>
    </message>
    <message>
        <source>German</source>
        <translation>გერმანული</translation>
    </message>
    <message>
        <source>English</source>
        <translation>ინგლისური</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>ესპანური</translation>
    </message>
    <message>
        <source>French</source>
        <translation>ფრანგული</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>უნგრული</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>იტალიური</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>იაპონური</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>ქართული</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>ჰოლანდიური</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>პოლონური</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">ბრაზილიური პორტუგალიური</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>რუსული</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>სლოვაკური</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>უკრაინული</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>გამარტივებული ჩინური</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;ავტომატური&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">თურქული</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - პარამეტრები</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">ძირითადი</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>გეზები</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>ძებნა...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>არჩევა...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>ეკრანის ანაბეჭდების შესანახი დასტა:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>გამომყვანი დრაივერები</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>ვიდეო:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>აუდიო:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>პროგრამული ვიდეოეკვალაიზერის გამოყენება</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>პროგრამული ხმის მართვის გამოყენება</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>მედიაპარამეტრები</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>ყველა ფაილის პარამეტრის დამახსოვრება (აუდიო ჩანაწერი, სუბტიტრები...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>არ დაიმახსოვრო მდებარეობა დროში (ფაილების დაკვრა დაიწყება თავიდან)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>ვიდეოს მთელს ეკრანზე გაშვება</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">სუბტიტრები</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>შრიფტი</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>აირჩიეთ შრიფტი რომელიც გამოყენებული იქნება სუბტიტრებისთვის (და OSD-თვის):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF შრიფტი:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>აირჩიეთ...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>სისტემური შრიფტი:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>ზომა</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>ავტომასშტაბირება:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>ავტომასშტაბირების გარეშე</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>ფილმის სიმაღლის პროპორციული</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>ფილმის სიგრძის პროპორციული</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>ფილმის დიაგონალის პროპორციული</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>მასშტაბი:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>ავტოჩატვირთვა</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">პირველი ხელმისაწვდომი სუბტიტრის ავტომატურად არჩევა</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>იგივე სახელი რაც ფილმს აქვს</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>ყველა სუბტიტრი რომელიც შეიცავს ფილმის სახელს</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>ყველა სუბტიტრი დირექტორიაში</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>სუბტიტრების ავტომატურად ჩატვირთვა (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>სუბტიტრების ნაგულისხმები კოდირება:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>SSA/ASS ბიბლიოთეკის გამოყენება სუბტიტრების გამოსახვისთვის</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>ტექსტის ფერი:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>ჩარჩოს ფერი:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">დამატებითი</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>პარამეტრები:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>ვიდეო ფილტრები:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>აუდიო ფილტრები:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>წარმადობა</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>პრიორიტეტი:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>რეალურ დროში</translation>
    </message>
    <message>
        <source>high</source>
        <translation>მაღალი</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>ნორმალურზე მაღალი</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>ნორმალური</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>ნორმალურზე მცირე</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>ყრუ</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>ბუფერის მითითებამ შეიძლება გააუმჯობესოს წარმადობა ნელ მატარებლებზე</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">ბუფერი:</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>კბ</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>კადრების გამოტოვება</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>კადრების მძიმედ გამოტოვება (შეიძლება გამოიწვიოს გამოსახულების დამახინჯება)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>სინქრონიზება</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>აუდიო/ვიდეოს ავტო სინქრონიზება</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>ფარდობა:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">ავტომატური ხარისხი შემდგომი დამუშავების ფილტრისთვის:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">დონე:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">უმცირესი</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">უმაღლესი</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>ხმის ჩანაწერის სწრაფი გადართვა</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>თავებს შორის სწრაფი გადასვლა dvdებში</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(ბუფერი გათიშული იქნება და არ არის გარანტირებული რომ ის ნამვდილად მუშაობს)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>ეკრანმზოგის გათიშვა</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>მონიტორის ფარდობა:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>ძირითადი ფანჯრის ზომის შეცვლის მეთოდი:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>არასდროს</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>როდესაც საჭიროა</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>მხოლოდ ახალი ვიდეოს ჩატვირთვისას</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>სტილი:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>ამძრავები</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>აირჩიეთ თქვენი DVD მოწყობილობა:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>აირჩიეთ თქვენი CD მოწყობილობა:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>გამო&amp;ყენება</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;შეწყვეტა</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>უპირატესი აუდიო და სუბტიტრები</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>სუბტიტრები:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>სუბტიტრების ეკრანის ანაბეჭდებში ჩვენება</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ხატულა</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>აგრეთქე შეგიძლიათ დამატებითი ვიდეოფილრების მითითება.
გამოყავით ისინი &quot;,&quot; სიმბოლოს საშუალებით. არ გამოტოვოთ ადგილი!
მაგალითი: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>და ბოლოს - აუდიოფილრტრები. იგივე წესით როგორც ვიდეოფილრები.
მაგალითი: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>პრიორიტეტი</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>ინტერფეისი</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>გადასვლა</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>ხმა</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>ნაგულისხმები ხმა:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>ფანჯრის ზომა</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>ერთი პროცესი</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>გამოიყენე მხოლოდ გაშვებული SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer მოუსმენს ამ პორტს სხვა პროცესებიდან ბრძანებების მისაღებად:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(ამ ჯგუფში შეტანილი ცვლილებები მოითხოვს SMPlayer-ის გადატვირთვას)</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>წინა ფაილები</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>მაქს. ერთეულები</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>სიის გაწმენდა</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>ენა:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>ხატულების ნაკრები:</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>ამ მომენტში SMPlayer-ს არ შეუძლია cdrom ან dvd მოწყობილობების ამოცნობა. ამიტომ მათ გამოსაყენებლათ საჭიროა მითითება (შეგიძლიათ ერთი და იგივე აირჩიოთ).</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">თაგუნა და კლავიატურა</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">თაგვი</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>ღილაკების ფუნქციები:</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>მარცხენა წკაპი</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>ორმაგი წკაპი</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>თაგვის ბორბლის ფუნქცია:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>გადასვლები მატარებელში</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>ხმის მართვა</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">კლავიატურა</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">ჟურნალები</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>ეს პარამეტრი ძირითადად განკუთვნილია პროგრამის გამართვისათვის.</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">&amp;სუბტიტრები</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">ვიდეო</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">აუდიო</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ხატულა</translation>
    </message>
    <message>
        <source>label</source>
        <translation>დასახელება</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>ეკვალაიზერი</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>კონტრასტი</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>სიკაშკაშე</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>ტონი</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>ინტენსივობა</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>გამა</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;საწყისი პარამეტრები</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>ნაგულის&amp;ხმებად შენახვა</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>მიმდინარე მნიშვნელობების ახალი ვიფდეოებისთვის გამოყენება.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>ყველაფრის ნორმალიზება.</translation>
    </message>
</context>
</TS>
