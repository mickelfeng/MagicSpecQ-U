<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Front-end para o mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Ficheiro a abrir</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Programador</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Aceitar</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Versão: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Versão Qt: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Tradutores:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Alemão</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Eslovaco</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francês</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chinês Simplificado</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Húngaro</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonês</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandês</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraniano</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Português do Brasil</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Checo</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logotipo criado por %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Obtenha actualizações em: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>Acerca do SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 e %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polaco</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Compilado com suporte para o KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Búlgaro</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Sérvio</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chinês Tradicional</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romeno</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Português de Portugal</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Português - Brasil</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Português - Portugal</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Atalho</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Carregar</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Ficheiros de atalhos</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Escolha um nome de ficheiro</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirma a substituição?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>O ficheiro %1 já existe.
Deseja substituí-lo?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Escolha um ficheiro</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>O ficheiro não pode ser guardado</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>O ficheiro não pode ser carregado</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer log</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer log</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>A&amp;brir</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Reproduzir</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Vídeo</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>Á&amp;udio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Legendas</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Navegar</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Opções</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Ficheiro...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>D&amp;irectório...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Lista de reprodução...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD a partir do leitor</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD a partir de uma pasta...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Limpar</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>Ficheiros &amp;recentes</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Reproduzir</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pausa</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Avançar fotograma</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>Velocidade &amp;normal</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Reduzir a metade</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Dobro da velocidade</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Velocidade &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Velocidade &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Velocidade</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>R&amp;epetir</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Ecrã Inteiro</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Modo compacto</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Tamanho</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>A&amp;utodetectar</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;a 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Aspect ratio (Proporção)</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Nenhum</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Desentrelaçar</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Pós-processamento</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetecção de fase</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Adicionar r&amp;uído</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>&amp;Filtros</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizador</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Captura</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>&amp;Manter em cima</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Pista</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extraestéreo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtros</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>Por &amp;defeito</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>E&amp;stéreo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Canais</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>Canal &amp;esquerdo</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>Canal &amp;direito</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Modo estéreo</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Silenciar</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Atraso -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>A&amp;traso +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Seleccionar</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Carregar...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Atraso &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Atraso &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Para cima</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>P&amp;ara baixo</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Título</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Capítulo</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Ângulo</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Lista de reprodução</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Mostrar contador de fotogramas</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Desactivado</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Barra de procura</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Tempo</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Tempo + Tempo t&amp;otal</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Ver logs</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>P&amp;referências</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Acerca de &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>Acerca de &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;vazio&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Listas de reprodução</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Todos os ficheiros</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Escolha um ficheiro</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Informação</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>As unidades de CDROM / DVD ainda não foram configuradas.
O diálogo de configuração irá ser mostrado agora, para que o possa fazer.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Escolha um directório</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Legendas</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Acerca de Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Reproduzindo %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>&amp;Remover ruído</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormal</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Suave</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Reproduzir / Pausa</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pausa / Avançar fotograma</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Descarregar</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Aviso</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>A porta %1 já está a ser utilizada por outro programa.
Não é possivel iniciar o servidor.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>O servidor na porta %1 não responde.
A opção de única instância foi desactivada.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>F&amp;echar</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Ver &amp;informação e propriedades...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reiniciar</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Mover para a &amp;esquerda</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Mover para a &amp;direita</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Mover para &amp;cima</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Mover para &amp;baixo</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Pan &amp;&amp; scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Linha anterior</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>L&amp;inha seguinte</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Diminuir volume (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Aumentar volume (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Sair do Modo de Ecrã Inteiro</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Próximo Nível</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Diminuir contraste</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Aumentar contraste</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Diminuir brilho</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Aumentar brilho</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Diminuir tonalidade</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Aumentar tonalidade</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Diminuir saturação</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Diminuir gamma</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Áudio seguinte</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Legenda seguinte</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Capítulo seguinte</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Capítulo anterior</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Aumentar saturação</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Aumentar gamma</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation>Tamanho duplo</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>&amp;Carregar ficheiro externo...</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normal)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (double framerate)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Próximo</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Anterior</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Normalização de volume</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation>CD &amp;Áudio</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer ainda se encontra aqui</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>&amp;Mostrar ícone na área de notificação</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Ocultar</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Restaurar</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>Ficheiros &amp;recentes</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Sair</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Brilho: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Contraste: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Tonalidade: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Saturação: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Volume: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Bem-Vindo ao SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Legenda</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Lista de reprodução</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>Barra &amp;principal</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>Barra de &amp;idioma</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Barras de ferramentas</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Ocidental</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Ocidental com euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Eslavo/Centro-Europeu</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galego, Maltês, Turco</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Báltico antigo</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cirílico</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Árabe</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Grego moderno</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Báltico</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Céltico</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Hebreu</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ucraniano, Bielo-Russo</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Chinês simplificado</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Chinês tradicional</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japonês</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Coreano</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thai</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Cirílico Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Eslavo/Centro-Europeu Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqSlider</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ícone</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Propriedades do ficheiro</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informação</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Seleccionar o demuxer a ser utilizado neste ficheiro:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reiniciar</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>Codec de &amp;vídeo</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Seleccione o codec de vídeo:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>Codec de á&amp;udio</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Seleccione o codec de áudio:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>Opções do &amp;MPlayer</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Opções:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Também pode passar filtros de vídeo adicionais.
Separe-os com &quot;,&quot;. Não utilizar espaços!
Exemplo: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>Filtros de víd&amp;eo:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>E finalmente os filtros de áudio. Mesma regra utilizada nos filtros de vídeo.
Exemplo: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>&amp;Filtros de áudio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceitar</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>A&amp;plicar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opções Adicionais para o MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Aqui  pode passar opções extra ao MPlayer.
Escrevê-las separadas por espaços.
Exemplo: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Duração</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Artista</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Álbum</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Género</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Pista</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Informação do clip</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Aspect ratio (Proporção)</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Imagens por segundo</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Codec seleccionado</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Pista de áudio inicial</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Qualidade</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Canais</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Pistas de áudio</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>vazio</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Legendas</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Título do Stream</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>URL do Stream</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Escolha um directório</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Reproduzir um DVD a partir de uma pasta</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Pode reproduzir um dvd a partir do seu disco rígido. Simplemente seleccione a pasta que contém os directórios VIDEO_TS e AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Escolha um directório...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Aceitar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Escolha o nome do ficheiro</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirma a substituição?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>O ficheiro já existe.
Deseja substituí-lo?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Erro ao gravar o ficheiro</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Não foi possível gravar o log</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Janela de Log</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Copiar para a área de transferência</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Duração</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Reproduzir</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Listas de reprodução</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Escolha um ficheiro</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Escolha um nome de ficheiro</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirma a substituição?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>O ficheiro %1 já existe.
Deseja substituí-lo?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Todos os ficheiros</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Seleccione um ou mais ficheiros a abrir</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Escolha um directório</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Editar nome</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Escreva o nome que este ficheiro irá ter na lista de reprodução:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Carregar</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Gravar</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Próximo</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Anterior</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Para &amp;cima</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Para &amp;baixo</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Repetir</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>A&amp;leatório</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Adicionar ficheiro &amp;actual</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Adicionar &amp;ficheiro(s)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Adicionar &amp;directório</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Remover &amp;selecção</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Remover &amp;tudo</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Lista de reprodução</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Adicionar...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Remover...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Lista de reprodução modificada</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Existem alterações não guardadas, deseja gravar a lista de reprodução?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Desempenho</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Legendas</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Executáveis</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Todos os ficheiros</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Seleccione o executável do mplayer</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Seleccione um directório</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Tipos de Letra Truetype</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Escolha um ficheiro ttf</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Salto curto</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Salto Médio</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Salto Longo</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Salto com a Roda do Rato</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Aqui pode especificar uma pasta onde as fotografias capturadas pelo smplayer serão guardadas. Se o campo ficar em branco, a função de Captura ficará desactivada.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Seleccione o controlador de saída vídeo. Normalmente xv (linux) e directx (windows) oferecem o melhor desempenho.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Seleccione o controlador de saída áudio.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Pode marcar esta opção se a sua placa gráfica ou controlador de vídeo não suportam o equalizador de vídeo.&lt;br&gt;&lt;b&gt;Nota:&lt;/b&gt; esta opção poder ser incompatível com alguns controladores de saída vídeo.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Marque esta opção para utilizar o misturador por software, em vez de utilizar o misturador da placa de som.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Se marcar esta opção, smplayer reproduzirá todos os ficheiros desde o ínicio.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Se esta opção estiver marcada, todos os vídeos serão iniciados em modo de ecrã inteiro.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Marque esta opção para desactivar a protecção de ecrã durante a reprodução.&lt;br&gt;A protecção de ecrã será activada novamente quando a reprodução terminar.&lt;br&gt;&lt;b&gt;Nota:&lt;/b&gt; Esta opção só funciona em X11 e Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Aqui deve especificar o executável do mplayer que será utilizado pelo smplayer.&lt;br&gt;smplayer requer pelo menos o mplayer 1.0rc1 (svn recomendado).&lt;br&gt;&lt;b&gt;Se esta opção estiver errada, smplayer não será capaz de reproduzir o que seja!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Se marcada, smplayer irá guardar a informação saída do mplayer (pode visualizá-la em &lt;b&gt;Opções-&gt;Ver logs-&gt;mplayer&lt;/b&gt;). Em caso de problemas este log pode conter informação importante, por isso é recomendado manter esta opção activada.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Se esta opção estiver marcada, smplayer irá guardar as mensagens de depuração (debug) que o smplayer emite (pode visualizar o log em &lt;b&gt;Opções-&gt;Ver logs-&gt;smplayer&lt;/b&gt;). Esta informação pode ser útil para o programador no caso de encontrar um problema.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Esta opção permite filtrar as mensagens do smplayer que vão ser guardadas no log. Aqui pode escrever uma expressão regular. &lt;br&gt;Por exemplo: &lt;i&gt;^Core::.*&lt;/i&gt; irá mostrar somente as linhas que começem com &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Nota:&lt;/b&gt; Esta opção é apenas para Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Por defeito</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Estabelece a prioridade do processo mplayer de acordo com as prioridades disponíveis no Windows.&lt;br&gt;&lt;b&gt;AVISO:&lt;/b&gt; Usar a prioridade tempo real pode bloquear o sistema.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Normalmente smplayer irá lembrar-se das opções para cada ficheiro que reproduza (pista de áudio seleccionada, volume, filtros...). Desmarque esta opção se não desejar esta funcionalidade.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Aqui pode introduzir o idioma preferido para a pista de áudio. Quando um vídeo com múltiplas pistas de áudio é encontrado, smplayer tentará usar o seu idioma preferido.&lt;br&gt;Isto só será possível com vídeos que ofereçam informação acerca do idioma das pistas de áudio, tal como DVDs ou ficheiros mkv.&lt;br&gt;Este campo aceita expressões regulares. Exemplo: &lt;b&gt;es|esp|spa&lt;/b&gt; seleccionará a pista de áudio se coincide com &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Aqui pode introduzir o idioma preferido para as legendasio. Quando um vídeo com múltiplas legendas é encontrado, smplayer tentará usar o seu idioma preferido.&lt;br&gt;Isto só será possível com vídeos que ofereçam informação acerca do idioma das legendas, tal como DVDs ou ficheiros mkv.&lt;br&gt;Este campo aceita expressões regulares. Exemplo: &lt;b&gt;es|esp|spa&lt;/b&gt; seleccionará a legenda se coincide com &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Esta opção especifica a quantidade de memória (em kBytes) a utilizar no pré-carregamento de um ficheiro ou URL. Especialmente útil em media lenta.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Saltar alguns fotogramas para manter a sincronização A/V em sistemas lentos.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Perda de fotogramas mais intensa (quebra a descodificação). Leva à distorção da imagem!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Ajusta a sincronização A/V gradualmente baseado em cálculos do atraso áudio.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Altera dinâmicamente o nível de pós-processamento dependendo do tempo de CPU disponível. O número especificado é o nível máximo a utilizar. Normalmente pode escolher um número elevado.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Checo</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Alemão</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Inglês</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Espanhol</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francês</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Húngaro</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonês</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandês</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polaco</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Português do Brasil</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Eslovaco</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraniano</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chinês Simplificado</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Autodetectar&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Búlgaro</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Marcando esta opção é possível reduzir a cintilação, mas também pode fazer com que o vídeo não seja mostrado correctamente.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Grego</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Finlandês</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Esta opção especifica a posição das legendas sobre a janela de vídeo. &lt;i&gt;100&lt;/i&gt; é o fundo, enquanto &lt;i&gt;0&lt;/i&gt; é o topo.</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Sérvio</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chinês Tradicional</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Aqui pode alterar estilos para legendas SSA/ASS. Também pode ajustar a forma como a biblioteca SSA/ASS cria as legendas a partir de ficheiros srt e sub.&lt;br&gt;Exemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Teclado e rato</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Português de Portugal</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romeno</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Português - Brasil</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Português - Portugal</translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Preferências</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceitar</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>A&amp;plicar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Geral</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Caminhos</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Procurar...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Seleccionar...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Pasta para guardar capturas:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Controladores de saída</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Vídeo:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Áudio:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Utilizar equalizador vídeo por software</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Utilizar controle de volume por software</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Opções para o vídeo</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Lembrar as opções para todos os ficheiros (pista de áudio, legendas...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Não lembrar posição anterior (reprodução desde o ínicio)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Iniciar vídeos em modo de ecrã inteiro</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Tipo de Letra</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Seleccione o tipo de letra a usar em legendas (e OSD):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>Tipo de Letra TTF:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Escolha...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Tipo de letra do sistema:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Auto-escala:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Sem auto-escala</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proporcional à altura do filme</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proporcional à largura do filme</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proporcional à diagonal do filme</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Escala:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Carregar automaticamente</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Mesmo nome que o filme</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Todas as legendas contendo o nome do filme</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Todas as legendas no directório</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Autocarregar ficheiros de legendas (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Codificação por defeito das legendas:</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Usar a bibioteca SSA/ASS para desenhar as legendas</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Cor do texto:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Cor do limite:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Incluir legendas nas capturas de ecrã</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opções:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Também pode passar filtros de vídeo adicionais.
Separe-os com &quot;,&quot;. Não utilizar espaços!
Exemplo: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Filtros vídeo:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>E finalmente os filtros de áudio. Mesma regra utilizada nos filtros de vídeo.
Exemplo: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Filtros áudio:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Desempenho</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioridade:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>tempo real</translation>
    </message>
    <message>
        <source>high</source>
        <translation>alta</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>acima do normal</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>abaixo do normal</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>desocupado</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Utilizar uma cache pode melhorar o desempenho em vídeos lentos</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Permitir saltar fotogramas</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Permitir saltar ainda mais fotogramas (pode levar a distorção da imagem)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Sincronização</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Sincronizaçao automática áudio/vídeo</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Factor:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Qualidade automática para filtro de pós-processamento:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Nível:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Mínimo</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Máximo</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Mudança rápida da pista de áudio</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Selecção rápida de capítulos em dvds</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(cache será desactivada e não é garantido que realmente funcione)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Desactivar protecção de ecrã</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Proporção do monitor:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Ajuste do tamanho da janela:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Sempre que necessário</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Só depois de carregar novo vídeo</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Instância única</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Utilizar uma só instância do SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer vai escutar nesta porta comandos de outras instâncias:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(alterações neste grupo requerem que o SMPlayer seja reiniciado)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Estilo:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Actualmente SMPlayer não detecta automaticamente unidades de cdrom ou dvd. Portanto para que seja possível reproduzir cdroms ou dvds é necessário que seleccione a sua unidade de cd e dvd (podem ser a mesma).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ícone</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Seleccione o seu dispositivo CD:</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Seleccione o seu dispositivo DVD:</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Ficheiros recentes</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Máx. entradas</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Limpar lista</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Procura</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Volume por defeito:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Funções do butão:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Duplo clique</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Clique esquerdo</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Tamanho da janela</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Função da roda:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Deslocação pelo vídeo/áudio</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Controle de volume</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Esta opção é principalmente para depurar (debugging) a aplicação.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Idioma:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Conjunto de ícones:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Áudio e legendas preferidas</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Legendas:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Seleccionar o executável do MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Executar o MPlayer na sua própria janela</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opções Adicionais para o MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Aqui  pode passar opções extra ao MPlayer.
Escrevê-las separadas por espaços.
Exemplo: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Seleccione a prioridade do processo MPlayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Guardar os textos de saída do MPlayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Guardar os textos de saída do SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filtro para os logs do SMPlayer:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Não redesenhar o fundo da janela de vídeo</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Aqui pode alterar os atalhos de teclado. Para tal faça duplo clique ou começe a escrever sobre um atalho. Opcionalmente também pode guardar a lista para partilhá-la com outras pessoas ou utilizá-la noutro computador.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Seleccionar a primeira legenda disponível</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Posição por defeito das legendas no ecrã</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Colorkey:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Mudar...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Topo</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Fundo</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Estilos:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Utilizar cache</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS pass-through S/PDIF</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Fim de ficheiro:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>Sem vídeo:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Legendas</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>Utilizar opção -subfont (necessária nas versões mais recentes do MPlayer)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>Biblioteca SSA/&amp;ASS</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>A nova bliblioteca SSA/ASS vai disponibilizar legendas mais vistosas para ficheiros SSA/ASS e pistas Matroska. Também será utilizada para mostrar legendas em outros formatos, como ficheiros SUB e SRT.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Aqui pode alterar estilos para legendas SSA/ASS. Também pode ajustar a forma como a biblioteca SSA/ASS cria as legendas a partir de ficheiros srt e sub. Exemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>&amp;Avançado</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>&amp;Logs</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>Idioma &amp;Mplayer</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>SMPlayer precisa de ler e interpretar as mensagens de saída do MPlayer e por vezes procura textos em Inglês. Se está a utilizar um MPlayer traduzido para outro idioma, então é necessário alterar o texto que o SMPlayer procura. (Tecnicamente deve introduzir expressões regulares)&lt;br&gt;&lt;br&gt;
As listas podem já conter expressões regulares para vários idiomas.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Teclado</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Rato</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation>Zoom vídeo</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation>Max. Amplificação:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation>Normalização de volume</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation>Activar pós-processamento para todos os vídeos</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Qualidade:</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation>Aqui pode alterar estilos para legendas SSA/ASS. Também pode ajustar a forma como a biblioteca SSA/ASS cria as legendas a partir de ficheiros srt e sub. Exemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 segundo</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 segundos</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 minutos</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 minutos e %2 segundos</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 minuto e 1 segundo</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 minuto e %1 segundos</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 minutos e 1 segundo</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ícone</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etiqueta</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Equalizador</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Contraste</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Brilho</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Tonalidade</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Saturação</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reiniciar</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Usar como valores por defeito</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Usa os valores actuais como valores por defeito para os novos vídeos.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Colocar todos os controles a zero.</translation>
    </message>
</context>
</TS>
