<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation type="unfinished">Інтерфейс для mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation type="unfinished">Файл для відкриття</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation type="unfinished">Розробник</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished">&amp;Ok</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation type="unfinished">Версія: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation type="unfinished">Версія Qt: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation type="unfinished">Це вільне програмне забезпечення; Ви можете поширювати його і/чи модифікувати, керуючись 2 чи (на Ваш розсуд) більш пізньою версією GNU General Public License, опібліковану Free Software Foundation.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation type="unfinished">Перекладачі:</translation>
    </message>
    <message>
        <source>German</source>
        <translation type="unfinished">Німецька</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="unfinished">Словацька</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="unfinished">Італійська</translation>
    </message>
    <message>
        <source>French</source>
        <translation type="unfinished">Французька</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation type="unfinished">Спрощена китайська</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished">Російська</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="unfinished">Угорська</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="unfinished">Японська</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="unfinished">Голландська</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="unfinished">Українська</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation type="unfinished">Грузинська</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="unfinished">Чеська</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation type="unfinished">Логотип розроблено %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation type="unfinished">Нові версії шукайте на: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation type="unfinished">Про SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation type="unfinished">%1 та %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="unfinished">Польська</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation type="unfinished">Зібрано з підтримкою KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished">Болгарська</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Турецька</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished">Шведська</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished">Сербська</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished">Традиційна китайська</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished">Румунська</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished">Португальська (Бразилія)</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished">Португальська (Португалія)</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Назва</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Опис</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="unfinished">Комбінація</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished">&amp;Зберегти</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation type="unfinished">&amp;Зчитати</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation type="unfinished">Файли клавіш</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation type="unfinished">Виберіть ім&apos;я файлу</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished">Перезаписати?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished">Файл %1 вже існує.
Перезаписати?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished">Виберіть файл</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Помилка</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished">Не можна зберегти файл</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation type="unfinished">Не можу відкрити файл</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation type="unfinished">SMPlayer - звіти mplayer</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation type="unfinished">SMPlayer - звіти smplayer</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;Відкрити</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation type="unfinished">Від&amp;творення</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="unfinished">&amp;Відео</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation type="unfinished">Зв&amp;ук</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">Су&amp;бтитри</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation type="unfinished">Ог&amp;ляд</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation type="unfinished">&amp;Налаштування</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">До&amp;відка</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation type="unfinished">&amp;Файл...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation type="unfinished">&amp;Тека...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation type="unfinished">&amp;Список...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation type="unfinished">&amp;DVD з диску...</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation type="unfinished">D&amp;VD з теки...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation type="unfinished">Ш&amp;лях...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation type="unfinished">&amp;Очистити</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation type="unfinished">Ос&amp;танні файли</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation type="unfinished">Від&amp;творення</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation type="unfinished">&amp;Пауза</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation type="unfinished">&amp;Стоп</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation type="unfinished">&amp;Крок фрейма</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation type="unfinished">&amp;Нормальна швидкість</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation type="unfinished">&amp;Половинна швидкість</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation type="unfinished">&amp;Подвійна швидкість</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation type="unfinished">Швидкість &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation type="unfinished">Швидкість &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation type="unfinished">Шв&amp;идкість</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation type="unfinished">&amp;Повторити</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished">Н&amp;а весь екран</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation type="unfinished">&amp;Компактний режим</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation type="unfinished">Ро&amp;змір</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation type="unfinished">&amp;Автовизначення</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation type="unfinished">&amp;Співвідношення сторін</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation type="unfinished">&amp;Нічого</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation type="unfinished">&amp;Деінтерлейсинг</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation type="unfinished">&amp;Післяобробка</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation type="unfinished">&amp;Автовизначення фази</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation type="unfinished">Додати ш&amp;ум</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation type="unfinished">Ф&amp;ільтри</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation type="unfinished">&amp;Еквалайзер</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation type="unfinished">Знімок &amp;екрану</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation type="unfinished">З&amp;алишатись зверху</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation type="unfinished">&amp;Доріжка</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation type="unfinished">&amp;Розширене стерео</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation type="unfinished">&amp;Караоке</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation type="unfinished">&amp;Фільтри</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation type="unfinished">&amp;За умовчанням</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation type="unfinished">&amp;Стерео</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation type="unfinished">&amp;4.0 оточення</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation type="unfinished">&amp;5.1 оточення</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation type="unfinished">&amp;Канали</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation type="unfinished">&amp;Лівий канал</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation type="unfinished">&amp;Правий канал</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation type="unfinished">&amp;Стерео режим</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation type="unfinished">&amp;Вимкнути звук</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation type="unfinished">Гучність &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation type="unfinished">Гучність &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation type="unfinished">&amp;Затримка -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation type="unfinished">З&amp;атримка +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation type="unfinished">&amp;Вибрати</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation type="unfinished">&amp;Відкрити...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation type="unfinished">Затримка &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation type="unfinished">Затримка &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation type="unfinished">В&amp;гору</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation type="unfinished">В&amp;низ</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation type="unfinished">&amp;Заголовок</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation type="unfinished">&amp;Глава</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="unfinished">&amp;Ракурс</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation type="unfinished">&amp;Список</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation type="unfinished">&amp;Показати лічильник фреймів</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation type="unfinished">&amp;Вимкнено</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation type="unfinished">&amp;Прогрес</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation type="unfinished">&amp;Час</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation type="unfinished">Час + З&amp;агальний час</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation type="unfinished">Екранна &amp;індікація</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation type="unfinished">&amp;Дивитись звіти</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation type="unfinished">&amp;Налаштування</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished">Про &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation type="unfinished">Про &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation type="unfinished">&lt;нічого&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Відео</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Звук</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation type="unfinished">Список</translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished">Всі файли</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished">Вибрати файл</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation type="unfinished">SMPlayer - Інформація</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation type="unfinished">Приводи CD/DVD еще не налаштовані.
Ви зможете зробити це у діалозі налаштувань цих пристроїв.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation type="unfinished">Вибрати теку</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="unfinished">Субтитри</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="unfinished">Про Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation type="unfinished">Відтворюється %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="unfinished">Пауза</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished">Стоп</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation type="unfinished">Шу&amp;мопридушення</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation type="unfinished">З&amp;вичайне</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation type="unfinished">&amp;Програмне</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation type="unfinished">Грати / Пауза</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation type="unfinished">Пауза / Крок фрейму</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation type="unfinished">В&amp;ивантажено</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation type="unfinished">SMPlayer - Увага</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation type="unfinished">Порт %1 зайнятий іншою програмою.
Запустити сервер неможливо.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation type="unfinished">Сервер на порту %1 не відповідає.
Функцію віддалених запитів буде вимкнено.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation type="unfinished">V&amp;CD...</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished">З&amp;акрити</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation type="unfinished">Дивитсь &amp;інфо та властивості...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation type="unfinished">Масштаб &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation type="unfinished">Масштаб &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">&amp;Скинути</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation type="unfinished">Змістити &amp;вліво</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation type="unfinished">Змістити &amp;вправо</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation type="unfinished">Змістити &amp;вгору</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation type="unfinished">Змістити &amp;вниз</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation type="unfinished">&amp;Панорамування</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation type="unfinished">&amp;Попередний рядок в субтитрах</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation type="unfinished">Н&amp;аступний рядок в субтитрах</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation type="unfinished">Зменшення гучності (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation type="unfinished">Збільшення гучності (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="unfinished">Повноекранний вихід</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="unfinished">Екранна індікація - наступний рівень</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation type="unfinished">Зменшення контрасту</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation type="unfinished">Збільшення контрасту</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation type="unfinished">Зменшення яскравості</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation type="unfinished">Збільшення яскравості</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation type="unfinished">Зменшення кольору</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation type="unfinished">Збільшення кольору</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation type="unfinished">Зменшення насиченості</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation type="unfinished">Зменшення гами</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation type="unfinished">Наступне аудіо</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation type="unfinished">Наступні субтитри</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation type="unfinished">Наступна глава</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation type="unfinished">Попередня глава</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation type="unfinished">Збільшення насиченості</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation type="unfinished">Збільшення гами</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished">Увімкнути подвійний розмір</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished">&amp;Завантажити зовнішній файл...</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished">&amp;Ядерний деінтерлейсер</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished">&amp;Yadif (простий)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished">Y&amp;adif (подвійна частота кадрів)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;Наступний</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">Поп&amp;ередній</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished">Нормалізація &amp;гучності</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished">&amp;Музичний CD</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation type="unfinished">SMPlayer все ще працює тут</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation type="unfinished">В&amp;ідображати іконку в системному треї</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation type="unfinished">&amp;Сховати</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation type="unfinished">&amp;Відновити</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation type="unfinished">&amp;Останні файли</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">&amp;Вихід</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation type="unfinished">Яскравість: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation type="unfinished">Контрастість: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation type="unfinished">Гама: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation type="unfinished">Колір: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation type="unfinished">Насиченість: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation type="unfinished">Гучність: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation type="unfinished">Масштаб: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation type="unfinished">Ласкаво просимо до SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished">Гучність</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Звук</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation type="unfinished">Субтитри</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="unfinished">Список</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation type="unfinished">&amp;Головна панель</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation type="unfinished">&amp;Панель мов</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation type="unfinished">&amp;Панелі</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation type="unfinished">Східна Європа</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation type="unfinished">Східна Європа з Євро</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation type="unfinished">Кирилиця/Центральна Європа</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation type="unfinished">Есперанто, Гальський, Мальтійський, Тюркський</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation type="unfinished">Балтійська стара</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation type="unfinished">Кирилиця</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="unfinished">Арабська</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation type="unfinished">Грецька нова</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Тюркська</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation type="unfinished">Балтійська</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation type="unfinished">Кельтська</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation type="unfinished">Іврит</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished">Російська</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation type="unfinished">Українська, Білоруська</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation type="unfinished">Китайська спрощена</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation type="unfinished">Китайська традиційна</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation type="unfinished">Японська</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation type="unfinished">Корейська</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation type="unfinished">Тайська</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation type="unfinished">Кирилиця Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation type="unfinished">Кирилиця/Центральна Європа Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation type="unfinished">Повзунок еквалайзера</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="unfinished">піктограма</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation type="unfinished">SMPlayer - Властивості файлу</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished">&amp;Інформація</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation type="unfinished">&amp;Демультиплексор</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation type="unfinished">&amp;Виберіть демультиплексор для цього файлу:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">Ск&amp;идання</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation type="unfinished">&amp;Відео кодек</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation type="unfinished">&amp;Виберіть відео кодек:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation type="unfinished">З&amp;вуковий кодек</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation type="unfinished">&amp;Виберіть звуковий кодек:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation type="unfinished">Опції &amp;MPlayer</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation type="unfinished">&amp;Опції:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="unfinished">Ви можете також передати додаткові фильтри відео.
Разділяйте їх комою. Не використовуйте пробіли!
Приклад: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation type="unfinished">Фільтри в&amp;ідео:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="unfinished">Фільтри звука. Використовуються аналогічно фільтрам відео.
Приклад: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation type="unfinished">Фильтри &amp;звуку:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished">&amp;Застосувати</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">В&amp;ідміна</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished">Додаткові опції для MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished">Тут Ви можете передати додаткові опції в MPlayer.
Записуються через пробіли.
Приклад: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation type="unfinished">Головне</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished">Шлях</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Розмір</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation type="unfinished">%1 КБ (%2 МБ)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished">Адреса</translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished">Тривалість</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation type="unfinished">Демультиплексор</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Ім&apos;я</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation type="unfinished">Виконавець</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished">Автор</translation>
    </message>
    <message>
        <source>Album</source>
        <translation type="unfinished">Альбом</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation type="unfinished">Жанр</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Дата</translation>
    </message>
    <message>
        <source>Track</source>
        <translation type="unfinished">Доріжка</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation type="unfinished">Авторське право</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">Примітка</translation>
    </message>
    <message>
        <source>Software</source>
        <translation type="unfinished">Програма</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation type="unfinished">Інформація про кліп</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Відео</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="unfinished">Роздільність екрану</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation type="unfinished">Співвідношення сторін</translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished">Формат</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation type="unfinished">Бітрейт</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation type="unfinished">%1 кб/с</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation type="unfinished">Фреймів за секунду</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation type="unfinished">Вибраний кодек</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation type="unfinished">Початковий звуковий потік</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished">Частота</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation type="unfinished">%1 Гц</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation type="unfinished">Канали</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation type="unfinished">Звукові потоки</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Мова</translation>
    </message>
    <message>
        <source>empty</source>
        <translation type="unfinished">нічого</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="unfinished">Субтитри</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation type="unfinished">Заголовок потоку</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation type="unfinished">Адреса потоку</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation type="unfinished">Вибрати теку</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation type="unfinished">SMPlayer - Відтворити DVD з теки</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation type="unfinished">Ви можете відкрити DVD з жорсткого диску. Виберіть теку, яка містить VIDEO_TS та AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation type="unfinished">Виберіть теку...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished">&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Відміна</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation type="unfinished">Виберіть ім&apos;я файлу для збереження</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished">Перезаписати?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation type="unfinished">Файл існує.
Перезаписати?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation type="unfinished">Помилка збереження файлу</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation type="unfinished">Неможливо зберегти звіт</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation type="unfinished">Вікно звіту</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished">Зберегти</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation type="unfinished">Копіювати до буферу обміну</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Закрити</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Закрити</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Ім&apos;я</translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished">Тривалість</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation type="unfinished">Від&amp;творення</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Редагувати</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Список</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished">Вибрати файл</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation type="unfinished">Виберіть ім&apos;я файлу</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished">Перезаписати?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished">Файл %1 існує.
Перезаписати?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished">Всі файли</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation type="unfinished">Виберіть один чи більше файлів</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation type="unfinished">Вибрати теку</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation type="unfinished">Змінити ім&apos;я</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation type="unfinished">Введіть ім&apos;я, котре буде відповідати у списку цьому файлу:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation type="unfinished">&amp;Загрузити</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished">&amp;Зберегти</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;Наступний</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">По&amp;передній</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation type="unfinished">Змістити &amp;вгору</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation type="unfinished">Змістити &amp;вниз</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation type="unfinished">&amp;Повторювати</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation type="unfinished">П&amp;еремішати</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation type="unfinished">Додати &amp;поточний файл</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation type="unfinished">Додати &amp;файл(и)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation type="unfinished">Додати &amp;теку</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation type="unfinished">Видалити &amp;вибране</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation type="unfinished">Видалити &amp;все</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation type="unfinished">SMPlayer - Список</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation type="unfinished">Додати...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation type="unfinished">Видалити...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation type="unfinished">Список змінено</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation type="unfinished">Зміни в списку не збережено! Ви бажаєте зберегти?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation type="unfinished">Головне</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Диски</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation type="unfinished">Швидкодія</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="unfinished">Субтитри</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="unfinished">Додатково</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation type="unfinished">Шляхи</translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished">Всі файли</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation type="unfinished">Вибрати виконуваний файл mplayer</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation type="unfinished">Вибрати теку</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation type="unfinished">Шрифти Truetype</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation type="unfinished">Вибрати ttf файл</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation type="unfinished">Маленький крок</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation type="unfinished">Средній крок</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation type="unfinished">Довгий крок</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation type="unfinished">Крок колеса миші</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">Нічого</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation type="unfinished">Інтерфейс</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation type="unfinished">Тут Вам потрібно вказати виконуваний файл mplayer, який SMPlayer буде використовувати.&lt;br&gt;SMPlayer потрібна версія mplayer щонайменше 1.0rc1 (рекомендується з svn).&lt;br&gt;&lt;b&gt;Якщо ці налаштування неправильні - SMPlayer не зможе нічого відкрити!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation type="unfinished">Тут Ви можете вказати теку, куди будуть зберігатися скріншоти, зроблені SMPlayer. Якщо це поле буде пустим - функція буде вимкнута.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation type="unfinished">Виберіть драйвер виводження відео. Використання xv (linux) та directx (windows) забезпечує найкращу швидкодію.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation type="unfinished">Виберіть драйвер виводження звуку.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation type="unfinished">Ви можете спробувати ці опції, якщо відеоеквалайзер не підтримується Вашою відеокартою чи вибраним драйвером виводження відео.&lt;br&gt;&lt;b&gt;Пам&apos;ятайте:&lt;/b&gt; ці опції можуть бути несумісними з деякими драйверами виводження відео.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation type="unfinished">Перевірте ці опції для використання програмного мікшера замість апаратного мікшера звукової карти.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation type="unfinished">Якщо ви виберете цю опцію - SMPlayer буде відтворювати всі файли з початку.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation type="unfinished">Якщо Ви виберете цю опцію - всі відеофайли будуть стартувати на весь екран.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation type="unfinished">Виберіть цю опцію для придушення скрінсейверу при відтворенні.&lt;br&gt;Скрінсейвер буде ініційовано знову після зупинки.&lt;br&gt;&lt;b&gt;Пам&apos;ятайте:&lt;/b&gt; Ця опція працює тільки для X11 та Windows.</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation type="unfinished">Якщо увімкнено - SMPlayer буде зберігати повідомлення mplayer (їх можна побачити у &lt;b&gt;Налаштування-&gt;Дивитись звіти-&gt;mplayer&lt;/b&gt;). У випадку проблем ці звіти можут містити важливу інформацію, так що рекомендується увімкнути.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation type="unfinished">Якщо увімкнено - SMPlayer буде зберігати свої налагоджувальні повідомлення (їх можна побачити у &lt;b&gt;Налаштування-&gt;Дивитись звіти-&gt;smplayer&lt;/b&gt;). Ця інформація може бути корисною для розробника, якщо Ви знайдете помилку.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation type="unfinished">Ця опція дозволяє фільтрувати повідомлення smplayer, які будуть збережені у звіті. Тут Ви можете написати будь-який регулярний вираз.&lt;br&gt;Наприклад: &lt;i&gt;^Core::.*&lt;/i&gt; відобразить лише строки, що починаються з &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation type="unfinished">&lt;br&gt;&lt;b&gt;Примітка:&lt;/b&gt; Ці опції тільки для Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished">За умовчанням</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation type="unfinished">Вкажіть пріоритет для процесу mplayer, доступний для Windows.&lt;br&gt;&lt;b&gt;УВАГА:&lt;/b&gt; Використання пріоритету реального часу може заморозити систему.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation type="unfinished">Звичайно SMPlayer запам&apos;ятовує налаштування для кожного файлу, який ви відкриваєте (вибрана звукова доріжка, гучність, фільтри і т.п.). Вимкніть це, якщо Вам таке не потрібно.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished">Тут Ви можете вказати мову для звукових доріжок. При знаходженні звукових доріжок SMPlayer буде намагатися використовувати вказану Вами мову.&lt;br&gt;Це працює тільки для форматів, які надають інформацію про мови для звукових доріжок, такі як DVD чи mkv файли.&lt;br&gt;Приймаються регулярні вирази. Приклад: &lt;b&gt;es|esp|spa&lt;/b&gt; призначить звукову доріжку, яка відповідатиме &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; чи &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished">Тут Ви можете вказати мову для звукових субтитрів. При знаходженні субтитрів для SMPlayer привілейованою буде вказана Вами мова.&lt;br&gt;Це працює тільки для форматів, які надають інформацію про мови для субтитрів, такі як DVD чи mkv файли.&lt;br&gt;Приймаються регулярні вирази. Приклад: &lt;b&gt;es|esp|spa&lt;/b&gt; призначить звукову доріжку, яка відповідатиме &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; чи &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation type="unfinished">Ця опція вказує розмір (в кілобайтах) пам&apos;яті, що відводиться для кешування файлів чи URL. Корисно для повільних медіа.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation type="unfinished">Пропускати деякі фрейми для забезпечення A/V синхронізації на повільних системах.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation type="unfinished">Збільшене випадання фреймів (декодуванняз переривами). Призводить до спотворення картинки!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation type="unfinished">Поступове регулювання A/V синхронізації, основане на розмірах звукових затримок.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation type="unfinished">Динамічна зміна рівня післяобробки в залежності від вільного процесорного часу. Число, яке Ви вкажете. буде використано як максимальний рівень. Звичайно можка вказати досить велике значення.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="unfinished">Чеська</translation>
    </message>
    <message>
        <source>German</source>
        <translation type="unfinished">Німецька</translation>
    </message>
    <message>
        <source>English</source>
        <translation type="unfinished">Англійська</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation type="unfinished">Іспанська</translation>
    </message>
    <message>
        <source>French</source>
        <translation type="unfinished">Французька</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="unfinished">Угорська</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="unfinished">Італійська</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="unfinished">Японська</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation type="unfinished">Грузинська</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="unfinished">Голландська</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="unfinished">Польська</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished">Російська</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="unfinished">Словацька</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="unfinished">Українська</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation type="unfinished">Спрощена китайська</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation type="unfinished">&lt;Авто&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished">Болгарська</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation type="unfinished">Ця опція може зменшити мерехтіння, але може призвести до того, що зображення буде показане не відповідним чином.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Турецька</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="unfinished">Грецька</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="unfinished">Фінська</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished">Шведська</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="unfinished">Ця опція вказує позицію субтитрів на вікні відео. &lt;i&gt;100&lt;/i&gt; задає в самому низу, тоді як &lt;i&gt;0&lt;/i&gt; задає самий верх.</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished">Сербська</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished">Традиційна Китайська</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished">Тут Ви можете задати стилі для субтитрів SSA/ASS. Це можна використати також для точного настроювання вигляду srt та sub субттрів бібліотекою SSA/ASS.&lt;br&gt;Приклад: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished">Клавіатура та миша</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished">Румунська</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished">Португальська (Бразилія)</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished">Португальська (Португалія)</translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation type="unfinished">SMPlayer - Переваги</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Головне</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation type="unfinished">Шляхи</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation type="unfinished">Пошук...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation type="unfinished">Вибір...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation type="unfinished">Тека для збереження знімків:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation type="unfinished">Пристрій виведення</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation type="unfinished">Відео:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Звук:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation type="unfinished">Використовувати програмний еквалайзер відео</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation type="unfinished">Використовувати програмний контроль гучності</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation type="unfinished">Налаштування медіа</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation type="unfinished">Запам&apos;ятати налаштування для всіх файлів (звукові доріжки, субтитри...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation type="unfinished">Не запам&apos;ятовувати позицію часу (файли стартують з початку)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation type="unfinished">Відкривати відео на весь екран</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation type="unfinished">Включати субтитри у знімки екрану</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation type="unfinished">Виберіть шрифт для субтитрів (та OSD):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>Шрифт TTF:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation type="unfinished">Вибір...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation type="unfinished">Системний шрифт:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Розмір</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation type="unfinished">Автомасштабування:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation type="unfinished">Без автомасштабування</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation type="unfinished">Пропорційно до висоти клипу</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation type="unfinished">Пропорційно до ширини клипу</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation type="unfinished">Пропорційно до діагоналі клипу</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Масштаб:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation type="unfinished">Автовідкриття</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation type="unfinished">Така ж назва як і у кліпа</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation type="unfinished">Підключати субтитри, які містять назву кліпу</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation type="unfinished">Всі субтитри теки</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation type="unfinished">Автозавантаження субтитрів (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation type="unfinished">Кодування субтитрів за умовчанням:</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation type="unfinished">Використовувати бібліотеку SSA/ASS для рендерингу субтитрів</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation type="unfinished">Колір тексту:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation type="unfinished">Колір краю:</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation type="unfinished">Опції:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation type="unfinished">Фільтри відео:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation type="unfinished">Фільтри звуку:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation type="unfinished">Переваги</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation type="unfinished">Пріоритет:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation type="unfinished">реальний час</translation>
    </message>
    <message>
        <source>high</source>
        <translation type="unfinished">високий</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation type="unfinished">вище звичайного</translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="unfinished">звичайний</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation type="unfinished">нижче звичайного</translation>
    </message>
    <message>
        <source>idle</source>
        <translation type="unfinished">низький</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation type="unfinished">Установки кешу можуть поліпшити чи погіршити швидкодію</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>Кб</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation type="unfinished">Допускати випадання фреймів</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation type="unfinished">Допускати жорстке випадання фреймів (може спотворити картинку)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation type="unfinished">Синхронізація</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation type="unfinished">Автосинхронізація звука/відео</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation type="unfinished">Показник:</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation type="unfinished">Швидке перемикання звукових доріжок</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation type="unfinished">Швидкий пошук глав у DVD</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation type="unfinished">(кеш повинен бути вимкнений, інакше нормальна робота не гарантується)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation type="unfinished">Придушити скринсейвер</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation type="unfinished">Співвідношення сторін монітору:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation type="unfinished">Метод зміни разміру головного вікна:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished">Ніколи</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation type="unfinished">Коли це потрібно</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation type="unfinished">Тільки після відкриття нового відео</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Стиль:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation type="unfinished">Пристрої</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation type="unfinished">Виберіть Ваш DVD пристрій:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation type="unfinished">Виберіть Ваш CD пристрій:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>O&amp;K</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished">&amp;Застосувати</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">В&amp;ідміна</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="unfinished">Тут Ви можете передати додаткові фільтри відео.
Разділяти комою. Не використовувати пробіли!
Приклад: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="unfinished">Фільтри звуку. Використовуються аналогічно фільтрам відео.
Приклад: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation type="unfinished">Віддалені запити</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation type="unfinished">Використовувати тільки один запит SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation type="unfinished">SMPlayer буде очікувати на команди зовнішніх запитів з цього порта:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation type="unfinished">(ця група змін потребє перезапуску SMPlayer)</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation type="unfinished">На даний час SMPlayer не вміє самостійно знаходити cd чи dvd приводи. Для програвання cd чи dvd Ви маєте вказати шлях до відповідних приводів (може бути те ж саме).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="unfinished">піктограма</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation type="unfinished">Останні файли</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation type="unfinished">Макс. пам&apos;ятати</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation type="unfinished">Очистити список</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation type="unfinished">Пошук</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished">Гучність</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation type="unfinished">Гучність за умовчанням:</translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation type="unfinished">Кнопки функцій</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation type="unfinished">Подвійний клік</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation type="unfinished">Клік лівою</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation type="unfinished">Розмір вікна</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation type="unfinished">Ці опції, головним чином, потрібні щоб відладити програму.</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation type="unfinished">Інтерфейс</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation type="unfinished">Функції колеса:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation type="unfinished">Прокрутка</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation type="unfinished">Гучність</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Мова:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation type="unfinished">Набір піктограм:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation type="unfinished">Переважні аудіо та субтитри</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation type="unfinished">Субтитри:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished">Пріоритет</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation type="unfinished">Виберіть виконуваний файл MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation type="unfinished">Запускати MPlayer в окремому вікні</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished">Додаткові опції для MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished">Тут Ви можете передати додаткові опції для MPlayer.
Розділяються пробілами.
Приклад: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="unfinished">Вкажіть пріоритет процесу MPlayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation type="unfinished">Вихідний звіт MPlayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation type="unfinished">Вихідний звіт SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation type="unfinished">Фільтр для звітів SMPlayer:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation type="unfinished">Не перемальовувати фон вікна відео</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="unfinished">Тут Ви можете змінити комбінації клавіш. Клацніть двічі та вкажіть комбінацію у відповідному чарунку. Також можна вільно зберегти ці налаштування для використання на іншому комп&apos;ютері.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="unfinished">Вибрати перші доступні субтитри</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished">Позиція</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation type="unfinished">Позиція субтитрів на екрані за замовчанням</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation type="unfinished">Ключ кольору:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation type="unfinished">Змінити...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished">Верх</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="unfinished">Низ</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation type="unfinished">Стилі:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished">Кеш</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished">Використовувати кеш</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished">Розмір:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished">Передача AC3/DTS на S/PDIF</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished">Кінець файлу:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished">Без відео:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">&amp;Субтитри</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished">Використовувати опцію -subfont (потрібен для останніх релізів MPlayer)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished">Бібліотека SSA/&amp;ASS</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished">Нова бібліотека SSA/ASS забезпечує хорошу стилізацію субтитрів для зовнішніх файлів субтитрів SSA/ASS та треків Matroska. Але це також буде використовуватись для рендерінгу файлів інших форматів, таких як SUB та SRT.</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished">&amp;Додатково</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished">&amp;Звіти</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished">Мова &amp;MPlayer</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished">SMPlayer повинен зчитати та розібрати вивід MPlayer, який як правило англійською мовою. Якщо у Вас MPlayer перекладений іншою мовою - Ви повинні змінити відображення тексту для SMPlayer. (Технічно Ви повинні вказати регулярний вираз)&lt;br&gt;&lt;br&gt;
Випадаючі списки можуть надавати готові регулярні вирази для різних мов.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished">&amp;Клавіатура</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished">&amp;Миша</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished">Масштаб відео</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Відео</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Звук</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished">Максимальне підсилення:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished">Нормалізація гучності</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished">Увімкнути післяобробку для всіх відеофайлів</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished">Якість:</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished">Тут Вы можете вказати стилі для субтитрів SSA/ASS. Також може використовуватися для точного налаштування відображення субтитрів SRT і SUB библиотекою SSA/ASS. Приклад: &lt;b&gt; Bold=1, Outline=2, Shadow=4 &lt;/b&gt; {2 or 4?}</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation type="unfinished">1 секунда</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation type="unfinished">секунд: %1</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation type="unfinished">хвилин: %1</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation type="unfinished">хвилин: %1, секунд: %2</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation type="unfinished">1 хвилина</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation type="unfinished">1 хвилина та 1 секунда</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation type="unfinished">1 хвилина, секунд: %1</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation type="unfinished">хвилин: %1, 1 секунда</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation type="unfinished">Пошук (головне)</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="unfinished">піктограма</translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished">мітка</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation type="unfinished">Еквалайзер</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation type="unfinished">Контрастність</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation type="unfinished">Яскравість</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation type="unfinished">Колір</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation type="unfinished">Насиченість</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation type="unfinished">Гама</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">Об&amp;нулити</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation type="unfinished">&amp;Встановити значення за умовчанням</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation type="unfinished">Використовувати поточні значення як за умовчанням для нових кліпів.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation type="unfinished">Скинути все на нуль.</translation>
    </message>
</context>
</TS>
