<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Графички интерфејс за mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Отвори фајл</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Програмер</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Потврди</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Верзија %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt Верзија %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Овај програм је бесплатан софтвер; можете га редистрибуирати и/или модификовати под условима GNU GPL лиценце објављене од стране Фондације Слободног Софтвера, било да је верзија 2 лиценце или било која наредна верзија.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Преводиоци:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Немачки</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Словачки</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Италијански</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Француски</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Упрошћени-Кинески</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Руски</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Мађарски</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Јапански</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Холандски</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Украински</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Бразилски Португалски</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Грузијски</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Чешки</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Лого дизајнирао: %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Скини нову верзију са: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>О SMPlayer-у</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 и %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Пољски</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Компајлиран са подршком за KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Бугарски</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Турски</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Шведски</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Српски</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Опис</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Пречица</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Save</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Load</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Кључни фајлови</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Изабери име фајла</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Потврди преписивање?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Фајл %1 већ постоји
Да ли желите да га препишеш?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Изабери фајл</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Грешка</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Фајл не може да се сачува</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Фајл не може да се учита</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer лог</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer лог</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Отвори</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Пусти</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Видео</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Аудио</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Превод</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Изабери</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>Оп&amp;ције</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Помоћ</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Фајл...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>Д&amp;иректоријум...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Плејлиста...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD са уређаја</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD из фолдера...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;Интернет адреса...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Обриши</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Отварани фајлови</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>П&amp;усти</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Пауза</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Заустави</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Фрејм по фрејм</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Нормална брзина</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Дупло спорије</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Дупло брже</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Брзина &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Брзина &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>Бр&amp;зина</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Понављај</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Цео екран</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Компактан облик</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>Ве&amp;личина</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Аутодетектовање</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Коверат</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 К&amp;оверат</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Панскен</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;to 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Задржи однос</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Искључено</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Нископропусни5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Линеарност &amp;Мешање</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Уклони линије</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Постпроцес</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Аутодетектовање фазе</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Деблокирање</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>Де&amp;прстеновање</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Додај ш&amp;ум</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>Ф&amp;илтри</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Еквилајзер</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Сликај екран</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>О&amp;стани на врху</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Изабери аудио</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Есктрастерео</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Караоке</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Филтри</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;Стандардно</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Стерео</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4,0 Тоне</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5,1 Tone</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Канали</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Леви канал</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Десни канал</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Врста стереа</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Искључи тон</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Јачина &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Јачина &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Кашњење</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>П&amp;редњачење</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Изабери</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Учитај...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Кашњење &amp;</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Предњачење &amp;</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Горе</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;Доле</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Језик</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Поглавље</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Угао</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Плејлиста</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Прикажи бројач фрејмова</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Искључено</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Бар за тражење</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Време</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Време + У&amp;купно време</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Види логове</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>П&amp;одешавања</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>О &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>О &amp;SMPlayer-у</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Аудио</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Плејлиста</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Сви фајлови</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Изабери фајл</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - информација</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM / DVD нису конфигурисани
Дијалог за конфигурисање ће сада бити приказан,
па можеш сада да конфигуришеш уређаје. </translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Изабери директоријум</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Превод</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>О  Qt-у</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Тренутно пушта %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Паузирај</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Заустави</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>Ук&amp;лони шум</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>Н&amp;ормалан</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Слаб</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Пусти / Паузирај</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Пауза / Фрејм по фрејм</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>Од&amp;читај</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Упозорење</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Порт %1 користи нека друга апликација
Сервер не може да се стартује.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Сервер на порту %1 не одговара
Опција једног старта је онемогућена.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Искључи</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>З&amp;атвори</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Погледај &amp;инфо и карактеристике...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Зум &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Зум &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Ресетуј</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Помери &amp;лево</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Помери &amp;десно</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Помери &amp;горе</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Помери &amp;доле</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Пан &amp;&amp; скен</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Претходна линије у преводу</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>С&amp;ледећа линија у преводу</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Смањи тон (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Појачај тон (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Искључи опцију Цео Екран</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Следећи ниво</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Смањи контраст</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Повећај Контраст</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Смањи осветљај</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Повећај осветљај</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Смањи боју</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Појачај боју</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Смањи засићење</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Повећај засићење</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Смањи гама</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Повећај гама</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Следећи аудио фајл</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Следећи превод</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Следеће поглавље</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Претходно поглавље</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;Следећа</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">Прет&amp;ходна</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer овде и даље ради</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>П&amp;рикажи икону у систем треју</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Сакри</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Покажи</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Отварани фајлови</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">&amp;Искључи</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Осветљај: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Контраст: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Гама: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Боја: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Засићеност: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Јачина тона: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Зум: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Добродошли у SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Јачина тона</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Аудио</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Превод</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Плејлиста</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Главни алатке</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Алатке за језик</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Алатке</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Западно Европски Језици</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Западно Европски Језици са Евро Знаком</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Словенски/Централно Европски Језици</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Есперанто, Галски, Малтезе, Турски</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Стари Балтички сет карактера</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Ћирилица</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Арапски</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Модерни Грчки</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Турски</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Балтички</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Келтски</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Хебрејски сет карактера</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Руски</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Украински, Белоруски</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Упрошћени Кинески сет карактера</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Традиционални Кинески сет карактера</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Јапански сет карактера</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Корејски сет карактера</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Тајландски сет карактера</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Ћирилица Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Словенски/Централно Европски Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>ЕкКлизач</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>икона</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Карактеристике фајла</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Информација</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Демултиплексер</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Изабери демултиплексер за овај фајл:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Ресетуј</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;Видео кодек</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Изабери видео кодек:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>А&amp;удио кодек</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Изабери аудио кодек:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>&amp;Опције MPlayer-а</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Опције:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Такође можеш да ставиш додатне видео филтре
Раздвоји их са &quot;,&quot;. Не користи размак!
Пример: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>В&amp;идео филтри:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>И коначно аудио филтри: Исто важи као за видео филтре
Пример: Example: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>Аудио &amp;филтри:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Потврди</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Примени</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Откажи</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Додатне опције за MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Овде можеш да ставиш још опција за MPlayer
Пиши их са размаком
Пример: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Опште</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Путања</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Величина</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Интернет адреса</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Дужина</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Демултиплексер</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Уметник</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Аутор</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Албум</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Датум</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Снимак</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Права копирања</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Софтвер</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Информација о снимку</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Резолуција</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Пропорција</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Брзина протока</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Фрејмова по секунди</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Изабран кодек</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Почетни аудио стрим</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Однос</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Канали</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Аудио стримови</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Језик</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>празно</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Превод</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>891983</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>1</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Име стрима</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>Интернет адреса стрима</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Изабери директоријум</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Пусти DVD из фолдера</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Можеш да пушташ DVD из фолдера. Само изабери фолдер у коме су VIDEO_TS и AUDIO_TS фолдери.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Изабери фолдер...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Потврди</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Откажи</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Изабери има под којим ћеш да сачуваш</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Потврди преписивање?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Фајл постоји
Да ли желиш да га препишеш?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Грешка при чувању фајла</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Лог не може да се сачува</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Прозор за логове</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Сачувај</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Копирај у клипборд</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Затвори</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Затвори</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Дужина</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Пусти</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Едитуј</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Плејлиста</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Изабери фајл</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Изабери име фајла</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Потврди преписивање?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Фајл %1 постоји.
Да ли желиш да га препишеш?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Сви фајлови</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Изабери један или више фајлова да отвориш</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Изабери фолдер</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Едитуј име</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Откуцај име које ће бити приказано у плејлисти за овај фајл:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Учитај</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Сачувај</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Следећа</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>Прет&amp;ходна</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Помери &amp;горе</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Помери &amp;доле</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Понављај</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>Н&amp;асумично</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Додај &amp;тренутни фајл</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Додај &amp;фајл(ове)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Додај &amp;фолдер</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Уклони &amp;селектоване</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Уклони &amp;све</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Плејлиста</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Додај...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Уклони...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Плејлиста је модификована</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Несачуване промене, да ли желиш да сачуваш плејлисту?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Опште</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Уређаји</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Перформансе</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Превод</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Напредне опције</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Извршне датотеке</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Сви фајлови</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Изабери извршну датотеку за MPlayer</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Изабери фолдер</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype фонтови</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Изабери ttf фајл</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Кратак скок</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Средњни скок</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Дугачак скок</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Скок точком миша</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ништа</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Интерфејс</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Миш и тастатура</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Овде можеш да изабереш фолдер у који ће бити смештени слике екрана. Ако је ово поље празно сликање екрана ће бити онемогућено.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Изабери излазни видео драјвер. Обично xv (linux) и directx (windows) дају најбоље перформансе.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Изабери излазни аудио драјвер.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Штиклирај ову опцију ако видео еквилајзер није подржан твојом графичком картицом или изабраним излазним видео драјвером &lt;br&gt;&lt;b&gt;Упозорење:&lt;/b&gt; ова опција може бити некомпатибилна са неким графичким картицама.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Штиклирај ову опцију да би користио софтверски миксер, уместо миксера звучне картице.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Ако штиклираш ову опцију, smplayer ће пуштати све фајлове од почетка.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Ако је ова опција штиклирана, све ће бити пуштано на целом екрану.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Штиклирај ову опцију да би онмогућио чувара екрана док се пушта видео. &lt;br&gt;Чувар екрана ће опет радити када се видео заустави.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt;. Ова опција ради само на X11 и на Windows-у.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Овде мораш да ставиш извршну mplayer датотеку за smplayer.&lt;br&gt;smplayer захтева најмање mplayer 1.0rc1 (препоручује се svn).&lt;br&gt;&lt;b&gt;Ако је ово подешавање погрешно, smplayer неће моћи ништа да пушта!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Ако је ово штиклирано, smplayer ће чувати излаз mplayer-а (а можеш га видети у &lt;b&gt;Опције-&gt;Види логове-&gt;mplayer&lt;/b&gt;). У случају проблема овај лог може да садржи важне информације, зато је препоручљиво да ова опција буде штиклирана.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Ако је ова опвија штиклирана, smplayer ће чувати поруке за дебаговање које smplayer даје за излаз (можеш их видети у &lt;b&gt;Опције-&gt;Види логове-&gt;smplayer&lt;/b&gt;). Ове информације могу да буду корисне за програмере уколико се појавио баг.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Ова опција служи за филтрирање порука smplayer-а које се чувају у логовима. Овде можеш да пишеш било које правилно изражавање..&lt;br&gt;На пример: &lt;i&gt;^Core::.*&lt;/i&gt; ће приказати само линије које почињу са &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Логови</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Упозорење:&lt;/b&gt; Ова опција је само за Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Основно</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Постави приоритет процеса за mplayer према предефинисаним приоритетима у Windows-u.&lt;br&gt;&lt;b&gt;ПАЖЊА:&lt;/b&gt; Употреба realtime приорите може да заглави систем.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Обично smplayer ће запамтити подешавања за сваки фајл који пушташ (изабран аудио фајл, јачина тона, филтри...). Одштиклирај ову опцију ако не желиш да smplayer памти подешавања.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Овде можеш да упишеш свој жељени језик за аудио стрим. Када убациш медиј са вишеструким аудио стримовима, smplayer ће покушати да користи твој жељени језик.&lt;br&gt;Ово само ради са медијима коју имају информацију о аудио стриму, ако што су DVD или mkv фајлови.&lt;br&gt;Ово поље прихвата правилно изражавање. Пример: &lt;b&gt;es|esp|spa&lt;/b&gt;ће селектовати аудио који се поклапа са &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Овде можеш да упишеш свој жељени језик за превод. Када убациш медиј са вишеструким аудио стримовима, smplayer ће покушати да користи твој жељени језик.&lt;br&gt;Ово само ради са медијима коју имају информацију о аудио стриму, ако што су DVD или mkv фајлови.&lt;br&gt;Ово поље прихвата правилно изражавање. Пример: &lt;b&gt;es|esp|spa&lt;/b&gt;ће селектовати аудио који се поклапа са &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Овом опцијом се наводи колико меморије (у килобајтима) може да се користи за прекеширање фајла или интернет адресе. Посебно је користно за споре медијуме.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Прексочи приказивање неких фрејмова да би задржао Аудио/Видео синхронизацију на спорим системима.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Интензивније испадање фрејмова (прекида/квари декодовање). Доводи до изобличења слике!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Постепено подешавање Аудио/Видео синхронизације базирано на мерењу аудио кашњења.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Динамички мења ниво постпроцесирања у зависности од слободног времена процесора. Број који ставиш ће бити највећи могући који ће се користити. Обично можеш да се користи неки велики број.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Чешки</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Немачки</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Енглески</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Шпански</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Француски</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Мађарски</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Италијански</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Јапански</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Грузијски</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Холандски</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Пољски</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Бразилски Португалски</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Руски</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Словачки</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Украјински</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Упрошћени-Кинески</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Autodetect&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Бугарски</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Штиклирање ове опције може да се редукује треперење, али такође може да се деси да се видео не прикаже ваљано.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Турски</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Грчки</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Фински</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Шведски</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Ова опција одређује место превода на екрану. &lt;i&gt;100&lt;/i&gt; значи на дну, док  &lt;i&gt;0&lt;/i&gt; значи на врху.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Овде можете да поништите стилове за SSA/ASS превод. Ово такође може да се користи за фино подешавање рендеровања srt и sub превода коришћењем SSA/ASS библиотеке. &lt;br&gt;Пример: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Српски</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Опције</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Потврди</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Примени</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Откажи</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Опште</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Путање</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Тражи...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Изабери...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Фолдер за чување слика екрана:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Излазни драјвери</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Видео:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Аудио:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Користи софтверски видео еквилајзер</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Користи софтверску контролу јачине тона</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Опције медија</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Запамти подешавања за све фајлове (аудио, превод...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Не памти позицију времена (фајлови се пуштају од почетка)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Стартуј видео на целом екрану</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Превод</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Фонт</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Изабери фонт који ће бити коришћен за превод (и OSD):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF фонт:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Изабери...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Системски фонт:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Величина</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Аутоматска величина:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Без аутоматске величине</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Пропорционално са висином видеа</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Пропорционално са ширином видеа</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Пропорционално са дијагоналом видеа</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Величина:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Аутоматско учитавање</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Аутомаски изабери први доступан превод</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Исто име као и видео фајл</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Сви преводи садрже име видео фајла</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Сви преводи у фолдеру</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Аутоматски учитај фајлове превода (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Основни енкодинг за превод:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Користи SSA/ASS библиотеку за исцртавање превода</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Боја текста:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Боја ивице:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Превод видљив на сликама екрана</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Напредне опције</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Опције:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Можеш такође да ставиш додатне филтре
Раздвоји их са &quot;,&quot;. Не користи размак!
Пример: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Видео филтри:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>И коначно аудио филтри. Исто важи као и за видео филтре
Пример: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Аудио филтри:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Перформансе</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Приоритет:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>реално време</translation>
    </message>
    <message>
        <source>high</source>
        <translation>високо</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>изнаднормале</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>нормално</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>исподнормале</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>слободно време</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Подешавање кеша може да побпљша перформасе на спорим мидијима</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Кеш:</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Допусти испадање фрејмова</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Допусти велико испадање фрејмова (може да доведе до изобличења слике)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Синхронизација</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Аудио/Видео аутоматска синхронизација</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Фактор:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Аутоматски квалитет за постпроцес филтар:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Ниво:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Најнижи</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Највиши</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Брза промена аудиа</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Брзо тражење поглавља у dvd-јевима</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(кеш ће бити онемоућен и није гарантовано да ће заиста радити)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Онемогући чувара екрана</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Пропорциналност монитора:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Метода за ширење главног прозора:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Никад</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Кад год је потребно</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Само после учитавања новог видеа</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Један старт програма</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Користи само један стартован SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPLayer ће слушати овај порт и примати команде од других стартованих SMPlayer-а:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(промене у овој групи захтевају да се рестартује SMPlayer)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Стил:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Уређаји</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Тренутно SMPLayer не може аутоматски да детектује DVD или CD уређаје. Да би пуштали са DVD или CD морате изабрати уређаје (нема разлике дал је CD или DVD).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>икона</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Изабери CD уређај:</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Изабери DVD уређај:</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Отварани фајлови</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Макс. ствари</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Обриши листу</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Тражење</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Јачина тона</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Основна јачина:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Миш</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Функције дугмета:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Дупли клик</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Леви клик</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Величина прозора</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Интерфејс</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Фунцкија точка:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Тражење кроз медијум</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Контрола тона</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Миш и тастартура</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Тастатура</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Логови</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Ова опција служи са дебаговање апликације.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Језик:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Група икона:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Жељени аудио стрим и превод</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Превод:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Изабери извршну датотеку за MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Стартуј MPlayer у посебном свом прозору</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Додатне опције за MPLayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Овде можеш да ставиш додатне опције за MPlayer.
Пиши их са размаком.
Пример: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Изабери приоритет за MPlayer процес.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Логуј излаз MPlayer-a</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Логуј излаз SMplayer-a</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Филтер за SMPlayer логове:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Не исцртавај поново позадину видео прозора</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Овде можеш да промениш било коју пречицу на тастатури. Можеш дуплим кликом или куцањем преко ћелије пречице. Опционо можеш да сачуваш листу и да је учиташ на другом неком рачунару.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Изабери први доступан превод</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Позиција</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Основна позиција превода на екрану</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Врх</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Дно</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Стилови:</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>КључнаБоја:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Промени...</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">&amp;Превод</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Видео</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Аудио</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 секунда</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 секунди</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 минута</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 минута и %2 секунди</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 минут</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 минут и 1 секунда</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 минут и %1 секунди</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 минута и 1 секунда</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>ОсновниПрозорТражења</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>икона</translation>
    </message>
    <message>
        <source>label</source>
        <translation>назив</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Еквилајзер</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Контраст</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Осветљај</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Боја</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Засићеност</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Гама</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Ресетуј</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Постави основне вредности</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Користи тренутно вредности као основне за нове видео фајлове.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Постави све контроле на нула.</translation>
    </message>
</context>
</TS>
