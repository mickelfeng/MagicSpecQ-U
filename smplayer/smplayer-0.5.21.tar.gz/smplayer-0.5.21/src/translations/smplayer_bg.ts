<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Обвивка за mplayer</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Разработчик</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Файл за отваряне</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>About SMPlayer</source>
        <translation>Относно SMPlayer</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Добре</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Версия: %1</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Компилиран с KDE поддръжка</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt версия: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Тази програма е с отворен код; вие можете да я разпространявате, променяте и допълвате под GNU лиценза.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Преводачи:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Немски</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Словашки</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Италиански</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 и %2 (%3)</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Френски</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Опростен китайски</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Руски</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Унгарски</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Полски</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Японски</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Нидерландски</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Украйнски</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Бразилски Португалски</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Грузински</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Чешки</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Логото е направено от %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Може да следите за нови версии на: %1</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Български</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Турски</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Шведски</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Сръбски</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Традиционен китайски</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Пряк път</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Запис</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Зареждане</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Ключови файлове</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Избор на име на файла</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Презапис?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файлът %1 вече съществува.
Искате ли да бъде презаписан?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Избор на файл</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Грешка</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файлът не може да бъде запазен</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Файлът не може да бъде зареден</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Внимание</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Порт %1 е вече използван от друга програма.
Сървърът не може да бъде стартиран.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Сървърът на порт %1 не отговаря.
Опцията single instance е забранена.</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Файл...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>&amp;Директория...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Списък за изпълнение...</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD от устройство</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD от папка...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Изпълнение</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Пауза</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Стоп</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Кадър напред</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Изпълнение / Пауза</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Повторение</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Нормална скорост</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Скорост наполовина</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Двойна скорост</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Скорост &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Скорост &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Скорост</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;На цял екран</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Компактен режим</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Изравнител</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Снимка на екрана</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>&amp;Положение отгоре</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocessing</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Автооткриване на фазата</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Добавяне на &amp;шум</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>&amp;Филтри</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Заглушаване</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Сила на звука &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Сила на звука &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Забавяне -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>&amp;Забавяне +</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Екстрастерео</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Караоке</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Филтри</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Зареждане...</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Освобождаване</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Забавяне &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Забавяне &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Нагоре</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;Надолу</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Списък за изпълнение</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Показване на брояча на кадри</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Показване на дневниците</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Относно &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>Относно &amp;SMplayer</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Отваряне</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Изпълнение</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Видео</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Аудио</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Субтитри</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Преглед</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Помощ</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Последни файлове</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Изчистване</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Размер</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Картина</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Корекция на картина</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>De&amp;noise</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Автооткриване</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Широкоекранен</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 &amp;Широкоекранен</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Пълноекранен</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;към 16:9</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Няма</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>&amp;Нормален</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Лек</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Канали</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Стерео режим</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;Стандартни</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Стерео</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Съраунд</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Съраунд</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Ляв канал</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Десен канал</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Избор</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Заглавие</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Глава</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Наклон</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Забранен</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Лента за търсене</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Време</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Време + &amp;Общо време</translation>
    </message>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer дневник</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer дневник</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;празно&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Аудио</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Списъци за изпълнение</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Всички файлове</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Избор на файл</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer -Информация</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM / DVD устройствата все още не са настроени.
Тук вие можете да го направите.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Избор на директория</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Субтитри</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Относно Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Изпълнява се %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Изход</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Затваряне</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Показване на &amp;информация...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Намаляване &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Увеличаване &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Възстановяване</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Преместване &amp;наляво</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Преместване &amp;надясно</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Преместване &amp;нагоре</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Преместване &amp;надолу</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Pan &amp;&amp; scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Предишен ред от субтитрите</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>&amp;Следващ ред от субтитрите</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Нам. на звука (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Увел на звука (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Изход от цял екран</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Следващо ниво</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Нам на контраста</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Увел на контраста</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Нам на яркостта</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Увел на яркостта</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Нам на нюанса</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Увел на нюанса</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Нам на наситеността</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Увел на наситеността</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Следващ аудио файл</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Следващи субтитри</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Следваща глава</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Предишна глава</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Увел на наситеността</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Увел на гамата</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;Следващ</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">&amp;Предишен</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer все още работи</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>&amp;Показване на икона в системния панел</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Скриване</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Възстановяване</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Последни файлове</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">&amp;Изход</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Яркост: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Контраст: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Гама: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Нюанс: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Наситеност: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Сила на звука: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Мащаб: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Добре дошли в SMPlayer</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Главна лента</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Езикова лента</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Ленти</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Сила на звука</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Аудио</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Субтитри</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Списък за изпълнение</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Западни европейски езици</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Западни европейски езици с Евро</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Славянски/Централна Европа</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Есперанто, Галисийски, Малтийски, Турски</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Стар Балтийски</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Кирилица</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Арабски</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Модерен гръцки</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Турски</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Балтийски</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Келтски</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Еврейски</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Руски</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Украйнски, Беларуски</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Опростен Китайски</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Традиционен Китайски</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Японски</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Корейски</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Тайски</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Кирилица Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Славянски/Централна Европа Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqSlider</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>икона</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Настройки на файла</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Информация</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Разпределител</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Изберете разпределителят, които ще бъде използван за този файл:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Възстановяване</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;Видео кодек</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Изберете видео кодек:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>&amp;Аудио кодек</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Изберете аудио кодек:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>&amp;MPlayer настройки</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Настройки:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Вие също можете да добавяте допълнителни видео филтри.
Отделете ги с  &quot;,&quot;. Не използвайте интервали!
Пример: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>&amp;Видео филтри:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Вие също можете да добавяте и аудио филтри. 
Правилото е същото като за видео филтрите.
Пример: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>&amp;Аудио филтри:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Добре</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Прилагане</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Отказ</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Допълнителни настройки на MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Тук можете да добавяте допълнителни команди.
Отделете ги с  интервали.
Пример: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Общи</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Път</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 КБ (%2 МБ)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Дължина</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Разпределител</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Изпълнител</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Албум</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Авторско право</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Софтуер</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Информация за клипа</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Разделителна способност</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Съотношение</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Скорост</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Кадри в секунда</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Избран кодек</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Първоначален аудио поток</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Честота</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Хц</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Канали</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Аудио потоци</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Език</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>празно</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Субтитри</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Име на потока</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>URL на потока</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Избор на директория</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Изпълнение на DVD от папка</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Вие можете да изпълните dvd от вашия харддиск. Просто изберете папката, която съдържа директориите VIDEO_TS и AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Избор на директория...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Добре</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Отказ</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Изберете име на файла</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Презапис?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Файлът вече съществува.
Искате ли да бъде презаписан?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Грешка при запис на файла</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Дневникът не може да бъде запазен</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Прозорец на дневника</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Запис</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Копиране в системния буфер</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Затваряне</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Затваряне</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Дължина</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Изпълнение</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Редактиране</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Списъци за изпълнение</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Избор на файл</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Избор на име на файла</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Презапис?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файлът %1 вече съществува.Искате ли да бъде презаписан?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Всички файлове</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Изберете един или повече файлове за отваряне</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Избор на директория</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Редактиране на име</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Напишете име, което ще бъде показано в списъка за изпълнение:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Зареждане</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Запис</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Следващ</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Предишен</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Премести &amp;нагоре</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Премести &amp;надолу</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Повторение</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Разбъркано подреждане</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Добавяне на &amp;текущия файл</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Добавяне на &amp;файл(ове)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Добавяне на &amp;директория</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>&amp;Премахване на избраните</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Премахване на &amp;всички</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Добавяне...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Премахване...</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Списък за изпълнение</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Списъкът за изпълнение е променен</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Има незапазени промени, искате ли да запазите списъка?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Общи</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Дискове</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Производителност</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Субтитри</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Разширени</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Изпълними файлове</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Всички файлове</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Избор на mplayer изпълним файл</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Избор на директория</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype шрифтове</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Избор на ttf файл</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Чешки</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Немски</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Английски</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Испански</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Френски</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Унгарски</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Италиански</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Японски</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Грузински</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Нидерландски</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Полски</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Бразилски Португалски</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Руски</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Словашки</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Украйнски</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Опростен китайски</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Автооткриване&gt;</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Интерфейс</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Мишка и клавиатура</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Дневници</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Късо прескачане</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Средно прескачане</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Дълго прескачане</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Прескачане на колелцето на мишката</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Няма</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Стандартни</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Тук трябва да зададете изпълнимия файл на mplayer, който smplayer ше използва.&lt;br&gt;smplayer изисква поне 1.0rc1 (svn препоръчително).&lt;br&gt;&lt;b&gt;Ако настройката е грешна, smplayer няма да може да изпълни нищо!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Тук можете да зададете къде да бъдат запазвани снимките на екрана. Ако това поле е празно, фукнцията ще бъде изключена.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Избор на видео драйвер. Обикновено xv (Линукс) и directx (Windows) дават най-добра производителност.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Избор на аудио драйвер.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Можете да разрешите тази опция ако видео изравняването не се поддържа от вашата видеокарта или избрания видео драйвер.&lt;br&gt;&lt;b&gt;Забележка:&lt;/b&gt; тази опция може да не е съвместима с някои видео драйвери.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Тази опция служи за използване на софтуерно миксиране, вместо това на звуковата карта.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Обикновенно smplayer помни настройките за всеки отделен файл. Махнете тази опция ако не искате да става така.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Ако тази опция е активна, smplayer ще пуска всички файлове от началото.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Ако тази опция е активна, smplayer ще пуска всички файлове на цял екран.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Натиснете тук, за да забраните скрийнсейвъра, когато се изпълняват файлове.&lt;br&gt;Скрийнсейвърът ще бъде активиран, когато изпълнението свърши.&lt;br&gt;&lt;b&gt;Забележка:&lt;/b&gt; Тази опция работи само в X11 и Windows.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Тук можете да напишете предпочитания ви език за аудио потоците. Когато диск с няколко аудио потока бъде намерен, smplayer ще се опита да използва този език.&lt;br&gt;Това ще работи само на дискове, които предлагат информация за езика на потоците, като DVD-та или mkv файлове.&lt;br&gt;Това поле възприема нормални фрази. Пример: &lt;b&gt;es|esp|spa&lt;/b&gt;ще избере аудио файла ако съвпада с  &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; или &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Тук можете да напишете предпочитания ви език за субтитрите. Когато диск със субтитри бъде намерен, smplayer ще се опита да използва този език.&lt;br&gt;Това ще работи само на дискове, които предлагат информация за езика на субтитрите, като DVD-та или mkv файлове.&lt;br&gt;Това поле възприема нормални фрази. Пример: &lt;b&gt;es|esp|spa&lt;/b&gt;ще избере субтитрите ако съвпадат с  &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; или &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Задаване на приоритета на mplayer според тези налични в Windows.&lt;br&gt;&lt;b&gt;ВНИМАНИЕ:&lt;/b&gt; Използването на реално време може да причини забив на системата.</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Забележка:&lt;/b&gt; Тази опция е само за Windows.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Тази опция определя колко памет(в кб) да бъде използвана за прекеширането на файл или URL. Много полезно за бавна медия.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Прескачане показването на някои кадри, за да се поддържа A/V синхронизирането на слаби машини.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Интензивен frame drop. Води до изкривяване на картината!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Постепенно нагласява A/V синхронизирането базирано на измерванията на аудио забавянето.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Динамична промяна на нивото на postprocessing в зависимост от CPU-то. Номерът, който изберете, ще бъде максимална граница. </translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Ако изберете тази опция, smplayer ще съхранява дневниците на mplayer  (можете да ги видите в &lt;b&gt;Настройки-&gt;Показване на дневниците-&gt;mplayer&lt;/b&gt; В случай на проблеми този дневник може да съдържа важна информация.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Ако изберете тази опция, smplayer ще съхранява съобщенията за бъгове на smplayer  (можете да ги видите в &lt;b&gt;Настройки-&gt;Показване на дневниците-&gt;smplayer&lt;/b&gt; В случай на проблеми този дневник може да съдържа важна информация.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Тази опция позволява да се филтрират дневниците на smplayer. Тук можете да пишете обикновенни фрази. &lt;br&gt;Например: &lt;i&gt;^Core::*&lt;/i&gt; ще покаже редовете, започващи с &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Български</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Ако отметнете тази опция може да намалите треперенето, но също и може видеото да не се показва правилно.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Турски</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Гръцки</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Фински</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Шведски</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Тази настройка определя позицията на субтитрите върху видео прозореца.&lt;i&gt;100&lt;/i&gt;означава отдолу, докато &lt;i&gt;0&lt;/i&gt; означава отгоре.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Сръбски</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Традиционен китайски</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Настройки</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Общи</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Пътища</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Търсене...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Избор...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Папка за съхраняване на снимки:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Изходни устройства</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Видео:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Аудио:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Използване на софтуерен видео изравнител</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Използване на софтуерна сила на звука</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Запомняне на настройките за всички файлове (аудио файлове, субтитри...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Без запомняне на времевата позиция (файловете ще почват от началото)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Стартиране на филмите на цял екран</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Субтитри</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Избор на шрифта, който ще бъде използван за субтитри (и OSD):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF шрифт:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Избор...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Системен шрифт:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Автомащабиране:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Без Автомащабиране</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Пропорционално на височината на филма</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Пропорционално на ширината на филма</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Пропорционално на диагонала на филма</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Мащабиране:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Автозареждане</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Автоматичен избор на първите налични субтитри</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Същото име като филма</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Всички субтитри, съдържащи името на филма</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Всички субтитри в директорията</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Автоматично зареждане на субтитри (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Кодировка на субтитри:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Използване на SSA/ASS библиотеката за обработка на субтитри</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Цвят на текста:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Цвят на ъглите около екрана:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Допълнителни</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Настройки:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Видео филтри:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Аудио филтри:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Производителност</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Приоритет:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>реално време</translation>
    </message>
    <message>
        <source>high</source>
        <translation>високо</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>наднормалното</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>нормално</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>поднормалното</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>без</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Задаването на кеш може да подобри производителността при бавни файлове</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Кеш:</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Разрешаване на frame drop</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Разрешаване на силен frame drop (може да доведе до изкривеност на картината)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Синхронизация</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Автоматично Аудио/Видео синхронизиране</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Фактор:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Автоматично качество за postprocessing филтъра:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Ниво:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Най-ниско</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Най-високо</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Бързо автоматично превключване на песни</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Бързо търсене на отделните глави в DVD-та</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(кеша ще бъде забранен и няма гаранция, че наистина ще работи)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Изключване на скрийнсейвър</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Положение на монитора:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Метод за преоразмеряване на главния прозорец:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Никога</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Винаги когато е необходимо</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Само след зареждането на ново видео</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Стил:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Устройства</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Изберете вашето DVD устройство:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Изберете вашето CD устройство:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Добре</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Прилагане</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Отказ</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Предпочитани аудио и субтитри</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Субтитри:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Включи субтитрите в снимките на екрана</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>икона</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Вие също можете да добавяте допълнителни видео филтри.
Отделете ги с  &quot;,&quot;. Не използвайте интервали!
Пример: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Вие също можете да добавяте и аудио филтри. 
Правилото е същото като за видео филтрите.
Пример: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Интерфейс</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Търсене</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Сила на звука</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Стандартна сила на звука:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Размер на прозореца</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Едно копие в системата</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Използване само на едно копие на SMPlayer в системата</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer ще наблюдава порта за команди от други копия на програмата:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(промените тук изискват SMPlayer да бъде рестартиран)</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Последни файлове</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Макс. елементи</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Изчистване на листа</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Език:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Икони:</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>В момента SMPlayer не открива автоматично cd и dvd устройства. Така че, за да пуснете такива, първо ги посочете оттук.</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Мишка и клавиатура</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Мишка</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Функции на бутоните:</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Ляво натискане</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Двойно натискане</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Функция на колелото:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Търсене на медия</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Контрол на звука</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Клавиатура</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Дневници</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Тази опция е планирана за остраняване на грешки в програмата.</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Изберете изпълнимия файл на MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Пускане на MPlayer в неговия собствен прозорец</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Допълнителни настройки на MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Тук можете да добавяте допълнителни команди.
Отделете ги с  интервали.
Пример: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Изберете приоритета за MPlayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Разрешаване на дневник за MPlayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Разрешаване на дневник за SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Филтър за дневниците на SMPlayer:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Не оцветявай фона на видео прозореца отново</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Тук може да променяте клавишите на клавиатурата. За да го направите кликнете двойно и натиснете бутон. Също можете да запазите този списък и да го споделяте с познати.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Избор на първите налични субтитри</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Позиция на субтитрите на екрана по подразбиране</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Colorkey:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Промени...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Отгоре</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Отдолу</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Стилове:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">&amp;Субтитри</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Видео</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Аудио</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 секунда</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 секунди</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 минути</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 минути и  %2 секунди</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 минута</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 минута и 1 секунда</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 минута и %1 секунди</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 минути и 1 секунда</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>икона</translation>
    </message>
    <message>
        <source>label</source>
        <translation>надпис</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Изравнител</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Контраст</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Яркост</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Нюанс</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Наситеност</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Гама</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Възстановяване</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Задаване като стандартни</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Използване като стандартни за нови филми.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Задаване на всичко до нула.</translation>
    </message>
</context>
</TS>
