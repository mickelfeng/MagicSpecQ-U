<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Ett grafiskt gränssnitt för MPlayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Fil att öppna</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Utvecklare</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Version: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt-version: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Detta program är gratis. Du får sprida det och/eller ändra det enligt GNU General Public License utgiven av Free Software Foundation; antingen version två av licensen eller (om du så vill) en senare version.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Översättare:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>tyska</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>slovakiska</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>italienska</translation>
    </message>
    <message>
        <source>French</source>
        <translation>franska</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Förenklad kinesiska</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>ryska</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>ungerska</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>japanska</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>holländska</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>ukrainska</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">portugisiska (Brasilien)</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>georgiska</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>tjeckiska</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logga designad av %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Hämta uppdateringar från: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>Om SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 och %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>polska</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Kompilerad med KDE-stöd</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>bulgariska</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>turkiska</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>svenska</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>serbiska</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>traditionell kinesiska</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Beskrivning</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Kortkommando</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Spara</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Öppna</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Nyckelfiler</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Välj ett filnamn</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Bekräfta överskrivning?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Filen %1 finns redan.
Vill du skriva över den?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Välj en fil</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Filen kunde inte sparas</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Filen kunde inte öppnas</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer-logg</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer-logg</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Öppna</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Spela upp</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Ljud</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Undertexter</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Bläddra</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Inställningar</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hjälp</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Filer ...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>&amp;Mapp ...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Spellista ...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD från enhet</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD från mapp ...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;Webbadress ...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Töm</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Tidigare filer</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Spela upp</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Paus</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>S&amp;topp</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>St&amp;ega</translation>
    </message>
    <message>
        <source>&amp;-10 seconds</source>
        <translation type="obsolete">&amp;-10 sekunder</translation>
    </message>
    <message>
        <source>&amp;+10 seconds</source>
        <translation type="obsolete">&amp;+ 10 sekunder</translation>
    </message>
    <message>
        <source>-1 &amp;minute</source>
        <translation type="obsolete">-1 &amp;minut</translation>
    </message>
    <message>
        <source>+1 m&amp;inute</source>
        <translation type="obsolete">+1 m&amp;inut</translation>
    </message>
    <message>
        <source>-10 mi&amp;nutes</source>
        <translation type="obsolete">-10 mi&amp;nuter</translation>
    </message>
    <message>
        <source>+10 min&amp;utes</source>
        <translation type="obsolete">+10 min&amp;uter</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normal hastighet</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Halv hastighet</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Dubbel hastighet</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Hastighet &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Hastighet &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Hastighet</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Upprepa</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Helskärm</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Kompakt läge</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>S&amp;torlek</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Autodetektera</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Brevlåda</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 B&amp;revlåda</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;till 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Bildformat</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Ingen</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lågpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlace</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Efterbehandling</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetektera phase</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Lägg till n&amp;oise</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>F&amp;ilter</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizer</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Skärmdump</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>&amp;Alltid överst</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Spår</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filter</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;Standard</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Kanaler</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Vänster kanal</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Höger kanal</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>S&amp;tereoläge</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Ljud av</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Volym &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Volym &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Fördröjning -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>F&amp;ördröjning +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Välj</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Öppna ...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Fördröjning &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Fördröjning &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Upp</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;Ner</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Titel</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Kapitel</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Vinkel</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Spellista</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>Visa &amp;bildräknare</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Inaktiverad</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Förloppsindikator</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Tid</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Tid + T&amp;otal tid</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>Vis&amp;a på skärmen (OSD)</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>Visa &amp;loggar</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Inställningar</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Om &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>Om &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tom&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Ljud</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Spellistor</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alla filer</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Välj en fil</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Information</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Enheterna för cdrom/dvd är inte konfigurerade än.
Nu visas konfigurationsdialogen så att du kan göra detta.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Välj en mapp</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Undertexter</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Om Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Spelar upp %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Paus</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>De&amp;noise</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormal</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Soft</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Spela upp/Paus</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Paus/Stegning</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Stäng</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Varning</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Port %1 används redan av ett annat program.
Kan inte starta servern.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Servern på port %1 svarar inte.
Alternativet &apos;single instance&apos; har inaktiverats.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Avsluta</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Stäng</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Visa i&amp;nfo och egenskaper ...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Återställ</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Flytta till &amp;vänster</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Flytta till &amp;höger</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Flytta &amp;uppåt</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Flytta &amp;nedåt</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Pan &amp;&amp; scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Föregående rad</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>N&amp;ästa rad</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Sänk vol (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Höj vol (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Avsluta helskärm</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - nästa nivå</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Minska kontrast</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Öka kontrast</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Minska ljusstyrka</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Öka ljusstyrka</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Minska nyans</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Öka nyans</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Minska färgmättnad</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Minska gamma</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Nästa ljudfil</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Nästa undertext</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Nästa kapitel</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Föregående kapitel</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Öka färgmättnad</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Öka gamma</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation>Skifta dubbel storlek</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>&amp;Öppna extern fil...</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normal)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (dubbel framerate)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Nästa</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Föregående</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer är fortfarande i gång</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>Visa i&amp;kon i Meddelandefältet</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Dölj</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Återställ</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Tidigare</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Avsluta</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Ljusstyrka: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Kontrast: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Nyans: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Färgmättnad: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Volym: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Välkommen till SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volym</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Ljud</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Undertext</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Spellista</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Huvudverktygsfält</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Språkverktygsfält</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Verktygsfält</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Västeuropeiska språk</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Västeuropeiska språk med euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Slaviska/Centraleuropeiska språk</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, galiciska, maltesiska, turkiska</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Gammal baltisk teckenuppsättning</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Kyrilliska</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabiska</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Modern grekiska</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turkiska</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Baltiska</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Keltiska</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Hebreisk teckenuppsättning</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Ryska</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrainska, vitryska</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Förenklad kinesiska</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Traditionell kinesiska</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japansk teckenuppsättning</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Koreansk teckenuppsättning</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thailändsk teckenuppsättning</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Kyrillisk Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Slavisk/Centraleuropeisk Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqSlider</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Filegenskaper</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>Välj &amp;demuxer för denna fil:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Återställ</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>Video&amp;codec</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>Välj v&amp;ideocodec:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>&amp;Ljudcodec</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>Välj lj&amp;udcodec:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>Alternativ för &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Alternativ:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Du kan också lägga till ytterligare filter.
Skilj dem med &quot;,&quot;. Använd inte mellanslag!
Exempel: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideofilter:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Och slutligen ljudfilter. Samma regel som för videofilter.
Exempel: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>Ljud&amp;filter:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Verkställ</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Ytterligare alternativ för MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Här kan du ange fler alternativ för MPlayer.
Skilj dem åt med mellanslag.
Exempel: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Sökväg</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 kB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Webbadress</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Längd</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Artist</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Skapare</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Genre</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Spår</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Mjukvara</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Klippinfo</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Upplösning</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Bildformat</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Bitar/sek</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Bildrutor/sekund</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Vald codec</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Initialljudström</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Frekvens</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanaler</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Ljudströmmar</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Språk (Language)</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>tom</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Undertext</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>Nr</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Strömtitel</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>Ström-URL</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Välj en mapp</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Spela upp en DVD från en mapp</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Du kan spela upp en dvd från din hårddisk. Välj bara den mapp som innehåller mapparna VIDEO_TS och AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Välj en mapp ...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>Avbryt</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Välj filnamn att spara som</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Bekräfta ersättning?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Filen finns redan.
Vill du skriva över den?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Fel vid sparande av fil</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Loggen kunde inte sparas</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Loggfönster</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopiera till Urklipp</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Stäng</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Längd</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Spela upp</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Redigera</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Spellistor</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Välj en fil</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Välj ett filnamn</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Bekräfta ersättning?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Filen %1 finns redan.
Vill du skriva över den?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alla filer</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Markera en eller flera filer att öppna</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Välj en mapp</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Redigera namn</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Skriv in det namn som ska visas i spellistan för denna fil:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Öppna</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Spara</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Nästa</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Föregående</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Flytta &amp;upp</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Flytta &amp;ner</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Upprepa</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Blanda</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Lägg till &amp;aktuell fil</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Lägg till &amp;fil(er)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Lägg till &amp;mapp</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Ta bort &amp;markerade</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Ta bort &amp;alla</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Spellista</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Lägg till ...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Ta bort ...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Spellistan ändrad</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Det finns ändringar som inte sparats. Vill du spara spellistan?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Enheter</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Prestanda</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Undertexter</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avancerat</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Program</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alla filer</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Markera mplayers programfil</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Välj en mapp</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>TrueType-teckensnitt</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Välj en TTF-fil</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Kort hopp</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Mellanhopp</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Långt hopp</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Hopp med mushjulet</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Gränssnitt</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Mus och tangentbord</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Här kan du ange den mapp där skärmdumpar från SMPlayer ska sparas. Om detta fält är tomt så kan du inte ta några skärmdumpar.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Välj drivrutiner för video output. Vanligtvis ger xv (Linux) och DirectX (Windows) bäst resultat.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Välj drivrutin för ljudoutput.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Välj detta alternativ om ditt grafikkort inte stöder equalizer för video eller den valda drivrutinen för video. &lt;br&gt;&lt;b&gt;OBS:&lt;/b&gt; Detta alternativ kan vara inkompatibelt med vissa drivrutiner för video-output.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Använd detta alternativ om du vill använda ett mjukvarubasat mixerbord i stället för det i ljudkortet.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Om du markerar detta alternativ så spelar SMPlayer alla filer från början.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Om du markerar detta alternativ så spelas all video upp i helskärmsläge.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Välj detta alternativ för att inaktivera skärmsläckaren under uppspelning.&lt;br&gt;Skärmsläckaren aktiveras igen efteråt.&lt;br&gt;&lt;b&gt;OBS:&lt;/b&gt; Detta fungerar endast i X11 och Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Här måste du ange EXE-filen till den MPlayer som SMPlayer ska använda.&lt;br&gt;SMPlayer kräver minst MPlayer 1.0rc1 (svn rekommenderas).&lt;br&gt;&lt;b&gt;Om denna sökväg är felaktig så kommer inte SMPlayer att spela någonting alls!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>SMPlayer sparar output från MPlayer (se &lt;b&gt;Inställningar -&gt; Visa loggar -&gt; mplayer&lt;/b&gt;). Vid eventuella problem kan denna logg innehålla viktig information, så se till att detta alternativ är förbockat.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Om detta alternativ är förbockat så sparar SMPlayer debug-meddelanden från SMPlayer (loggen nås under &lt;b&gt;Inställningar -&gt; Visa loggar -&gt; smplayer&lt;/b&gt;. Denna information kan vara väldigt användbar för utveckaren om du stöter på en bugg.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Detta alternativ låter dig filtrera meddelanden från SMPlayer som sparas i loggfilen. Här kan du använda reguljära uttryck.&lt;br&gt;Exempel: &lt;i&gt;^Core::.*&lt;/i&gt; visar bara rader som börjar med texten &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Loggar</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;OBS:&lt;/b&gt; Detta alternativ gäller endast Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Ange processprioritering för MPlayer enligt de fördefinierade prioriteter tillgängliga under Windows.&lt;br&gt;&lt;b&gt;VARNING:&lt;/b&gt; Realtidsprioritet kan låsa systemet helt.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Vanligtvis kommer SMPlayer ihåg inställningarna för varje fil du spelar upp (valt ljudspår, volym, filter, ...) Avmarkera detta alternativ om du inte vill ha denna funktion.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Här kan du skriva in det språk du föredrar i fråga om ljudströmmar. När media med flera ljudströmmar öppnas, så försöker SMPlayer använda det språk du föredrar.&lt;br&gt;Detta fungerar endast med media som innehåller information om språket i ljudströmmen, som t.ex. DVD eller MKV-filer.&lt;br&gt;Detta fält accepterar reguljära uttryck. Exempel: &lt;b&gt;es|esp|spa&lt;/b&gt; om det matchar med &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; eller &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Här kan du skriva in det språk du föredrar i fråga om undertexter. När media med flera undertextströmmar öppnas, så försöker SMPlayer använda det språk du föredrar.&lt;br&gt;Detta fungerar endast med media som innehåller information om språket i undertextströmmen, som t.ex. DVD eller MKV-filer.&lt;br&gt;Detta fält accepterar reguljära uttryck. Exempel: &lt;b&gt;es|esp|spa&lt;/b&gt; om det matchar med &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; eller &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Detta alternativ anger hur mycket minne (i kB) som ska användas när en fil eller URL cachas i förväg. Speciellt användbart vid långsamma media.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Strunta i att visa vissa bildrutor för att bibehålla bild-ljudsynkroniseringen på långsamma system.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Hoppar över ännu fler bildrutor. Leder till distortion av bilden!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Anpassar gradvis ljud-bildsynkroniseringen baserat på mätningar av ljudfördröjning.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Ändrar dynamiskt nivån på efterbehandlingen beroende på tillgänglig CPU-tid. Den siffra du anger bestämmer den maximala nivån. Vanligen kan du använda något högt tal.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tjeckiska</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Tyska</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Engelska</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Spanska</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Franska</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Ungerska</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italienska</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japanska</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiska</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holländska</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polska</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugisiska (Brasilien)</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Ryska</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovakiska</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainska</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Förenklad kinesiska</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Autodetektera&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgariska</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Detta alternativ kan minska flimmer, but det skulle också kunna göra så att videon inte visas på rätt sätt.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turkiska</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>grekiska</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>finska</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>svenska</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Detta alternativ anger position för undertexterna i videofönstret. &lt;i&gt;100&lt;/i&gt; betyder längst ner, medan &lt;i&gt;0&lt;/i&gt; betyder längst upp.</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>serbiska</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>traditionell kinesiska</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Här kan du åsidosätta format för SSA/ASS-undertexter. Du kan också finjustera återgivningen av srt- och sub-undertexter med SSA/ASS-library.&lt;br&gt;Exempel: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>MPlayer language</source>
        <translation type="obsolete">Språk för MPlayer</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Tangentbord och mus</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Inställningar</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Verkställ</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Allmänt</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Sökvägar</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Sök ...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Välj ...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Mapp för skärmdumpar:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Drivrutiner för output</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Tal:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Använd mjukvarubaserad videoequalizer</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Använd mjukvarubaserad volymkontroll</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Inställningar för media</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Kom ihåg inställningarna för alla filer (ljudspår, undertexter ...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Kom inte ihåg tidsposition (filerna spelas upp från början)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Starta video i helskärmsläge</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Undertext</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Välj teckensnitt för undertexter (och meddelanden på skärmen):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF-font:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Välj ...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Systemfont:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Autoskala:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Ej autoskala</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proportionell mot filmhöjd</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proportionell mot filmbredd</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proportionell mot diagonalen</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Skala:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Autoöppna</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Välj automatiskt den första tillgängliga undertexten</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Samma namn som filmen</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Alla texter som innehåller filmnamnet</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Alla undertexter i mappen</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Autoöppna textfiler (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Standardkodning för undertexter:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Använd SSA/ASS för undertexter</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Textfärg:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Ramfärg:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Inkludera undertext i skärmdump</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Avancerat</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Alternativ:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Du kan också ange ytterligare videofilter.
Skilj dem med &quot;,&quot;. Använd inte mellanslag!
Exempel: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Videofilter:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Och slutligen ljudfilter. Samma regel som för videofilter.
Exempel: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Ljudfilter:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Prestanda</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioritet:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>realtid</translation>
    </message>
    <message>
        <source>high</source>
        <translation>hög</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>över normal</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>under normal</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>inaktiv</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>En cache kan förbättra prestanda för långsamma media.</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Cache:</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>kB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Tillåt &apos;frame drop&apos;</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Tillåt &apos;hard frame drop&apos; (kan leda till distortion i bilden)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Synkronisering</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Autosynkronisering av ljud/video</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Autokvalitet för efterbehandlingsfilter:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Nivå:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Lägst</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Högst</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Snabbt byte av ljudspår</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Snabbsökning till kapitel på DVD</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(Cachen inaktiveras och ingen garanti ges för att det verkligen fungerar)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Inaktivera skärmsläckare</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Skärm:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Storleksförändring av huvudfönstret:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>När det behövs</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Endast när ny video öppnats</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Endast 1 kopia</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Tillåt bara 1 kopia av SMPlayer åt gången</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer lyssnar på denna port för att ta emot kommandon från andra kopior:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(Ändringar i denna grupp kräver omstart av SMPlayer)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Stil:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Enheter</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>För tillfället autodetekterar SMPlayer inte cdrom- eller dvd-enheter. Så för att kunna spela upp cdrom och dvd måste du först ange dina enheter för cdrom och dvd (kan vara samma).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Ange CD-enhet:</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Ange DVD-enhet:</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Tidigare</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Max. poster:</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Töm listan</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Sökning</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volym</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Normalvolym:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Mus</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Knappfunktioner:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Dubbelklick:</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Vänsterklick:</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Fönsterstorlek</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Gränssnitt</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Hjulfunktion:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Snabbspolning</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Volymkontroll</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Mus och tangentbord</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Tangentbord</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Loggar</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Detta alternativ är huvudsakligen tänkt för att avbuggning av programmet.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Språk (Language):</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Skal:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Standardspråk - tal och undertexter</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Undertexter:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritering</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Ange EXE-filen för MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Kör MPlayer i ett eget fönster</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Ytterligare alternativ för MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Här kan du ange extra alternativ för MPlayer.
Skilj dem åt med mellanslag.
Exempel: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Ange prioritet för MPlayer-processen.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Logga output från MPLayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Logga output från SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filter för SMPlayer-loggar:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Måla inte om bakgrunden på videofönster</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Här kan du ändra kortkommandon. Dubbelklicka eller börja skriva över ett kortkommandofält. Du kan också spara listan och dela med dig av den till andra användare eller datorer.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Välj första tillgängliga undertext</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Standardposition för undertexterna</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Färgnyckel:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Ändra ...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Uppe</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Nere</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Format:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Använd cache</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS pass-through S/PDIF</translation>
    </message>
    <message>
        <source>Use subfont (required by recent MPlayer releases)</source>
        <translation type="obsolete">Använd subfont (krävs av nyare MPlayer-utgåvor)</translation>
    </message>
    <message>
        <source>MPlayer language</source>
        <translation type="obsolete">Språk för MPlayer</translation>
    </message>
    <message>
        <source>SMPlayer looks for English texts in the MPlayer output. If your MPlayer is configured to display the output in another language you need to change here the texts that SMPlayer should look for.</source>
        <translation type="obsolete">SMPlayer letar efter engelska texter i output från MPlayer. Om din MPlayer är konfigurerad att visa output på ett annat språk behöver du här ändra texter som SMPlayer ska leta efter.</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Slut på filen:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>Ingen video:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Undertexter</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>Använd alternativet -subfont (krävs av senare utgåvor av MPlayer)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>SSA/&amp;ASS-library</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>Det nya SSA/ASS-libraryt erbjuder snygga undertexter för externa SSA/ASS-undertexter och Matroskaspår. Men det kommer också att användas för andra format som SUB- och SRT-filer.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Här kan du åsidosätta format för SSA/ASS-undertexter. Du kan också finjustera återgivningen av srt- och sub-undertexter med SSA/ASS-library. Exempel: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>&amp;Avancerat</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>&amp;Loggar</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>Språk för &amp;MPlayer</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>SMPlayer behöver läsa och tolka output från MPlayer och ibland krävs engelsk text. Om du använder en MPlayer som är översatt till ett annat språk så behöver du ändra de texter som SMPlayer letar efter. (Tekniskt sett bör du använda reguljära uttryck)&lt;br&gt;&lt;br&gt;
Rullgardinslistorna kan erbjuda färdiggjorda reguljära uttryck på flera språk.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Tangentbord</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Mus</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation>Zooma video</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Video</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Ljud</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished">Här kan du åsidosätta format för SSA/ASS-undertexter. Du kan också finjustera återgivningen av srt- och sub-undertexter med SSA/ASS-library. Exempel: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt; {2 or 4?}</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 sekund</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 sekunder</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 minut</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 minut och 1 sekund</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 minut och %1 sekunder</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 minuter</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 minuter och 1 sekund</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 minuter och %2 sekunder</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etikett</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Equalizer</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Ljusstyrka</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Nyans</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Färgmättnad</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Återställ</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Ange som standardvärden</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Använd aktuella värden som standardvärden för nya videor.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Nollställ alla kontroller.</translation>
    </message>
</context>
</TS>
