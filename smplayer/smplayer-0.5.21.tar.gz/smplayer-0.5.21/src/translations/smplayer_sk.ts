<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Front-end pre mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Súbor pre otvorenie</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Vývojár</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Verzia: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt Verzia: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Tento program je slobodný software: možete ho redistribuovať a/alebo modifikovať za podmienok licencie GPL verzia 2.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Prekladatelia:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Nemecky</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovensky</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Taliansky</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francúzsky</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Zjednodušená čínština</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Rusky</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Maďarsky</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonsky</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandsky</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainsky</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Brazílska Portugalčina</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation></translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Česky</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo vytvoril %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Aktuálna verzia na: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>O SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 a %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Poľsky</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Skompilované s podporou KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulharsky</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turecky</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Švédsky</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Srbsky</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Tradičná Čínština</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Rumunsky</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Portugalsky</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Meno</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Skratka</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Uložiť</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Načítať</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Vybrať názov súboru</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Potvrdiť prepísanie?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Súbor %1 už existuje.
Chcete ho prepísať?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Vybrať súbor</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Súbor nemôže byť uložený</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Súbor nemože byť načítaný</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer log</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer log</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Otvoriť</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Prehrať</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Zvuk</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Titulky</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Navigácia</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Možnosti</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Pomoc</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Súbor...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>&amp;Adresár...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Playlist...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD z disku</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD z adresáru na disku...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Vyčistiť zoznam</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Naposledy otvorené súbory</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Prehraj</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pauza</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Zastav</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Krokovanie obrazu</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normálna rýchlosť</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Polovičná rýchlosť</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Dvojnásobná rýchlosť</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Rýchlosť &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Rýchlosť &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Rýchlosť</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Opakovať</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Celá obrazovka</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Kompaktný mód</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>Veľ&amp;kosť</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Autodetekcia</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Pan Scan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;na 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Pomer strán</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Žiadne</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlace</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocessing</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetekcia fázy</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblocking</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ringing</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>&amp;Pridať šum</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>&amp;Filtre</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Ekvalizér</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Snímok obrazovky</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>U&amp;držiavať navrchu</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Stopa</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extra stereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtre</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>Š&amp;tandard</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Kanály</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Ľavý kanál</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Pravý kanál</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>S&amp;tereo mód</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Stíšiť</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Hlasitosť &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Hlasitosť &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Oneskorenie -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>O&amp;neskorenie +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Výber</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Načítať...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Oneskorenie &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Oneskorenie &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>Posunúť &amp;vyššie</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>Posunúť &amp;nižsie</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Titul</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Kapitola</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Uhol pohľadu</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>Play&amp;list</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>Zobraziť &amp;počítadlo obrázkov</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Zakázať</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Posuvník</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Čas</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Čas + c&amp;elkový čas</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Zobraziť logy</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Nastavenia</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>O &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>O &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;prázdny&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Playlist</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Vybrať súbor 1</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Informácie</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Zariadenie CD / DVD ešte nebolo nakonfigurované.
Môžete to urobiť teraz v nasledujúcom dialógu.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Vybrať adresár 2</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>O Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Prehrávam %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pauza</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Zastav</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>&amp;Odstránenie šumu</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>&amp;Normálne</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Jemné</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Prehrať / Pauza</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pauza / Krokovanie obrazu</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>U&amp;nload 1</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - upozornenie</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Port %1 je už použitý inou aplikáciou
Nemôžem spustiť server.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Server na porte %1 neodpovedá
Možnosť &quot;použiť iba jednu inštanciu&quot; bude zakázaná.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Koniec</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Z&amp;atvoriť</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Zobraziť &amp;informácie a vlastnosti...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Posunúť vľ&amp;avo</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Posunúť v&amp;pravo</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Posunúť &amp;vyššie</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Posunúť &amp;nižšie</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp; Pan &amp;&amp; scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Predchádzajúci riadok titulkov</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>&amp;Nasledujúci riadok titulkov</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Znížiť hlasitosť (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Zvýšiť hlasitosť (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Ukončiť režim celej obrazovky</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - ďalšia úroveň</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Znížiť kontrast</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Zvýšiť kontrast</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Znínžiť jas</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Zvýšiť jas</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Znížiť odtieť</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Zvýšiť odtieň</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Znížiť saturáciu</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Znížiť gammu</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Ďalšia zvuková stopa</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Ďalšie titulky</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Ďalšia kapitola</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Predchádzajúca kapitola</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Zvýšiť saturáciu</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Zvýšiť gammu</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation>Dvojnásobná veľkosť</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>&amp;Načitať externý súbor...</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normálne)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (dvojnásobný framerate)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>Ďa&amp;lší</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>Pre&amp;dchádzajúci</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Normalizácia hlasitosti</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer je stále spustený</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>Zobraziť ikonu v &amp;systémovej lište</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Skryť</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Obnoviť</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Naposledy otvorené súbory</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Koniec</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Jas: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Kontrast: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Odtieň: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Saturácia: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Hlasitosť: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Vitajte v programe SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Hlasitosť</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Playlist</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Hlavný panel</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>Panel &amp;jazykov</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Panely</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Západné Európske jazyky</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Západné Európske jazyky s Euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Slovanské/Stredo-Európske jazyky</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galicisch, Maltesisch, Turecky</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Staré Baltické kódovanie</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cyrilika</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabsky</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Moderná Gréčtina</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turecky</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Baltic</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Celtic</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Hebrejsky</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Rusky</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrajina, Bielorusko</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Zjednodušená Čínština</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Tradičná Čínština</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japonsky</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Kórejsky</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thajsky</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Cyrilika - windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Slovanské/Stredo-Európske jazyky - windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqPosúvač</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlyer - vlastnosti súboru</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informácie</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>Vyberte &amp;demuxer, ktorý bude použitý pre tento súbor:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;Video kódek</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Vyberte video kódek:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>&amp;Audio kódek</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Vyberte audio kódek:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>&amp;MPlayer možnosti</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Možnosti:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Ďalšie video filtre
Píšte ich oddelené čiarkou. Nepoužívajte medzery!
Príklad: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideo filtre:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Audio filtre. Rovnaké pravidlá ako pre video filtre.
Príklad: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>Audio &amp;filtre:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Použiť</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušiť</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Ďalšie možnosti pre MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Extra možnosti pre MPlayer
Píšte ich oddelené medzerou.
Príklad: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Hlavné</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veľkosť</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Dĺžka</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Meno</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Umelec</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dátum</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Stopa</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentár</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Informácie o klipe</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Rozlíšenie</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Pomer strán</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formát</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Bitový tok</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Obrázkov za sekundu</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Použitý kódek</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Zvuková stopa</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Frekvencia</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanály</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Zvukové stopy</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>prázdny</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Názov streamu</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>URL streamu</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Vybrať adresár</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Môžete prehrávať DVD uložené vo vašom počítači. Stačí vybrať adresár obsahujúci adresáre VIDEO_TS a AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Vybrať adresár...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušiť</translation>
    </message>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Prehrať DVD z adresáru</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Vyberte súbor, do ktorého sa uloží log</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Potvrdiť prepísanie?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Súbor už existuje
Chcete ho prepísať?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Chyba pri ukladaní súboru</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Log nemôže byť uložený</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Logovacie okno</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Uložiť</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Skopírovať do schránky</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zatvoriť</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zatvoriť</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Názov</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Dĺžka</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Vybrať súbor</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Vybrať názov súboru</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Potvrdiť prepísanie?</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Vyberte jeden alebo viac súborov na otvorenie</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Vybrať adresár</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Súbor %1 už existuje.
Chcete ho prepísať?</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Zmeniť názov</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Napíšte názov, ktorý bude zobrazený v zozname pre tento súbor:</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Prehrať</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Upraviť</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Zoznam</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Načítať</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Uložiť</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>Ďa&amp;lší</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>Pre&amp;dchádzajúci</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Posunúť &amp;vyššie</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Posunúť &amp;nižšie</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Opakovať</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Náhodný výber</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>&amp;Pridať aktuálny súbor</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Pridať &amp;súbor(y)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Pridať &amp;adresár</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>&amp;Odstrániť vybrané</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Odstrániť &amp;všetky</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Playlist</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Pridať...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Odstrániť...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Playlist zmenený</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Vykonané zmeny v playliste, chcete uložiť playlist?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Hlavné</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Umiestnenie programu mplayer</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Vybrať TTF súbor</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Vybrať adresár</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Výkon</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Rozšírené</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Zariadenia</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Súbory</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všetky súbory</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype fonty (*.ttf)</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Krátky posuv</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Stredný posuv</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Dlhý posuv</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Posuv koliečkom myši</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Žiadny</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Rozhranie</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Myš a klávesnica</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Adresár, kam budú ukladnané vytvorené snímky. Pokiaľ adresár nie je určený, snímky nebude možné ukladať.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Výstupné video zariadenie. Najvyšší výkon dosahuje výstup xv (linux) a directx (windows).&lt;br&gt;Viacej možností získate príkazom &lt;code&gt;mplayer -vo help&lt;/code&gt;.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Výstupné audio zariadenie (alsa, oss, nas).&lt;br&gt;Viacej možností získate príkazom &lt;code&gt;mplayer -ao help&lt;/code&gt;.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Použite túto možnosť, ak video ekvalizér nie je podporovaný vašou grafickou kartou, alebo výstupným video zariadením.&lt;br&gt;&lt;b&gt;Poznámka&lt;/b&gt; táto možnosť može byť nekompatibilná s niektorými výstupnými video zariadeniami.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Použi softwarový mixér miesto mixéru zvukovej karty.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Ak použijete túto možnosť, smplayer bude prehrávať súbory vždy od začiatku.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Ak použijete túto možnosť, všetky videá budú spúšťané v režime celej obrazovky.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Použite túto možnosť ak chcete zakázať šetrič obrazovky počas prehrávania.&lt;br&gt;Šetrič obrazovky bude obnovený po skončení prehrávania.&lt;br&gt;&lt;b&gt;Poznámka:&lt;/b&gt; Táto možnosť funguje iba v X11 a Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Tu určujete umiestnenie programu mplayer, ktorý SMPlayer používa.&lt;br&gt;SMPlayer potrebuje minimálne mplayer 1.0rc1.&lt;br&gt;&lt;b&gt;Ak táto možnosť nie je dobre nastavená, smplayer nebude schopný prehrať akýkoľvek súbor!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Ak použijete túto možnosť, smplayer bude uchovávať výstup programu mplayer (môžete ho vidieť v &lt;b&gt;Možnosti -&gt; Zobraziť logy -&gt; mplayer&lt;/b&gt;). V prípade problému, tento log obsahuje dôležité informácie, preto je potrebné nechať túto možnosť zaškrtnutú.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Ak použijete túto možnosť, smplayer bude uchovávať výstup programu smmplayer (môžete ho vidieť v &lt;b&gt;Možnosti -&gt; Zobraziť logy -&gt; smplayer&lt;/b&gt;). Tieto informácie môžu byť veľmi užitočné pre vývojárov pri hlľadaní chýb.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Ak použijete túto možnosť, smplayer bude filtrovať hlášky, ktoré budú uložené do logu. Môžete použiť akýkoľvek regulérny výraz.&lt;br&gt;Napríklad: &lt;i&gt;^Core::.*&lt;/i&gt; bude ukladať iba riadky začínajúce s &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logy</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Poznámka:&lt;/b&gt; Táto možnosť je iba pre Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Štandardné</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Nastavuje prioritu programu mplayer podobne ako sú preddefinované priority vo Windowse.&lt;br&gt;&lt;b&gt;Upozornenie:&lt;/b&gt; použite najvyššej priority môže spôsobiť zablokovanie systému.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>SMPlayer si štandardne pamätá nastavenia pre každý prehrávaný súbor (vybraná zvuková stopa, hlasitosť, nastavené filtre...). Zrušením tejto možnosti SMPlayer nebude používať toto nastavenie.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Nastavenie preferovaného jazyka pre zvukové stopy. Ak je vybrané médium s viacerými zvukovými stopami, SMPlayer bude používať nastavený jazyk.&lt;br&gt;Toto nastavenie bude fungovať iba s médiami, ktoré majú informácie o zvukových stopách, ako napr. DVD alebo mkv súbory.&lt;br&gt;Akceptované sú regulárne výrazy.&lt;br&gt;Príklad: &lt;b&gt;sk|cs|en&lt;/b&gt; použije slovenskú zvukovú stopu. Ak nebude nájdená, použije sa česká zvuková stopa. Ak nebude nájdená ani česká, použije sa anglická zvuková stopa. Ak nebude nájdená ani anglická zvuková stopa, použije sa prvá zvuková stopa na médiu.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Nastavenie preferovaného jazyka pre titulky. Ak je vybrané médium s viacerými titulkami, SMPlayer bude používať nastavený jazyk.&lt;br&gt;Toto nastavenie bude fungovať iba s médiami, ktoré majú informácie o zvukových stopách, ako napr. DVD alebo mkv súbory.&lt;br&gt;Akceptované sú regulárne výrazy.&lt;br&gt;Príklad: &lt;b&gt;sk|cs|en&lt;/b&gt; použije slovenské titulky. Ak nebudú nájdené, použijú sa české titulky. Ak nebudú nájdené ani české, použijú sa anglické titulky. Ak nebudú nájdené ani anglické titulky, použijú sa prvé titulky na médiu.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Nastavenie veľkosti pamäti (v kBytoch), ktorá bude použitá ako cache pre súbory alebo URL. Väčšia pamäť je vhodná pri pomalých médiach.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Preskakovanie niektorých snímkov na pomalých systémoch pre udržanie synchronizáciu obrazu a zvuku.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Intenzívnejšie preskakovanie snímkov. Spôsobuje nesprávne dekódovanie a výstupný obraz môže byť deformovaný!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Postupné prispôsobenie synchronizácie obrazu a zvuku založené na meraní zvukovej odchýlky.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Dynamická zmena úrovne postprocessingu závislá na vyťažení procesoru. Veľkosť ktorú určíte bude maximálna veľkosť. Bežne môžete použiť vysoké nastavenie.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Česky</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Nemecky</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Anglicky</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Španielsky</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francúzsky</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Maďarsky</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Taliansky</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonsky</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation></translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandsky</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Poľsky</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Brazílska Portugalčina</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>RuskyRusky</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovensky</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainsky</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Zjednodušená čínština</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Automatická detekcia&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulharsky</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Zaškrtnutím tejto možnosti môžete znížiť blikanie obrazu, ale môže to spôsobiť, že video nebude zobrazené správne.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turecky</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Grécky</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Fínsky</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Švédsky</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Toto nastavenie špcifikuje pozíciu titulkov v okne s videom. &lt;i&gt;100&lt;/i&gt; znamená úplne naspodu, &lt;i&gt;0&lt;/i&gt; úplne navrchu.</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Srbsky</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Tradičná Čínština</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Nastavenie štýlo pre SSA/ASS titulky. Môže byť použité pre jemné ladenie zobrazenia srt a sub titulkov pomocou SSA/ASS knižnice.&lt;br&gt;Príklad:&lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Klávesnica a myš</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Portugalsky</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Rumunsky</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Nastavenia</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Hlavné</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Umiestnenia</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Vybrať...</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Hľadať...</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Zvuk:</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Titulky</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Font</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Font, ktorý bude použitý pre titulky (a OSD):</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Vybrať...</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Veľkosť</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Automatické škálovanie:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Žiadne automatické škálovanie</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proporcionálne k výške videa</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proporcionálne k šírke videa</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proporcionálne k diagonále videa</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Škálovnie:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Automatické načítanie</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Automatické načítanie titulkov (*.srt,*.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Rovnaké ako názov filmu</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Všetky titulky obsahujúce názov filmu</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Všetky titulky v adresári</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Automaticky vybrať prvé možné titulky</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Použiť SSA/ASS knižnicu pre renderovanie titulkov</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Možnosti:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Video filtre:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Zvukové filtre:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Použiť</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušiť</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF font:</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Systémový font:</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Zakázať šetrič obrazovky</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nikdy</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Kedykoľvek to bude nutné</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Iba pri načítaní videa</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Cache:</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Adresár pre uloženie snímkov videa:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Použi softwarový video ekvalizér</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Použi softwarové ovládanie hlasitosti</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Metóda zväčšenia hlavného okna:</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Farba textu:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Farba orámovania:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Rozšírené</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Výkon</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorita:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>najvyššia</translation>
    </message>
    <message>
        <source>high</source>
        <translation>vysoká</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>viac ako normálna</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normálna</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>nižšia ako normálna</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>nízka</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Preskakovanie snímkov</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Časté preskakovanie snímkov (môže spôsobiť poškodenie výstupného obrazu)</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>DVD zariadenie:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>CD zariadenie:</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Nastavenia médií</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Zapamätať nastavenia pre všetky súbor (zvuková stopa, titulky, ...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Nepamätať pozíciu času vo filme (súbory prehrávať vždy od začiatku)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Štýl:</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Pomer strán monitoru:</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Prehrávať video v režime celej obrazovky</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Zariadenia</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Automatická kvalite pre postprocessing filtre:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Kvalita:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Nízka</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Vysoká</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Výstupné zariadenie</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Synchronizácia</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Automatická synchronizácia obrazu a zvuku</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Štandardné kódovanie titulkov:</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(cache bude zakázaná a nie je garantované, že to bude fungovať)</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Rýchly posuv v kapitolách na DVD</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Cache zvýši výkon na pomalých médiách</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Rýchle prepínanie zvukových stôp</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Zobraziť titulky na snímkoch obrazovky</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Jediná inštancia</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Vždy iba jedna inštancia programu SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer bude na tomto porte prijímať príkazy z druhej inštancie:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(zmeny v tejto skupine vyžadujú reštart programu SMPlayer)</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Ďalšie video filtre.
Oddeľujte ich čiarkami  &quot;,&quot;. Nepoužívajte medzery
Príklad: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Zvukové filtre. Rovnaké pravidlá ako video filtre.
Príklad: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>SMPlayer momentálne nerobí autodetekciu CD alebo DVD zariadení. Ak chcete prehrávať CD alebo DVD disky, musíte najprv vybrať vaše zariadenia (môžu byť použité tie isté).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Posledné použité súbory</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Maximum položiek</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Vyčistiť zoznam</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Posuv</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Hlasitosť</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Štandardná hlasitosť:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Myš</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Funkcie tlačítok:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Dvojklik</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Ľavé tlačítko</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Veľkosť okna</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Rozhranie</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Funkcia koliečka:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Stredný posuv</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Ovládanie hlasitosti</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Myš a klávesnica</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Klávesnica</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logy</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Táto možnosť je používaná pre odhaľovanie chýb v aplikácií.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Jazyk:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Sada ikon:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Preferovaná zvuková stopa a titulky</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Titulky:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>umiestnenie programu MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Spustiť MPlayer vo vlastnom okne</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Ďalšie nastavenia pre MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Ďalšie možnosťi pre MPlayer.
Píšte ich oddelené medzerou
Príklad: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Priorita procesu MPlayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Logovať výstup programu MPlayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Logovať výstup programu SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filter pre SMPlayer logy:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Neprekresľuj pozadie okna s videom</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Zmena klávesových skratiek. V stĺpci skratky dopíšte do vybranej bunky skratku. Môžete uložiť zoznam skratiek do súboru a poslať svojim známym, alebo použiť tento súbor na inom počítači.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Vybrať prvé možné titulky</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Pozícia</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Štandardná pozícia titulikov na obrazovke</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Zmeniť...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Navrchu</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Naspodu</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Štýly:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Použiť cache</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Veľkosť:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS pass-through S/PDIF</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Koniec súboru:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>No video:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Titulky</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>Použiť možnosť &lt;i&gt;-subfont&lt;/i&gt; (vyžadované určitými verziami programu MPlayer)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>SSA/&amp;ASS knižnica</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>Nová SSA/ASS knižnica umožňuje krajšie zobrazenie titulkov pre externé titulky a Matroska stopy. Môže byť však použitá aj pre renderovanie iných formátov, ako napríklad .sub a .srt súbory.</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>&amp;Rozšírené</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>&amp;Logy</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>&amp;Jazyk programu MPlayer</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>SMPlayer potrebuje čítať a parsovať výžstup programu MPlayer. Niekedy je výstup závislý na anglickom texte. Ak používate lokalizovanú verziu programu MPlayer (iný jazyk ako angličtina), musíte zmeniť text, podľa ktorého SMPlayer vyhľadáva. (Technicky povedané, musíte zadať regulárny výraz).&lt;br&gt;&lt;br&gt;
Rozbaľovací zoznam môže obsahovať výrazy pre niektoré jazyky.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Klávesnica</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Myš</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation>Max. amplifikácia:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation>Normalizácia hlasitosti</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation>Povoliť postprocessing pre všetky videá</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Kvalita:</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation>Nastavenie štýlo pre SSA/ASS titulky. Môže byť použité pre jemné ladenie zobrazenia srt a sub titulkov pomocou SSA/ASS knižnice.&lt;br&gt;Príklad:&lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 sekunda</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 sekúnd</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 minút</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 minút a %2 sekúnd</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 minúta</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 minúta a 1 sekunda</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 minúta a %1 sekúnd</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 minút a 1 sekunda</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation></translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
    <message>
        <source>label</source>
        <translation>popis</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Jas</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Odtieň</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Saturácia</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>Equalizer</source>
        <translation>Ekvalizér</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Nastaviť ako štandardnú hodnotu</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Použije aktuálne nastavenie ako štandardné hodnoty pre nové videá.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Vynulovať všetky nastavenia ekvalizéru.</translation>
    </message>
</context>
</TS>
