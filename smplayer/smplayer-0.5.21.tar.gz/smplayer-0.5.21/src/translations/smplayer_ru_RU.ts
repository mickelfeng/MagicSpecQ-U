<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Графическая оболочка для mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Разработчик</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>O&amp;K</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Версия: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Версия Qt: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Это свободное программное обеспечение; Вы можете распространять его и/или изменять руководствуясь 2 или (на ваше усмотрение) более поздней версией GNU General Public License опубликованной Free Software Foundation.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Переводчики:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Словацкий</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Итальянский</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Французский</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Упрощенный китайский</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Венгерский</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Японский</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Украинский</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Бразильский португальский</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Грузинский</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Чешский</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Дизайн логотипа: %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Получить обновления на: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>О SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 и %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Польский</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Скомпилированно с поддержкой KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Болгарский</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Тюркская</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Шведский</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Сербский</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Китайский традиционный</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Румынский</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Португальский (Португалия)</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Ярлык</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Горячие клавиши</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Выберите имя файла</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 существует.
Перезаписать?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файл не может быть сохранен</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Файл не может быть загружен</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Файл...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>&amp;Каталог...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Список...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD с привода</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD из каталога...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>Воспро&amp;изведение</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Пауза</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Стоп</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Шаг кадров</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>Пов&amp;торить</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Нормальная скорость</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Половинная скорость</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Удвоенная скорость</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Скорость &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Скорость &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>Ск&amp;орость</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>Н&amp;а весь экран</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Компактный режим</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Эквалайзер</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>Снимок эк&amp;рана</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>Повер&amp;х других окон</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Постпроцессинг</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Автоопределение фазы</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Добавить ш&amp;ум</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>Ф&amp;ильтры</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Выключить звук</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Громкость &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Громкость &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Задержка -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>З&amp;адержка +</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Расширенное стерео</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Караоке</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Фильтры</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Открыть...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Задержка &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Задержка &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>В&amp;верх</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>В&amp;низ</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Список</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Показать счетчик кадров</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>Смотреть от&amp;четы</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>О &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>О &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Открыть</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>Воспро&amp;изведение</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Видео</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>Зв&amp;ук</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>Су&amp;бтитры</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>Об&amp;зор</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>Спр&amp;авка</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>Посл&amp;едние файлы</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>О&amp;чистить</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>Ра&amp;змер</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Соотношение сторон</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlace</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>De&amp;noise</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Автоопределение</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;к 16:9</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Ничего</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>О&amp;бычный</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>М&amp;гкий</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Дорожка</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Каналы</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Стерео режим</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;По-умолчанию</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Стерео</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 окружение</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 окружение</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Левый канал</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Правый канал</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Выбрать</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Заголовок</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Глава</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Ракурс</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>Запре&amp;щено</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Прогресс</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Время</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Время + О&amp;бщее время</translation>
    </message>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - отчеты mplayer</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - отчеты smplayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;ничего&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Список</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Информация</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Приводы CD/DVD еще не настроены.
Вы сможете сделать это в диалоге настроек этих устройст.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>О Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Воспроизводится %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Воспроизведение / Пауза</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Пауза / Покадровый просмотр</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Выгрузить</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Внимание</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Порт %1 уже используется другим приложением.
Не могу запустить сервер.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Сервер не отвечает через порт %1.
Возможность удаленного доступа запрещена.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Показать ин&amp;формацию и параметры...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Зум &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Зум &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Переместить в&amp;лево</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Переместить в&amp;право</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Переместить в&amp;верх</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Переместить в&amp;низ</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Панорама вручную</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Предыдущая фраза субтитров</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>&amp;Следующая фраза субтитров</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Уменьшить громкость (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Увеличить громкость (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Выйти из поноэкранного режима</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Следующая фраза</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Уменьшить контраст</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Повысить контраст</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Уменьшить яркость</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Повысит яркость</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Уменьшить цветность</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Повысить цветность</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Уменьшить насыщенность</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Уменьшить гамму</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Следующая звуковая дорожка</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Следующая фраза</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Следующий раздел</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Предыдущий раздел</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Повысить насыщенность</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Повысить гамму</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation>Двойной размер</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>&amp;Загрузить внешний файл...</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (обычный)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (удвоенная частота кадров)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>С&amp;ледующий</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Предыдущий</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Нормализация звука</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer запущен</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>&amp;Показать пиктограмму в системном лотке</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Убрать</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Восстановить</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>Посл&amp;едние файлы</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>В&amp;ыход</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Яркость: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Контрастность: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Гамма: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Цвет: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Насыщенность: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Громкость: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Зум: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Добро пожаловать в SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Список</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Главная панель</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Языковая панель</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Панели</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Восточная Европа</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Восточная Европа с Евро</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Кириллица/Центральная Европа</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Эсперанто, Гальский, Мальтийский, Тюркский</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Балтийская старая</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Кириллица</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Арабская</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Греческая новая</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Тюркская</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Балтийская</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Кельтская</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Иврит</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Русская</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Украинская, Белорусская</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Китайская упрощенная</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Китайская традиционная</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Японская</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Корейская</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Тайская</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Кириллица Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Кириллица/Центральная Европа Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>Ползунок эквалайзера</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>пиктограмма</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Параметры файла</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Информация</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>В&amp;ыберите demuxer, который будет использоваться для этого файла:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>В&amp;идео кодек</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>Вы&amp;берите видео кодек:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>А&amp;удио кодек</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>Выб&amp;ерите аудио кодек:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>Настройки &amp;MPlayer</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Настройки:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Также Вы можете передать дополнительные фильтры видео.
Разделять запятой. Не использовать пробелы!
Пример: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>&amp;Видео фильтры:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Фильтры звука. Используются аналогично фильтрам видео.
Пример: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>Аудио &amp;фильтры:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>O&amp;K</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Применить</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>О&amp;тмена</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Дополнительные параметры для MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Здесь можно указать дополнительные параметры для MPlayer.
Указывайте их разделяя пробелами.
Например: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Главное</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Путь</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 КБ (%2 МБ)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Продолжительность</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Исполнитель</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Дорожка</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Авторское право</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Примечание</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Программа</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Информация о клипе</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Разрешение экрана</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Битрэйт</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 кб/с</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Кадров в секунду</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Выбранный кодек</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Звуковая дорожка по-умолчанию</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Частота</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Каналы</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Звуковые дорожки</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>ничего</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Название потока</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>Адрес потока</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Воспроизвести DVD из каталога</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Вы можете открыть DVD с жесткого диска. Выберите каталог, содержащий VIDEO_TS и AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Выберите каталог...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>O&amp;K</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>О&amp;тмена</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Выберите имя файла для сохранения</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Файл существует.
Перезаписать?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Невозможно сохранить отчет</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Окно отчета</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Копировать в буфер обмена</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Продолжительность</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>Воспро&amp;изведение</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Редактировать</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Список</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Выберите имя файла</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 существует.
Перезаписать?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Выберите один или более файлов</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Изменить имя</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Введите имя, которое будет соответствовать в списке этому файлу:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>С&amp;ледующий</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Предыдущий</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Переместить в&amp;верх</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Переместить в&amp;низ</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>Пов&amp;торить</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>Пере&amp;тасовать</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Добавить &amp;текущий файл</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Добавить &amp;файл(ы)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Добавить &amp;каталог</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Убрать в&amp;ыбранные</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Убрать в&amp;се</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Список</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Добавить...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Убрать...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Список воспроизведения изменен</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Изменения не сохраенены, желаете сохранить список воспроизведения?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Главное</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Диски</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Быстродействие</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Дополнительно</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Пути</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Выбрать исполняемый файл mplayer</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Шрифты Truetype</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Выбрать ttf файл</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Маленький шаг</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Средний шаг</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Длинный шаг</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Шаг колеса мыши</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ничего</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Внешний вид</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Здесь вы можете указать каталог, куда smplayer будет сохранять снимки экрана. Если каталог не указан, создание снимков будет запрещено.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Выберите драйвер вывода изображения на экран. Обычно xv (для linux) и directx (для windows) обеспечивают наибольшую производительность.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Выберите драйвер вывода для звука.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Вы можете поробывать эту опцию, если эквалайзер не поддерживается вашей видео-картой, или выбранным драйвером вывода видео.&lt;br&gt;&lt;b&gt;Обратите внимание:&lt;/b&gt;эта опция несовместима с некоторыми драйверами вывода видео.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Попробуйте эту опцию для использования программного микшера вместо аппаратного.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Если вы выберите эту опцию, smplaer будет проигрывать все файлы с начала.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Если эта опция выбрана, все видео будет воспроизводиться &quot;На весь экран&quot; с самого начала.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Выберите эту опцию, чтобы запретить хранитель экрана во время воспроизведения.&lt;br&gt;Как только воспроизведение будет закончено, хранитель экрана снова может быть запущен.&lt;br&gt;&lt;b&gt;Обратите внимание:&lt;/b&gt;Это возможно только в X11 и Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Если выбранно, то smplayer будет сохранять сообщения mplayer (вы можете просмотреть их в &lt;b&gt;Настройки-&gt;Смотреть отчеты-&gt;mplayer&lt;/b&gt;).Отчеты могут содержать важную информацию возникших проблемах.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Если выбранно, smplayer сохраняет сообщения программы (их можно просмотреть в &lt;b&gt;Настройки-&gt;Смотреть отчеты-&gt;smplayer&lt;/b&gt;). Эта информация может быть очень полезна разработчику в случае, если будет найдена ошибка.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Эта опция позволяет фильтровать сообщения сохраняемые в отчете с помощью регулярных выражений.&lt;br&gt;Например: &lt;i&gt;^Core::.*&lt;/i&gt; будут отображаться только строки с &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Обратите внимание:&lt;/b&gt; Эти настройки только Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>По-умолчанию</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Утсновите приоритет mplayer как стандартный для Windows..&lt;br&gt;&lt;b&gt;ОСТОРОЖНО:&lt;/b&gt; Использование приоритета реального времени может заблокировать систему.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>По-умолчанию smplayer запоминает настройки каждого файла, кторый проигрывается (звуковая дорожка, громкость, фильтры...). Если вам не нравится эта особенность, вы можете ее отключить.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Здесь вы можете указать предпочитаемый язык для звуковых дорожек. Если проигрываемый фильм содержит несколько звуковых дорожек, то smplayer будет использовать ту, которая соответствует вашим предпочтениям.&lt;br&gt;Все сказанное верно для тех типов мультимедия, которые содержат информацию о языке звуковых дорожек, таких как DVD или mkv.&lt;br&gt;Также можно использовать регулярные выражения. Например: &lt;b&gt;es|esp|spa&lt;/b&gt; означает, что будет выбрана звуковая дорожка содержащая в названии языка &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Здесь вы можете указать предпочитаемый язык для субтитров. Если проигрываемый фильм содержит субтитры на разных языках, то smplayer будет использовать те, которые соответствуют вашим предпочтениям.&lt;br&gt;Все сказанное верно для тех типов мультимедия, которые содержат информацию о языке субтитров, таких как DVD или mkv.&lt;br&gt;Также можно использовать регулярные выражения. Например: &lt;b&gt;es|esp|spa&lt;/b&gt; означает, что будут выбраны субтитры содержащие в названии языка &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Изменить размер буфера (в килобайтах). Особенно полезно для требовательных к ресурсам компьютера фильмов.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Пропускать кадры для поддержки аудио/видео синхронизации.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Более жесткое пропускание кадров (рваное воспроизведение). Приводит к искажению картинки!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Плавная аудио/видео синхронизация, основанная на изменении длинны звуковой дорожки.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Динамическое изменение степени постпроцессинга в зависимости от количества свободного процессорного времени. Указанное вами число будет соответствовать максимальному уровню.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Чешский</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Английский</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Испанский</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Французский</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Венгерский</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Итальянский</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Японский</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Грузинский</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Польский</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Бразильский португальский</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Словацкий</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Украинский</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Упрощенный китайский</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Автоопределение&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Болгарский</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Использование этого параметра может убрать моргание изображения, однако возможно, что видео при этом будет отображаться неверно.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Тюркская</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Греческий</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Финский</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Шведский</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Этот параметр определяет положение субтитров относительно окна. &lt;i&gt;100&lt;/i&gt; означает низ, &lt;i&gt;0&lt;/i&gt; - верх.</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Сербский</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Китайский традиционный</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Здесь можно указать стиль SSA/ASS субтитров. Также можно настроить отрисовку srt и sub субтитров с помощью библиотеки SSA/ASS.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Клавиатура и мышь</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Португальский (Португалия)</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Румынский</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Предпочтения</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Главное</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Пути</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Поиск...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Выбор...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Каталог для сохранения снимков:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Устройство вывода</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Видео:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Звук:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Использовать программный эквалайзер видео</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Использовать программный контроль громкости</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Настройки медиа</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Запомнить настройки для всех файлов (звуковые дорожки, субтитры...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Не запоминать позицию времени (файлы стартуют сначала)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Открывать видео на весь экран</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Включать субтитры в снимки экрана</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Выберите шрифт для субтитров (и OSD):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>Шрифт TTF:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Выбор...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Системный шрифт:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Автомасштабирование:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Без автомасштабирования</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Пропорциональко к высоте клипа</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Пропорционально к ширине клипа</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Пропорционально к диагонали клипа</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Масштаб:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Автооткрытие</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Такое же название как и у фильма</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Подключать субтитры содержащие название фильма</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Все субтитры каталога</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Автозагрузка субтитров (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Кодировка субтитров по умолчанию:</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Использовать библиотеку SSA/ASS для отрисовки субтитров</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Цвет текста:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Цвет края:</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Настройки:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Фильтры видео:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Фильтры звука:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Предпочтения</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Приоритет:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>реальное время</translation>
    </message>
    <message>
        <source>high</source>
        <translation>высокий</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>выше обычного</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>обычный</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>ниже обычного</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>низкий</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Установки кэша могут улучшить или ухудшить быстродействие</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>Кб</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Допускать выпадение кадров</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Допускать жесткое выпадение кадров (может исказить картинку)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Синхронизация</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Автосинхронизация звука/видео</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Показатель:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Автокачество для фильтров постобработки:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Уровень:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Самый низкий</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Самый высокий</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Быстрое переключение звуковых дорожек</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Быстрый поиск глав в DVD</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(кэш должен быть отключен, иначе нормальная работа не гарантируется)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Подавить скринсэйвер</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Соотношения сторон монитора:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Метод изменения размера главного окна:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Когда это нужно</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Только после открытия нового видео</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Стиль:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Устройства</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Выберите Ваш DVD привод:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Выберите Ваш CD привод:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>O&amp;K</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Применить</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>О&amp;тмена</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Также Вы можете передать дополнительные фильтры видео.
Разделять запятой. Не использовать пробелы!
Пример: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Фильтры звука. Используются аналогично фильтрам видео.
Пример: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Образец</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Запускать только один SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer будет ожидать комманд внешних устройств с этого порта:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(эта группа изменений требует перезапуска SMPlayer)</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>SMPlayer не определил cd или dvd приводов. Для проигрывания cd или dvd вы должны указать путь к соответствующим приводам.</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>пиктограмма</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Последние файлы</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Запоминать не более</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Очистить список</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Громкость по умолчанию:</translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Функции кнопки:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Двойной щелчок</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Щелчок левой</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Размер окна</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Внешний вид</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Функция колеса:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Прокрутка</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Регулятор громкости</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Эти настройки восновном необходимы для отладки приложения.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Язык:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Набор пиктограмм:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Предпочитаемые звуковая дорожка и субтитры</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Субтитры:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Укажите исполняемый файл MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Запускать MPlayer в отдельном окне</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Дополнительные параметры MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Здесь можно указать дополнительные параметры для MPlayer.
Указывайте их разделяя пробелами.
Например: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Укажите приоритет процесса для MPlayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Отчет вывода MPlayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Отчет вывода SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Отчеты фильтров SMPlayer:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Не перерисовывать фон области воспроизведения</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Здесь можно изменить горячие клавиши. Чтобы сделать это кликнув мышкой, или, нажав клавишу в необходимой ячейке. Вы можете сохранить список горячих клавишь, чтобы им могли пользоваться другие или использовать его на другом компьютере.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Использовать первые доступные субтитры</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Расположение субтитров на экране по-умолчанию</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Код цвета:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Изменения...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Верх</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Низ</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Стили:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Кеш</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Использовать кеш</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Размер:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS через S/PDIF</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Конец файла:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>Без видео:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>Су&amp;бтитры</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>Использовать параметр -subfont (требуется последними версиями MPlayer)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>SSA/ASS &amp;библиотека</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>Библиотека SSA/ASS позволяет отображать SSA/ASS субтитры и дорожки Matroska. Также она может быть использована для отрисовки других типов (srt, sub) сусбтитров.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Здесь можно указать стиль SSA/ASS субтитров. Также можно настроить отрисовку srt и sub субтитров с помощью библиотеки SSA/ASS.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>&amp;Дополнительно</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>От&amp;четы</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>&amp;Язык MPlayer</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>SMPlayer необходимо получать и обрабатывать вывод MPlayer, который иногда содержит английский текст. Если вы используете MPlayer переведенный на другой язык, то вам необходимо указать какой текст в переведенной версии соответствует оригиналу (для этого вы должны записать соответствующие регулярные выражения).&lt;br&gt;&lt;br&gt;
Нижеприведенный уже содержит регулярные для некоторых языков.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Клавиатура</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Мышь</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation>Зум</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation>Разрешить постобработку для всех видео</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Качество:</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation>Максимальное увеличение:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation>Нормализация громкости</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation>Здесь можно указать стиль SSA/ASS субтитров. Также можно настроить отрисовку srt и sub субтитров с помощью библиотеки SSA/ASS.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt; {2 or 4?}</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 секунда</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 секунд</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 минут</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 минут и %2 секунд</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 минута</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 минута и 1 секунда</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 минута и %1 секунд</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 минут и 1 секунда</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>Поиск (основное)</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>пиктограмма</translation>
    </message>
    <message>
        <source>label</source>
        <translation>метка</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Эквалайзер</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Контрастность</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Яркость</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Насыщенность</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Гамма</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Установки по-умолчанию</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Использовать данные настройки по-умолчанию для новых файлов.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Установить все значаения на ноль.</translation>
    </message>
</context>
</TS>
