<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Nakładka graficzna mplayer-a</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Plik do otwarcia</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Programista</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Wersja: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Wersja Qt: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Ten program jest darmowy; możesz go redystrybuować i/lub modyfikować na warunkach GNU General Public License wydanej przez Free Software Foundation; albo wersja 2 licencji, lub (twój wybór) każdą późniejszą wersję.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Tłumacze:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>German</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovak</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italian</translation>
    </message>
    <message>
        <source>French</source>
        <translation>French</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Simplified-Chinese</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russian</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Hungarian</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japanese</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Dutch</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainian</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Brazilian Portuguese</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgian</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Czech</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo wykonane przez %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Sprawdź uaktualnienia : %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>O SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 i %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polski</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Kompilowany ze wsparciem dla KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgarian</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Swedish</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbian</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Traditional Chinese</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romanian</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Portuguese from Portugal</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Klawisz skrótu</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Zapisz</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Wczytaj</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Pliki Key</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Wybierz nazwę pliku</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Nadpisać?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Plik %1 istnieje
Nadpisać?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Wybierz plik</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Plik nie może zostać zapisany</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Plik nie może zostać wczytany</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer log</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer log</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Otwórz</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Odtwarzanie</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Wideo</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Napisy</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Przeglądaj</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>Op&amp;cje</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Pomoc</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Plik ...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>K&amp;atalog...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Lista odtwarzania...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD z napędu</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD z katalogu...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Wyczyść</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Ostatnio otwierane pliki</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>O&amp;dtwarzaj</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pauza</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Krok</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normala prędkość</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Połowa prędkości</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Podwójna prędkość</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Prędkość &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Prędkość &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Prędkość</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Powtarzaj</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Pełny ekran</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Ukryj menu i przyciski</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>Ro&amp;zmiar</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Autodetekcja</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;zu 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Współczynnik proporcji</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Brak</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Liniowy &amp;Mieszany</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Usuwanie przeplotu</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Przetwarzanie końcowe</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetekcja fazy</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>&amp;Dodaj szum</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>F&amp;iltry</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Korektor</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Zrzut ekranu</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>Z&amp;awsze na wierzchu</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Ścieżka</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtry</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;Domyślne</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Kanały</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Lewy kanał</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Prawy kanał</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Tryb stereo</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Wycisz</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Ciszej &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Głośniej &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Opóźnij audio -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>P&amp;rzyśpiesz audio +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Wybierz</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Wczytaj...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Opóźnij napisy &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Przyśpiesz napisy &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Przesuń napisy w górę</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;Przesuń napisy w dół</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Tytuł</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Rozdział</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Kąt widzenia</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Lista odtwarzania</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Pokaż licznik klatek</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Wyłączone</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Pasek wyszukiwania</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Czas</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Czas +C&amp;ałkowity czas</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Pokaż logi</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Ustawienia</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>O &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>O &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;brak&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Wideo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Listy odtwarzania</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Wszystkie pliki</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Wybierz plik</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Informacje</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM / DVD nie jest jeszcze skonfigurowany.
Zobaczysz zaraz dialog konfiguracji i możesz dokonać ustaweń.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Wybierz katalog</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Napisy</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>O... Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Odtwarzanie %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pauza</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>Od&amp;szumianie</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormalne</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Programowe</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Odtwarzaj / Pauza</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pauza / Krok</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>W&amp;yładuj</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Uwaga</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Port %1 jest obecnie używany przez inny program.
Nie można uruchomić serwera.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Serwer na porcie %1 nie odpowiada.
Opcja pojedyńczego uruchomienia została wyłączona.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Wyjdź</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Z&amp;amknij</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Pokaż &amp;informację i właściwości...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Przesuń w &amp;lewo</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Przesuń w &amp;prawo</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Przesuń w &amp;górę</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Przesuń w &amp;dół</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Pan &amp;&amp; scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Poprzedni wiersz napisów</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>N&amp;astępny wiersz napisów</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Zmniejsz głośność (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Zwiększ głośność (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Wyjdź z pełnego ekranu</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD-następny poziom</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Zmniejsz kontrast</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Zwiększ kontrast</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Zmniesz jasność</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Zwiększ jasność</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Zmniejsz odcień</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Zwiększ odcień</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Zmniejsz saturację</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Zmniejsz gamma</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Następne audio</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Następne napisy</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Następny rozdział</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Poprzedni rozdział</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Zwiększ saturację</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Zwiększ gamma</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation>Podwójny rozmiar</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>&amp;Wczytaj zewnętrzny plik...</translation>
    </message>
    <message>
        <source>Y&amp;adif (mode 1)</source>
        <translation type="obsolete">Y&amp;adif (tryb 1)</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (mode 0)</source>
        <translation type="obsolete">&amp;Yadif (tryb 0)</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normalny)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (podwójna szybkość klatek)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Następny</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>Pop&amp;rzedni</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation>Normalizacja &amp;głośności</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation>&amp;Audio CD</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer nadal działa</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>P&amp;okaż ikonę w tacce systemowej</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Ukryj</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Przywróć</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Ostatnio otwierane pliki</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Wyjdź</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Jasność: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Kontrast: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Odcień: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Nasycenie: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Głośność: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Witaj w SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Głośność</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Napisy</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Lista odtwarzania</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Główny pasek narzędzi</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Pasek wyboru języka dla napisów i ścieżki audio</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Paski narzędzi</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Western European Languages</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Western European Languages with Euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Slavic/Central European Languages</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galician, Maltese, Turkish</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Old Baltic charset</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cyrylica</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabic</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Modern Greek</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Tureski</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Baltic</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Celtic</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Hebrew charsets</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Rosyjski</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrainian, Belarusian</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Simplified Chinese charset</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Traditional Chinese charset</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japanese charsets</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Korean charset</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thai charset</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Cyrillic Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Slavic/Central European Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqSlider</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Ustawienia pliku</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informacja</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Wybierz Demuxer, dla tego pliku:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;Wideo-Kodek</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Wybierz Wideo-Kodek:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>A&amp;udio-Kodek</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Wybierz Audio-Kodek:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>&amp;Opcje Mplayer-a</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Opcje:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Dodatkowe opcje filtrów wideo. 
Wpisz oddzielając wpisy przecinkiem &quot;,&quot;. Nie używaj spacji!
Przykład: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>F&amp;iltry Wideo:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Opcje dla filtrów audio. Takie same zasady jak dla filtrów wideo.
Przykład: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>Filtry &amp;Audio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Zastosuj</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Dodatkowe opcje MPlayer-a</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Tu możesz wpisać dodatkowe opcje MPlayer-a. 
Wpisz oddzielając spacją. 
Przykład: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Ogólne</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Ścieżka</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Długość</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Artysta</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Gatunek</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Track</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentarz</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Oprogramowanie</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Info o klipie</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Wideo</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Rozdzielczość</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Współczynnik proporcji</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Ramek na sekundę</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Użyty dekoder </translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Początkowy strumień audio</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Tempo</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanały</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Strumienie audio</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>brak</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Napisy</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Nazwa strumienia</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>URL strumienia</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Wybierz katalog</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Możesz odtwarzać DVD z dysku.
Wybierz katalog, w którym jest VIDEO_TS i AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Wybierz katalog ...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Odtwórz DVD z katalogu</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Wybierz plik do zapisania</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Nadpisać?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Plik istnieje. 
Nadpisać?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Błąd zapisu pliku</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Log nie zapisany</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Okno logu</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopiuj do schowka</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Długość</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Wybierz plik</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Wybierz nazwę pliku</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Potwierdź nadpisanie?</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Wybierz jeden lub więcej plików do otwarcia</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Wybierz katalog</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Plik %1 istnieje
Nadpisać?</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Edytuj nazwę</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Wpisz nową nazwę dla tego pliku która będzie wyświetlana w liście 
odtwarzania :</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Odtwarzaj</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Edytuj</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Listy odtwarzania</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Wszystkie pliki</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Wczytaj</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Zapisz</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Następny</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>Pop&amp;rzedni</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Przesuń w &amp;górę</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Przesuń w &amp;dół</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Powtarzaj</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>T&amp;asuj</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Dodaj &amp;bieżący plik</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Dodaj &amp;plik(i)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Dodaj &amp;katalog</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Usuń &amp;zaznaczony</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Usuń &amp;wszystko</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer-lista odtwarzania</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Dodaj...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Usuń...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Lista odtwarzania zmodyfikowana</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Tu są niezapisane zmiany, czy chcesz zapisać listę odtwarzania?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Ogólne</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Napisy</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Wybierz plik wykonywalny mplayer-a</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Wybierz TTF - plik</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Wybierz katalog</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Wydajność</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Zaawansowane</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Napędy</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Wykonywalne</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Wszystkie pliki</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Czcionki truetyp</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Mały skok</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Średni skok</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Duży skok</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Skok kółka myszki</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nic</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfejs</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Myszka i klawiatura</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Tutaj podajesz katalog, w którym będą zapisywane zrzuty ekranu wykonane przez smplayer. Jeśli zostawisz to pole puste opcja zrzutów ekranu będzie wyłączona.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Wybierz sterownik wyjściowy wideo. Zwykle xv (Linux) i directx (Windows) dają najlepszą wydajność.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Wybierz sterownik wyjściowy audio.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Zaznacz tą opcję jeśli korektor wideo nie jest obsługiwany przez twoją kartę graficzną lub wybrany sterownik wyjściowy wideo.&lt;br&gt;&lt;b&gt;Notka:&lt;/b&gt;ta opcja nie jest kompatybilna z niektórymi sterownikami wideo.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Zaznacz tą opcję aby użyć programowego miksera, zamiast miksera karty muzycznej.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Gdy ta opcja jest zaznaczona, smplayer będzie odtwarzał wszystkie pliki od początku.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Gdy ta opcja jest zaznaczona wszystkie pliki wideo będą odtwarzane w trybie pełnego ekranu.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Zaznacz tą opcję aby wyłączyć wygaszacz ekranu podczas odtwarzania.&lt;br&gt;Wygaszacz ekranu będzie uruchomiony ponownie po zakończonym odtwarzaniu.&lt;br&gt;&lt;b&gt;Notka:&lt;br&gt;Ta opcja działa tylko w X11 i Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Tutaj musisz podać plik wykonywalny mplayera.&lt;br&gt;minimalna wymagana wersja to 1.0rc1(svn zalecany).&lt;br&gt;&lt;b&gt;Jeśli 
tego nie zrobisz smplayer nie będzie odtwarzać plików!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Jeśli opcja jest zaznaczona, smplayer będzie pamiętał komunikaty z mplayer-a (możesz zobaczyć te komunikaty klikając
 &lt;b&gt;Opcje-&gt;Pokaż logi-&gt;mplayer&lt;/b&gt;). W przypadku problemów ten komunikat będzie miał bardzo ważne informacje, więc zaleca się włączyć tą opcję.
 
</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Jeśli ta opcja jest zaznaczona, smplayer będzie pamiętał komunikaty debugowania (możesz zobaczyć te komunikaty
klikając &lt;b&gt;Opcje-&gt;Pokaż logi-&gt;smplayer&lt;/b&gt;). Ta informacja będzie bardzo przydatna dla programisty jeśli znajdziesz
błąd w programie.

</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Ta opcja pozwala filtrować komunikaty wyjściowe które będą zapamiętane w logu. Wpisz tutaj wyrażenie regularne. &lt;br&gt;Na przykład wpisanie: &lt;i&gt;^Core::.*&lt;/i&gt; pokaże tylko linie zaczynające się od &lt;i&gt;Core::&lt;/i&gt;
</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logi</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Notka:&lt;/b&gt; Ta opcja jest tylko dla Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Domyślne</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Ustaw priorytet procesu mplayer-a zgodnie z hierarchią wartości pod Windows.&lt;br&gt;&lt;b&gt;UWAGA:&lt;/b&gt;Użycie najwyższego priorytetu może być przyczyną niestabilności systemu.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Zwykle smplayer pamięta ustawienia dla każdego odtwarzanego pliku (wybranej ścieżki audio,głośności,fitrów...). Odznacz tą opcję aby tego nie robił.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Tutaj możesz ustawić preferowany język ścieżki dźwiękowej. Jeśli smplayer wykryje więcej niż jedną ścieżkę dźwiękową spróbuje użyć preferowanej.&lt;br&gt;Ta funkcja działa tylko z mediami, które podają informację o ścieżkach dźwiękowych, takie jak DVD lub pliki mkv.&lt;br&gt;To pole akceptuje regularne wyrażenia. Na przykład: &lt;b&gt;es|esp|spa&lt;/b&gt; będzie dobierać ścieżkę dźwiękową odpowiadającą &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; lub &lt;i&gt;spa&lt;/i&gt;.
</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Tutaj możesz ustawić preferowany język napisów. Jeśli smplayer wykryje więcej niż jedną ścieżkę z napisami, spróbuje użyć preferowanej.&lt;br&gt;Ta funkcja działa tylko z mediami, które podają informację o ścieżkach napisów takie jak DVD lub pliki mkv.&lt;br&gt;To pole akceptuje regularne wyrażenia. Na przykład: &lt;b&gt;es|esp|spa&lt;/b&gt; będzie dobierać ścieżkę napisów odpowiadającą &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; lub &lt;i&gt;spa&lt;/i&gt;.
</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Ta opcja precyzuje ile pamięci (w KB) należy użyć dla buforowania pliku lub URL. Zalecane dla wolnych napędów.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Wybranie tej opcji powoduje pomijanie wyświetlania niektórych klatek
aby utrzymać synchronizację A/V na słabszym sprzęcie.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Wybranie tej opcji powoduje mocne pomijanie klatek (błędy w dekodowaniu 
obrazu). Może to powodować zniekształcenia obrazu!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Stopniowa regulacja synchronizacji A/V bazująca na pomiarach opóźnień.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Dynamiczne zmiany przetwarzania końcowego(postprocessing) zależne są od dostępnej wolnej mocy
obliczeniowej procesora (CPU). Poziom który ustawisz będzie maksymalny w użyciu. Zwykle można ustawić
trochę wyższą wartość.
</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Czech</translation>
    </message>
    <message>
        <source>German</source>
        <translation>German</translation>
    </message>
    <message>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Spanish</translation>
    </message>
    <message>
        <source>French</source>
        <translation>French</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Hungarian</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italian</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japanese</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgian</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Dutch</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polski</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Brazilian Portuguese</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russian</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovak</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainian</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Simplified-Chinese</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Autodetekcja&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgarian</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Zaznaczenie tej opcji może zredukować migotanie, ale jednocześnie może spowodować, że obraz wideo nie będzie poprawnie wyświetlany.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Greek</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Finnish</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Swedish</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Ta opcja określa pozycję napisów w wyświetlanym filmie. &lt;i&gt;100&lt;/i&gt; napisy na dole filmu, a &lt;i&gt;0&lt;/i&gt; napisy na górze.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Tutaj możesz zmienić styl wyświetlania napisów poprzez SSA/ASS. Można tego również użyć do zmiany wyglądu wyświetlanych napisów srt i sub przez bibliotekę SSA/ASS.&lt;br&gt;Przykład: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;
</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbian</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Traditional Chinese</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Tutaj możesz zmienić styl wyświetlania napisów za pomocą SSA/ASS. Można tego również użyć do zmiany wyglądu wyświetlanych napisów srt i sub przez bibliotekę SSA/ASS.&lt;br&gt;Przykład: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Klawiatura i myszka</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Portuguese from Portugal</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romanian</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Ustawienia</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Ogólne</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Ścieżka</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Wybierz ...</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Szukaj ...</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Wideo:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Audio:</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Napisy</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Czcionka</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Wybierz czcionkę dla napisów (oraz OSD):</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Wybierz ...</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Autoskalowanie:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Bez autoskalowania</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proporcjonalnie do wysokości</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proporcjonalnie do szerokości</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proporcjonalnie do przekątnej filmu</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Skalowanie:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Autoładowanie</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Automatycznie ładuj napisy (*.srt,*.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Taka sama nazwa jak film</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Wszystkie napisy zawierające nazwę filmu</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Wszystkie napisy w katalogu</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Automatycznie wybierz pierwsze dostępne napisy</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Użyj biblioteki SSA/ASS do wyświetlania napisów</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opcje:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Filtry wideo:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Filtry audio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Zastosuj</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>Czcionka TTF:</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Czcionka systemowa:</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Zablokuj wygaszacz ekranu</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nigdy</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Jeżeli jest taka potrzeba</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Tylko po załadowaniu nowego filmu</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Bufor:</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Katalog dla zrzutów ekranu:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Użyj programowego korektora wideo</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Użyj programowej regulacji głośności</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Metoda zmiany rozmiaru głównego okna:</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Kolor tekstu:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Kolor obwódki:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Zaawansowane</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Wydajność</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorytet:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>realtime</translation>
    </message>
    <message>
        <source>high</source>
        <translation>wysoki</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>poniżej normalego</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normalny</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>powyżej normalnego</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>bezczynny</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Pozwól na pomijanie klatek</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Mocne pomijanie klatek - może spowodować niestabilność wyświetlania</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Wybierz napęd DVD:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Wybierz napęd CD:</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Ustawienia mediów</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Zapamiętaj ustawienia dla wszystkich plików (ścieżki audio, napisy...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Nie zapamiętuj pozycji czasu (start odtwarzania od początku)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Style:</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Rozmiar ekranu:</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Start odtwarzania na pełnym ekranie</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Napędy</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Automatyczna jakość dla filtra przetwarzania końcowego (postprocessing):</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Poziom:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Niższy</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Wyższy</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Sterownik wyjściowy</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Synchronizacja</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Współczynnik:</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Automatyczna synchronizacja Audio/Wideo</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Domyślne kodowanie napisów:</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(bufor zostanie wyłączony i nie ma gwarancji, że to działa)</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Szybkie szukanie rozdziałów w dvd</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Ustawienie bufora. Wczytuje film do pamięci (ustawioną wielkość)
Polepsza to odtwarzanie na wolnych napędach</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Szybkie przełączanie ścieżek audio</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Dołącz napisy w zrzucie ekranu</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Ilość uruchomionych programów jednocześnie</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Użyj tylko jednej uruchomionej kopii programu SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer będzie nasłuchiwał na tym porcie w celu otrzymania komend od innych przypadków:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>( zmiany w tej grupie wymagają restartu SMPlayer-a !)</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Dodatkowe opcje filtrów wideo.
Wpisz oddzielając przecinkiem &quot;,&quot;. Nie używaj spacji!
Przykład: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Opcje dla filtrów audio.Takie same zasady jak dla filtrów wideo.
Przykład: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Aktualnie SMPlayer nie wykrywa automatycznie urządzeń cdrom lub dvd.
Aby odtwarzać z cdrom lub dvd musisz ustawić napęd cdrom i dvd (może być ten sam).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Ostanio otwarte pliki</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Max. pozycji</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Wyczyść listę</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Wyszukiwanie</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Głośność</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Domyślna głośność:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Myszka</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Funkcje przycisku:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Podwójny klik</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Lewy przycisk</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Rozmiar okna</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfejs</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Funkcje kółka:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Pasek postępu odtwarzania</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Kontrola głośności</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Myszka i klawiatura</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Klawiatura</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logi</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Ta opcja jest przeznaczona głównie do debugowania programu.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Język:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Wybierz ikony:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Preferowana ścieżka dźwiękowa i napisy</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Napisy:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorytet</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Wybierz plik wykonywalny MPlayer-a:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Uruchom MPlayer w oddzielnym oknie</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Dodatkowe opcje MPlayer-a</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Tu możesz wpisać dodatkowe opcje MPlayer-a.
Wpisz oddzielając spacją. 
Przykład: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Wybierz priorytet dla MPlayer-a.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Komunikaty wyjściowe MPlayer-a</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Komunikaty wyjściowe SMPlayer-a</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filtr logów SMPlayer-a:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Nie odświeżaj tła okna wideo</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Tutaj możesz zmienić każdy klawisz skrótu. Aby to zrobić kliknij dwa razy w polu klawisza skrótu i przyporządkuj mu klawisz klawiatury. Dodatkowo możesz także zapisać listę aby podzielić się nią z innymi lub wykorzystać na innym komputerze.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Wybierz pierwsze dostępne napisy</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Pozycja</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Domyślna pozycja napisów na ekranie</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Kolor tła okna głownego:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Zmień...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Góra</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Dół</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Style:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Bufor</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Użyj bufora</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Rozmiar:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS pass-through S/PDIF</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Koniec pliku:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>Brak wideo:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Napisy</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>Użyj czcionki subfont (wymaga ostatniej wersji MPlayer-a)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>Biblioteka SSA/&amp;ASS</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>Nowa biblioteka SSA/ASS dostarcza ładny styl napisów dla zewnęrznych plików napisów SSA/ASS i ścieżek Matroska. Będzie ona również użyta do wyświetlania innych formatów takich jak SUB I SRT.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Tutaj możesz zmienić styl wyświetlania napisów za pomocą SSA/ASS. Można tego również użyć do zmiany wyglądu wyświetlanych napisów SRT i SUB przez bibliotekę SSA/ASS.&lt;br&gt;Przykład: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>&amp;Zaawansowane</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>&amp;Logi</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>&amp;Język MPlayer-a</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>Aby odczytać i przeprowadzić analizę tekstu SMplayer potrzebuje danych od programu MPlayer i czasami opiera się na angielskim tekście. Jeśli używasz MPlayer-a przetłumaczonego na inny język, to należy przerobić teksty, których SMPlayer będzie szukał. (Technicznie powinieneś wpisać regularne wyrażenia)&lt;br&gt;&lt;br&gt;
Rozwijalna lista dostarcza już regularne wyrażenia dla kilku języków.

</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Klawiatura</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Myszka</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation>Zoom wideo</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Wideo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation>Maksymalne wzmocnienie:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation>Normalizacja głośności</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation>Włącz postprocessing dla wszystkich plików wideo</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Jakość:</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation>Tutaj możesz zmienić styl wyświetlania napisów za pomocą SSA/ASS. Można tego również użyć do zmiany wyglądu wyświetlanych napisów SRT i SUB przez bibliotekę SSA/ASS .Przykład: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 sekunda</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 sekund</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 minut</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 minut i %2 sekund</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 minuta</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 minuta i 1 sekunda</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 minuta i %1 sekund</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 minut i 1 sekunda</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etykieta</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Jasność</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Odcień</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Nasycenie</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>Equalizer</source>
        <translation>Korektor</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Wyzeruj</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Ustaw wartości jako domyślne</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Użyj aktualnych wartości jako domyślnych dla nowych plików wideo.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Ustaw wszystkie suwaki na zero.</translation>
    </message>
</context>
</TS>
