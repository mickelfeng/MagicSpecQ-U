<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Developer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File to open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Verzió: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt Verzió: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Ez a program egy szabad szoftver; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Fordítók:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Német</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Szlovák</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Olasz</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francia</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Hagyományos-Kínai</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Orosz</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Magyar</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japán</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Hollnad</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrán</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Braziliai Portugál</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Grúz</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Csehszlovák</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>A logo dizájn %1 munkája</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Frissítés beszerezhető innen : %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>SMPlayer névjegye</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="unfinished">Lengyel</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Török</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Név</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished">&amp;Mentés</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation type="unfinished">&amp;Betölt</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation type="unfinished">Válasszon egy fájlnevet</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished">Valóban felülírja ?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished">%1 fájl már létezik.
Valóban felül akarja írni ?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished">Válasszon egy fájlt</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Fájl...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>&amp;Könyvtár...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>Lejátszóli&amp;sta...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD lemez lejátszás </translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD lejátszás könyvtárból...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>Le&amp;játszás</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Szünet</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Megállít</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Képkocka léptetés</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Ismétlés</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normál sebesség</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Fél sebesség</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Dupla sebesség</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Sebesség&amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Sebesség &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Sebesség</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Teljes képernyő</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Kompakt mód</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Kiegyenlítő (EQ)</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Képernyőkép</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>Mindig &amp;felül</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocessing</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Automatikus szakasz</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation type="unfinished">&amp;</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>S&amp;zűrők</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Némítás</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Hangerő &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Hangerő &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Késleltetés -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>Ké&amp;sleltetés +</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extra sztereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Szűrők</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Betöltés...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Késleltetés &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Késleltetés &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Fel</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;Le</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>Lejátszól&amp;ista</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Képkocka számolás megjelenítése</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Beállítások</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Naplók megjelenítése</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>&amp;Qt névjegye</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>&amp;SMPlayer névjegye</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Megnyitás</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Lejátszás</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Videó</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Hang</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Feliratok</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Böngészés</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Opciók</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Segítség</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Utoljára megnyított fájlok</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Tisztítás</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Méret</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Képernyő méretarány</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlace</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>De&amp;noise</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Automatikus</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Levélszekrény</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 &amp;Levélszekrény</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Pan keresés</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;erre 16:9</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Nincs</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation type="unfinished">&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>&amp;Lineáris keverés</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormál</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Sáv</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Csatornák</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Sztereo Mód</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>Alap&amp;értelmezett</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Sztereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Hárrérhang</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Hárrérhang</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Bal csatorna</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Jobb csatorna</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Kiválaszt</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Cím</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Fejezet</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Kikapcsolva</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Csúszó skála</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Idő</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Idő + &amp;Teljes idő</translation>
    </message>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer napló</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer napló</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;üres&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Videó</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Hang</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Lejátszólisták</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Minden fájl</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Válasszon egy fájlt</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Információ</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>A CDROM / DVD meghajtó nincs még beállítva.
A beállító panel megjelenik most, állítsa be az eszközöket.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Válasszon egy könyvtárat</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Feliratok</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Qt névjegye</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>%1 lejátszás alatt</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Szünet</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Megállítás</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Lejátszás / Szünet</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Szünet / Képkocka léptetés</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Visszatöltés</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">Ala&amp;phelyzet</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation type="unfinished">Mozgatás &amp;felfelé</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation type="unfinished">Mozgatás &amp;lefelé</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;Következő</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">&amp;Előző</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation type="unfinished">&amp;Utoljára megnyított fájlok</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Fényerő: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Kontrast: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Szinezés: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Telitettség: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Hangerő: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>SMPlayer üdvözli Önt</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Hangerő</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Hang</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Felirat</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Lejátszólista</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Fő eszköztár</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Nyelvi eszköztár</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Eszkötár</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Nyugat-Európai Nyelvek</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Nyugat-Európai Nyelvek Euro-val</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Sláv/Közép-Europai Nyelvek</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galicisch, Máltai, Török</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation></translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cirill</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arab</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Török</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Balti</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Celtic</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Héber kódolás</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Orosz</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrán, Belorusz</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Hagyományos Kínai</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Tradicionális Kínai kódolás</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japán kódolás</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Koreai kódolás</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thai kódolás</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Windows Cirill</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Sláv/Közép-Europai Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqRegler</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>Icon</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation type="unfinished">&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation type="unfinished">&amp;Válassza ki a demuxert amit ehhez a fájlhoz használni fog:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">Ala&amp;phelyzet</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation type="unfinished">&amp;Videó kodek</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation type="unfinished">Vála&amp;ssza ki a videó kodeket:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation type="unfinished">Au&amp;dio kodek</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation type="unfinished">&amp;Válassza ki az audio kodeket:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation type="unfinished">&amp;MPlayer opciók</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation type="unfinished">&amp;Opciók:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="unfinished">Itt tud további videó szűrőket hozzáadni.
Írja őket &quot;,&quot;-vel elválasztva. Ne használja a szóközt!
Például: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation type="unfinished">V&amp;ideó szűrők:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="unfinished">Audio szűrők. Hasonló módon mint a videó szűrők.
Például: mintavétel=44100:0:0,hangnorma</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation type="unfinished">A&amp;udio szűrők:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished">&amp;Alkalmaz</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Mégsem</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation type="unfinished">Általános</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished">Elérési út</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Méret</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation type="unfinished">%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished">URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished">Hossz</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation type="unfinished">Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Név</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation type="unfinished">Előadó</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished">Szerző</translation>
    </message>
    <message>
        <source>Album</source>
        <translation type="unfinished">Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation type="unfinished">Műfaj</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Dátum</translation>
    </message>
    <message>
        <source>Track</source>
        <translation type="unfinished">Sáv</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation type="unfinished">Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">Megjegyzés</translation>
    </message>
    <message>
        <source>Software</source>
        <translation type="unfinished">Szoftver</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation type="unfinished">Klipp Infó</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Videó</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="unfinished">Felbontás</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation type="unfinished">Képernyőméret</translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished">Formátum</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation type="unfinished">Bitráta</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation type="unfinished">%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation type="unfinished">Képkocka / másodperc</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation type="unfinished">Kiválasztott kodek</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation type="unfinished">Elsődleges hang adatfolyam</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished">Érték</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation type="unfinished">%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation type="unfinished">Csatornák</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation type="unfinished">Hang adatfolyamok</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Nyelvezet</translation>
    </message>
    <message>
        <source>empty</source>
        <translation type="unfinished">üres</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="unfinished">Feliratok</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Típus</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Válasszon egy könyvtárat</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Egy DVD-t lejátszhat akár az Ön merevlemezéről is. Ehhez válassza ki azt a könyvtárat ahol a VIDEO_TS and AUDIO_TS fájlok vannak.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Könyvtár választás...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Mégsem</translation>
    </message>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - DVD lejátszása egy könyvtártból</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Válasszon egy fájlnevet a mentéshez</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Valóban felülírja ?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>A fájl már létezik
Valóvan felül akarja írni ?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Hiba a fájl mentésekor</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Naplózás mentése nem sikerült</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Napló ablak</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Mentés</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Másolás a vágólapra</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Bezár</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Bezár</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Név</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Hossz</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Válasszon egy fájlt</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Válasszon egy fájlnevet</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Valóban felülírja ?</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Kiválaszt egy vagy több fájlt a megnyitáshoz</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Válasszon egy könyvtárat</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>%1 fájl már létezik.
Valóban felül akarja írni ?</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Név szerkesztése</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Írjon be egy (új) nevet ennek a fájlnak a megjelenítéséhez:</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Lejátszás</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Szerkesztés</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Lejátszólisták</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Minden fájl</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Betölt</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Mentés</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Következő</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Előző</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Mozgatás &amp;felfelé</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Mozgatás &amp;lefelé</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Ismétlés</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Keverés</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>&amp;Jelenlegi fájl hozzáadása</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Fájl(ok) &amp;hozzáadása</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>&amp;Könyvtár hozzáadása</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Ki&amp;választott eltávolítása</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>&amp;Mind eltávolítása</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Lejátszólista</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Hozzáadás...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Eltávolítás...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Általános</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Feliratok</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Válassza ki az mplayer futtatható fájlt</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Válasszon egy TTF fájlt</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Válasszon egy könyvtárat</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Teljesítmény</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Bővített</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Meghajtók</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Futtathatók</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Minden fájl</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype fontok (*.ttf)</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Rövid ugrás</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Közepes ugrás</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Hosszú ugrás</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Léptetés egérgörgővel</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nincs</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Felület</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Egér és billentyűzet</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Itt kell megadni azt a könyvtárat ahol az smplayer által készített pillanatfelvételeket tárolja. Ha ez a mező üres marad a pillanatkép tulajdonságok ki lesznek kapcsolva.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Válasszon videó kimeneti meghajtót. Általában az xv (Linux) és a directx (Windows) biztosítja a legjobb teljesítményt.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Válasszon kimeneti audio meghajtót.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Jelölje be ezt az opciót ha a videó kiegyenlítő (EQ) nem támogatott a grafikus kártyája vagy a kiválasztott kimeneti meghajtó által.&lt;br&gt;&lt;b&gt;Megjegyzés:&lt;/b&gt; ez az opció nem kompatibilis néhány videó kimeneti meghajtóval.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Az opció bejelölésével szoftveres keverő lesz használva a hangkártya kerverője helyett.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Ha ezt az opciót bejelöli, minden fájl lejátszása az elejéről lesz kezdve.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Ha ezt az opciót bejelöli minden videó teljesképernyős modban lesz lejátszva.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Jelölje be ezt az opciót a képernyőkímélő kikapcsolásához a lejátszás alatt.&lt;br&gt;A képernyőkímélő újra bekapcsol ha a léjátszás befejeződik.&lt;br&gt;&lt;b&gt;Megjegyzés:&lt;/b&gt;Ez az opció csak X11 és Windows alatt működik.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Itt be kell állítanod az mplayer futathatóságát amit az smplayer használni fog. &lt;br&gt; smplayernek igénye van ehez az mplayer 1.0rc1-re (svn ajánlott)&lt;br&gt;&lt;b&gt;Ha ez rosszul van beállítva az smplayer nem fog semmit lejátszani!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Ha bejelöli az smplayer rögzíti az mplayer kimenetét (nézze meg ezt &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). Probléma esetén nagyon fontos információkat tartalmazhat, ezért érdemes ezt az opciót bejelölni.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Ha ezt bejelöli az smplayer rögzíteni fogja a debug üzeneteket az smplayer kimenetéről (nézze meg a naplót itt &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). Ez az információ nagyon hasznos lehet a fejlesztőnek a hibakeresésben.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Ez az opció engedély a szűrőkhöz az smplayer üzenetek rödzítésre kerülnek a naplóban. Ide írjon bármilyen megszokott kifejezést. &lt;br&gt;Kéréshez: &lt;i&gt;^Core::.*&lt;/i&gt; így a megjelenítés a sorokban &lt;i&gt;Core::&lt;/i&gt;-val indul</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Naplók</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Megjegyzés:&lt;/b&gt; Ez az opció csak a Windows-hoz érhető el.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Alapértelmezett</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Az mplayer rendszer-folyamat priorításának beállítása az preferált priorításokhoz ami elérhető a Windows-ban.&lt;br&gt;&lt;b&gt;Figyelem:&lt;/b&gt; A valósidejű priorítás használata rendszervisszacsatolást okozhat.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Általában az smplayer megjegyzi a beállításokat minden általa lejátszott fájlhoz (kiválasztott hangsáv, hangerő, szűrők...). Kapcsolja ki ezt az opciót ha nem akarja ezt a sajátosságot használni.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Itt kell megadnia az elsődleges nyelv típusát a hang adatfolyamhoz. Amennyiben egy média többszörös hang adatfolyamot tartalmaz az smplayer megpróbálja használni az Ön elsődleges nyelvét.&lt;br&gt;Ez csak akkor fog működni a médiával ha a hang adatfolyamok infomációjában van ilyen nyelv mint a DVD vagy mkv fájloknál.&lt;br&gt;Ha ezt elfogadja mindig ez lesz használva.Például: &lt;b&gt;es|esp|spa&lt;/b&gt; így választjuk ki hangsávokat hogy egyezzen ezekkel &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Itt kell megadnia az elsődleges nyelv típusát a felirat adatfolyamhoz. Amennyiben egy média többféle felirat adatfolyamot tartalmaz akkor az smplayer megpróbálja használni az Ön elsődleges nyelvét.&lt;br&gt;Ez csak akkor fog működni a médiával ha a hang adatfolyamok infomációjában van ilyen nyelv mint a DVD vagy mkv fájloknál.&lt;br&gt;Ha ezt elfogadja mindig ez lesz használva.Például: &lt;b&gt;es|esp|spa&lt;/b&gt; így választjuk ki hangsávokat hogy egyezzen ezekkel &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>
Ez az opció adja meg, hogy mennyi memóriát(kBytekben) használjon az újratároláshoz egy file vagy url. Legjobb lassú médiákhoz.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Vessen el a megjelenító pár képet a A/V szinkronizálásból lassú rendszeren.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Intenzívebb képdobás (dekódolás törés). Képtorzuláshoz vezethet!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Fokozatosan igazítja az A/V szinkron bázist az audio késleltetés mérésen.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>A postprocessing igénye szerint a szint dinamikus váltása az elérhető tartalék CPU időn. Az általad megadott szám lesz a maximum használt szint. Általában használhatsz nagy számot is.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Csehszlovák</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Német</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Angol</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Spanyol</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francia</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Magyar</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Olasz</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japán</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Grúz</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Hollnad</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Lengyel</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Braziliai Portugál</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Orosz</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Szlovák</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrán</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Hagyományos-Kínai</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Automatikus&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Török</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Beállítások</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Általános</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Elérési utak</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Kiválaszt...</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Keresés...</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Videó:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Hang:</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Feliratok</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Betűtípusok</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Válasszon egy fontot a feliratokhoz (OSD is):</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Válasszon...</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Méret</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Automatikus méret:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Nincs automatikus méretezés</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>A film magasságához megfelelő</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>A film szélességéhez megfelelő</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>A film átlójához megfelelő</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Arány:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Automatikus betöltés</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Feliratok automatikus betöltése (*.srt,*.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Azonos névvel mint a film</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Minden felirat ami tartalmazza a film nevét</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Minden felirat a könyvtárban</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Az első elérhető felirat automatikus kiválasztása</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>SSA/ASS programkönyvtár használata a felirat rendereléshez</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opciók:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Videó szűrők:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Audio szűrők:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Alkalmaz</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Mégsem</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF font:</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Rendszer font:</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Képernyőkimélő kikapcsolása</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Soha</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Valahányszor ha szükséges</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Betöltés egy új video után</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Gyorsítótár:</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Könyvtár a képernyőmentések tárolásához:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Szoftveres videó kiegyenlítő (EQ) használata</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Szoftveres hangerő szabályzás használata</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Főablak átméretezési mód:</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Szöveg szín:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Keret színe:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Haladó</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Teljesítmény</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorität:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>Valósidejű</translation>
    </message>
    <message>
        <source>high</source>
        <translation>magas</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>abovenormal</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>Normál</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>belownormal</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>tétlen</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Kép eldobás engedélyezése</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Engedélyezi a durva kép eldobást (képminőség romláshoz vezethet)</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>DVD eszköz kiválasztása (pl:/dev/dvd):</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>CD eszköz kiválasztása (pl:/dev/cdrom):</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Média-beállítások</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Jegyezze meg a beállításokat minden fájlhoz (hangsávok, feliratok...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Ne jegyezze meg az idő-poziciót ( a fájl lejátszását az elejéről kezdi )</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Stílus:</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Monitor méret:</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Videók indítása teljes képrenyős módban történjen</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Meghajtók</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Automatikus minőség a postprocessing szűrőhöz:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Szint:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Alacsonyabb</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Magasabb</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Kimeneti meghajtók</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Szinkronizáció</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Automatikus Audio/Video Sziknkronizálás</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Alapértelmezett felirat kódolás:</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>A gyorsítótár kikapcsolása nem garanált a helyes működés</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Gyors léptetés a fejezetekhez a dvd-ken</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Állítson be egy gyorsítótárat, a lassú média teljesítményét megnövelheti</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Gyors hangsáv váltás</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Feliratok beépítése a képernyőmentésbe</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Itt tud további videó szűrőket hozzáadni.
Írja őket &quot;,&quot;-vel elválasztva. Ne használja a szóközt!
Például: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Audio szűrők. Hasonló módon mint a videó szűrők.
Például: mintavétel=44100:0:0,hangnorma</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Egyszerű kérés</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Csak egy példány futhat az SMplayer-ből</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>MPlayer figyelni fog erre a portra, hogy kérésre parancsokat fogadjon:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(a válozásokhoz ezen a csoporton, szükség van az SMplayer újraindítására)</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Az SMPlayer lehet, hogy nem tudta automatikusan felismerni a cd vagy dvd eszközöket. A lejátszáshoz most választani kell egy cdrom vagy dvd eszközt (lehet a két eszköz azonos).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>Ikon</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Utoljára megnyított fájlok</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Elemek maximális száma</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Lista tisztítása</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Léptetés</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Hangerő</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Alapértelmezett hangerő:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Egér</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Gomb műveletek:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Dupla kattintás</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Bal kattintás</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Ablak méret</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Felület</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Görgő funkció:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Média léptetés</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Hangerő szabályzó</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Egér és billentyűzet</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Billentyűzet</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Naplók</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Ez az opció főleg az alkalmazás hibakereséséhez szükséges.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Nyelvezet:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Ikon készlet:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Preferált hang és felirat</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Feliratok:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorítás</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">&amp;Feliratok</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Videó</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Hang</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
    <message>
        <source>label</source>
        <translation>fül</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Contrast</source>
        <translation>Kontraszt</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Fényerő</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Szinezés</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Telítettség</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>Equalizer</source>
        <translation>Equalizer</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>Ala&amp;phelyzet</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>Alapértékek &amp;visszaállítása</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>A jelenlegi értékek használata mint alapérték az új videókhoz.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Minden vezérlő nullára állítása.</translation>
    </message>
</context>
</TS>
