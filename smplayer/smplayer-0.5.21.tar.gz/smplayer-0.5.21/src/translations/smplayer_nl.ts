<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Front-end voor mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Bestand om te openen</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Ontwikkelaar</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Versie: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt versie: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Dit programma is vrije software; u kan het verspreiden en/of wijzigen onder de bepalingen van de GNU Algemene Publieke Licentie, zoals uitgegeven door de Free Software Foundation; oftewel versie 2 van de Licentie, of (naar vrije keuze) een latere versie.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Vertalers:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Duits</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slowaak</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiaans</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Frans</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Vereenvoudigd Chinees</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russisch</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Hongaars</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japans</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Nederlands</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Oekraïens</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Braziliaans Portugees</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgisch</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tsjechisch</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo ontworpen door %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Verkrijg updates via: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>Over SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 en %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Pools</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Gecompileerd met KDE ondersteuning</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgaars</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turks</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Zweeds</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Omschrijving</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Sneltoets</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Opslaan</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Laden</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Sleutel bestanden</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Kies een bestandsnaam</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Bevestig overschrijven?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Het bestand bestaat al.
Wil je het overschrijven?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Kies een bestand</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Foutmelding</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Het bestand kon niet opgeslagen worden</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Het bestand kon niet ingeladen worden</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer log</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer log</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Openen</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>Af&amp;spelen</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>O&amp;ndertitels</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Bladeren</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>Op&amp;ties</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Help</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Bestand...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>&amp;Map...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Afspeellijst...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD vanaf schijfstation</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD vanaf map...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Leegmaken</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Recente bestanden</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Afspelen</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pauzeren</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Stoppen</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Frame stap</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normale snelheid</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Halve snelheid</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Dubbele snelheid</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Snelheid &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Snelheid &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>S&amp;nelheid</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Herhalen</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Volledig scherm</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Compacte modus</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Grootte</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Automatisch detecteren</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;naar 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Aspect verhouding</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Geen</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlace</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Nabewerking</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Automatisch fase detecteren</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>N&amp;oise toevoegen</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>F&amp;ilters</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizer</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Schermafdruk</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>Venster &amp;bovenaan houden</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Spoor</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filters</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;Standaard</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Kanalen</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Linkerkanaal</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Rechterkanaal</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Stereo modus</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Dempen</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Vertraging -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>V&amp;ertraging +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Kiezen</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Laden...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Vertraging &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Vertraging &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Omhoog</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>O&amp;mlaag</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Titel</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Hoofdstuk</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>Hoek (&amp;angle)</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Afspeellijst</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Frame teller weergeven</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Uitgeschakeld</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Zoekbalk</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Tijd</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Tijd + T&amp;otale tijd</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>Bekijk &amp;logs</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Voorkeuren</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Over &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>Over &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;leeg&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Afspeellijsten</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle bestanden</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Kies een bestand</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Informatie</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>De CDROM / DVD stations zijn nog niet geconfigureerd.
Het configuratie dialoogvenster zal nu getoond worden, zodat je dit nu kan doen.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Kies een map</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Ondertitels</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Over Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Afspelen van %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pauze</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>De&amp;noise</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormaal</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Zacht</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Afspelen / Pauzeren</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pauze / Frame stap</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>O&amp;ntladen</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Waarschuwing</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Poort %1 is reeds is gebruik door een ander programma.
Kan server niet starten.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Server op poort %1 antwoordt niet.
De enkele instantie optie werd uitgeschakeld.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Afsluiten</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Bekijk &amp;informatie en eigenschappen...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Uitzoomen &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Inzoomen &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Naar &amp;links verplaatsen</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Naar &amp;rechts verplaatsen</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Naar &amp;omhoog verplaatsen</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Naar &amp;beneden verplaatsen</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Pan &amp;&amp; scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Vorige lijn in ondertitels</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>V&amp;olgende lijn in ondertitels</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Volume zachter (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Volume luider (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Volledig scherm verlaten</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Volgende niveau</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Contrast verlagen</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Contrast verhogen</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Helderheid verlagen</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Helderheid verhogen</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Tint verlagen</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Tint verhogen</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Verzadiging verlagen</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Gamma verlagen</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Volgend audiospoor</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Volgende ondertitel</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Volgend hoofdstuk</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Vorig hoofdstuk</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Verzadiging verhogen</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Gamma verhogen</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;Volgende</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">V&amp;orige</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer draait hier nog steeds</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>Icoon in systeemvak &amp;weergeven</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Verbergen</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Herstellen</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Recente bestanden</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">&amp;Afsluiten</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Helderheid: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Contrast: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Tint: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Verzadiging: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Volume: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Welkom bij SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Ondertitel</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Afspeellijst</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Hoofdwerkbalk</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Taalwerkbalk</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Werkbalken</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>West-Europese Talen</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>West-Europese Talen met Euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Slavisch/Centraal-Europese Talen</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galicisch, Maltees, Turks</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Oude Baltische karakterset</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cyrillisch</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabisch</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Modern Grieks</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turks</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Baltisch</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Keltisch</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Hebreeuwse karaktersets</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russisch</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Oekraïens</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Vereenvoudigde Chinese karakterset</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Traditionele Chinese karakterset</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japanse karaktersets</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Koreaanse karakterset</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thaise karakterset</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Cyrillisch Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Slavisch/Centraal-Europees Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqSchuifbalk</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>icoon</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Eigenschappen van bestand</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informatie</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Kies de demuxer die gebruikt moet worden voor dit bestand:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;Video codec</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Kies de video codec:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>A&amp;udio codec</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Kies de audio codec:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>&amp;MPlayer opties</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Opties:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Je kan ook extra video filters meegeven.
De video filters moeten van elkaar gescheiden worden door &quot;,&quot;. Gebruik geen spaties!
Voorbeeld: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideo filters:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>En tot slot audio filters. Dezelfde regel als voor video filters.
Voorbeeld: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>Audio &amp;filters:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Toepassen</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Annuleren</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Extra opties voor MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Hier kan je extra opties meegeven aan MPlayer.
Schrijf ze gescheiden door spaties.
Voorbeeld: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Pad</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Lengte</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Artiest</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Genre</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Spoor</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Auteursrecht</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Clip info</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resolutie</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Aspect verhouding</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formaat</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Frames per seconde</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Geselecteerde codec</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Initieel Audio Spoor</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Rate</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanalen</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Audio Sporen</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Taal</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>leeg</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Ondertitels</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Stream titel</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>Stream URL</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Kies een map</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Speel een DVD vanuit een map</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Je kan een dvd vanaf je harde schijf afspelen. Kies gewoon de map die de submappen VIDEO_TS en AUDIO_TS bevat.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Kies een map...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Annuleren</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Kies een bestandsnaam waaronder opgeslagen moet worden</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Bevestig overschrijven?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Het bestand bestaat al.
Wil je het overschrijven?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Fout bij opslaan van het bestand</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Het logbestand kon niet worden opgeslagen</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Log Venster</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Opslaan</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopiëren naar klembord</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Lengte</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>Af&amp;spelen</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>Aan&amp;passen</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Afspeellijsten</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Kies een bestand</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Kies een bestandsnaam</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Bevestig overschrijven?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Het bestand bestaat al.
Wil je het overschrijven?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle bestanden</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Kies één of meerdere bestanden om te openen</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Kies een map</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Naam aanpassen</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Typ de naam waaronder dit bestand bekend zal staan in de afspeellijst:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Laden</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Opslaan</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Volgende</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>V&amp;orige</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Naar &amp;omhoog verplaatsen</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Naar &amp;beneden verplaatsen</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Herhalen</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Willekeurig</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>&amp;Huidig bestand toevoegen</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>&amp;Bestand(en) toevoegen</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>&amp;Map toevoegen</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Verwijder &amp;geselecteerde</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Verwijder &amp;alles</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Afspeellijst</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Toevoegen...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Verwijderen...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Afspeellijst aangepast</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Er zijn veranderingen gebeurd die nog niet zijn opgeslagen.
Wil je de afspeellijst opslaan?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Schijfstations</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Prestaties</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Ondertitels</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Uitgebreid</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Uitvoerbare bestanden (executables)</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle bestanden</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Kies het mplayer uitvoerbaar bestand</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Kies een map</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype Lettertypes</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Kies een ttf bestand</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Korte sprong</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Middelmatige sprong</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Lange sprong</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Muiswiel sprong</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Muis en toetsenbord</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Hier kan je een map instellen waar de schermafdrukken die door smplayer genomen worden bewaard kunnen worden. Als dit veld leeg is zal de schermafdruk mogelijkheid uitgeschakeld worden.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Kies de video uitvoer driver. Normaal gezien leveren xv (linux) en directx (windows) de beste prestaties.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Kies de audio uitvoer driver.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Je kan deze optie aanvinken als video equalizer niet wordt ondersteund door je grafische kaart of door de geselecteerde video uitvoer driver.&lt;br /&gt;&lt;b&gt;Let op:&lt;/b&gt; deze optie kan incompatibel zijn met sommige video uitvoer drivers.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Vink deze optie aan om de software mixer te gebruiken, in plaats van de geluidskaart mixer.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Als je deze optie aanvinkt, dan zal SMPlayer alle bestanden vanaf het begin afspelen.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Als je deze optie aanvinkt, dan zullen alle videobestanden starten in de modus volledig scherm.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Vink deze optie aan om de schermbeveiliging uit te schakelen tijdens het afspelen.&lt;br /&gt;De screensaver zal terug ingeschakeld worden wanneer het afspelen voltooid is.&lt;br /&gt;&lt;b&gt;Let op:&lt;/b&gt; Deze optie werkt alleen in X11 en Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Hier moet je het mplayer uitvoerbaar bestand kiezen dat smplayer zal gebruiken.&lt;br /&gt;smplayer vereist ten minste mplayer 1.0rc1 (svn aanbevolen)&lt;br /&gt;&lt;b&gt;Als deze instelling foutief is, dan zal smplayer niets kunnen afspelen!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Vink deze optie aan om de uitvoer van mplayer op te slaan (je kan de uitvoer bekijken via &lt;b&gt;Opties-&gt;Bekijk logs-&gt;mplayer&lt;/b&gt;). In het geval van problemen kan deze log belangrijke informatie bevatten, dus het wordt aanbevolen om deze optie aan te vinken.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Vink deze optie aan om de debugberichten van smplayer op te slaan (je kan de berichten bekijken via &lt;b&gt;Opties-&gt;Bekijk logs-&gt;smplayer&lt;/b&gt;). Deze informatie kan heel nuttig zijn voor de ontwikkelaar indien je tegen bugs aanloopt.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Deze optie staat je toe om de smplayer berichten die in het log worden opgeslagen te filteren. Je kan hier eender welke reguliere expressie neerzetten.&lt;br&gt;Bijvoorbeeld: &lt;i&gt;^Core::.*&lt;/i&gt; zal alleen lijnen weergeven die beginnen met &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Opgelet:&lt;/b&gt; Deze optie is alleen voor Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Standaard</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Prioriteit van het mplayer proces instellen volgens de vooraf gedefinieerde prioriteiten die beschikbaar zijn onder Windows.&lt;br&gt;&lt;b&gt;WAARSCHUWING:&lt;/b&gt; Gebruik van realtime prioriteit kan een systeem lockup veroorzaken.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Normaal gezien onthoudt smplayer de instellingen voor elk bestand dat je afspeelt (geselecteerd audio spoor, volume, filters...). Vink deze optie uit als je geen gebruik wilt maken van deze mogelijkheid.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Hier kan je een taalvoorkeur instellen voor audiosporen. Wanneer een mediabestand met meerdere audiosporen wordt gevonden, dan zal smplayer trachten om uw taalvoorkeur te gebruiken.&lt;br&gt;Dit werkt alleen bij mediabestanden die informatie over de taal bij de audiosporen hebben, zoals dvd&apos;s of mkv-bestanden.&lt;br&gt;Dit veld accepteert reguliere expressies. Voorbeeld: &lt;b&gt;es|esp|spa&lt;/b&gt; zal het audiospoor selecteren indien het overeenkomt met &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; of &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Hier kan je een taalvoorkeur instellen voor ingebedde ondertitelingen. Wanneer een mediabestand met meerdere ondertitelingssporen wordt gevonden, dan zal smplayer trachten om uw taalvoorkeur te gebruiken.&lt;br&gt;Dit werkt alleen bij mediabestanden die informatie over de taal bij de ondertitelingssporen hebben, zoals dvd&apos;s of mkv-bestanden.&lt;br&gt;Dit veld accepteert reguliere expressies. Voorbeeld: &lt;b&gt;es|esp|spa&lt;/b&gt; zal het ondertitelingsspoor selecteren indien het overeenkomt met &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; of &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Deze optie bepaalt hoeveel geheugen (in kBytes) gebruikt moet worden bij het precachen van een bestand of URL. Vooral handig bij trage media.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Sommige frames overslaan om A/V sync te behouden op trage systemen.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Meer intense frame dropping (breekt decodering). Leidt tot beeldvervorming!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Geleidelijk A/V sync bijstellen, gebaseerd op audio delay metingen.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Dynamisch het niveau van nabewerking veranderen, rekening houdend met de beschikbare CPU tijd. Het nummer dat je instelt zal het maximum niveau zijn dat gebruikt zal worden. Gewoonlijk kan je hier een groot nummer gebruiken.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tsjechisch</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Duits</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Engels</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Spaans</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Frans</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Hongaars</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiaans</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japans</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgisch</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Nederlands</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Pools</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Braziliaans Portugees</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russisch</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slowaak</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Oekraïens</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Vereenvoudigd Chinees</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Automatisch detecteren&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgaars</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Deze optie aanduiden kan flikkering verminderen, maar het kan mogelijk ook een foutieve weergave van de video veroorzaken.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turks</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Grieks</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Fins</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Zweeds</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Deze optie bepaalt de plaatsing van de ondertitels op het afspeelvenster. &lt;i&gt;100&lt;/i&gt; betekent onderaan en &lt;i&gt;0&lt;/i&gt; betekent bovenaan.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Hier kan je stijlen voor SSA/ASS ondertitels overschrijven met een zelfgekozen stijl. Het kan ook gebruikt worden om de rendering van srt en sub ondertitels bij te stellen via de SSA/ASS bibliotheek.&lt;br&gt;Voorbeeld: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Voorkeuren</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Toepassen</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Annuleren</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Algemeen</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Paden</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Zoeken...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Kiezen...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Map om schermafdrukken in op te slaan:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Uitvoer drivers</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Audio:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Gebruik software video equalizer</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Gebruik software volumeregeling</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Media instellingen</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Onthoud instellingen voor alle bestanden (audiospoor, ondertitels...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Positie niet onthouden (bestanden starten met afspelen vanaf het begin)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Start videobestanden in volledig scherm</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Ondertitels</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Lettertype</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Kies het lettertype dat gebruikt moet worden voor ondertitels (en OSD):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF lettertype:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Kies...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Systeemlettertype:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Automatisch schalen:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Geen automatisch schaling</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Evenredig met hoogte van film</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Evenredig met breedte van film</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Evenredig met diagonaal van film</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Schalen:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Automatisch laden</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Automatisch eerst beschikbare ondertitel kiezen</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Dezelfde naam als film</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Alle ondertitels die de filmnaam bevatten</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Alle ondertitels in map</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Automatisch ondertitels laden (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Standaard ondertitel encodering:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Gebruik SSA/ASS bibliotheek voor ondertitel rendering</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Tekstkleur:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Randkleur:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Ondertitels weergeven op schermafdrukken</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Uitgebreid</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opties:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Je kan ook extra video filters meegeven.
De video filters moeten van elkaar gescheiden worden door &quot;,&quot;. Gebruik geen spaties!
Voorbeeld: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Video filters:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>En tot slot audio filters. Dezelfde regel als voor video filters.
Voorbeeld: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Audio filters:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Prestaties</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioriteit:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>realtime</translation>
    </message>
    <message>
        <source>high</source>
        <translation>hoog</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>hoger dan normaal</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normaal</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>lager dan normaal</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>idle</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Een cache instellen kan prestaties verbeteren bij trage media</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Cache:</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Frame drops toestaan</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Harde frame drops toestaan (kan leiden tot beeldvervorming)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Synchronisatie</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Audio/video automatische synchronisatie</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Factor:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Automatische kwaliteit voor nabewerkingsfilter:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Level:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Laagste</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Hoogste</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Snelle audio spoor wisseling</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Snel zoeken naar hoofdstukken bij dvds</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(cache zal uitgeschakeld worden en er is geen garantie dat dit echt wel werkt)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Schermbeveiliging uitschakelen</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Monitor aspect:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Hoofdvenster afmetingen wijzigen:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nooit</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Wanneer nodig</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Alleen na het laden van een nieuw videobestand</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Enkele instantie</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Gebruik slechts één draaiende instantie van SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer zal naar deze poort luisteren om commando&apos;s te ontvangen van andere instanties:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(veranderingen in deze groep vereisen dat SMPlayer opnieuw wordt gestart)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Stijl:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Schijfstations</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>SMPlayer detecteert momenteel niet automatisch cdrom of dvd apparaten. Dus om cdrom&apos;s of dvd&apos;s af te kunnen spelen moet je eerst hier je cdrom en dvd schijfstations instellen (kan hetzelfde zijn).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>icoon</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Kies CD apparaat:</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Kies DVD apparaat:</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Recente bestanden</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Max. items</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Lijst leegmaken</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Standaardvolume:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Muis</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Knop functies:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Dubbelklikken</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Linkerklik</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Venstergrootte</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Wiel functie:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Media zoeken</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Volumeregeling</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Muis en toetsenbord</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Toetsenbord</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Deze optie is vooral bedoeld om het programma te debuggen.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Taal:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Icon set:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Voorkeur voor audio en ondertitels</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Ondertitels:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioriteit</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Kies het mplayer uitvoerbaar bestand:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Draai MPlayer in zijn eigen venster</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Extra opties voor MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Hier kan je extra opties meegeven aan MPlayer.
Schrijf ze gescheiden door spaties.
Voorbeeld: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Kies de prioriteit van het MPlayer proces.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>MPlayer uitvoer loggen</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>SMPlayer uitvoer loggen</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filter voor SMPlayer logbestanden:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Geen repaint uitvoeren op de achtergrond van het videovenster</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Hier kan je eender welke sneltoets instellen. Om een sneltoets aan te passen moet u op de desbetreffende cel dubbelklikken of typen terwijl de desbetreffende cel de focus heeft. Optioneel bestaat de mogelijkheid om uw sneltoetsen configuratie op te slaan zodat u het kan delen met andere mensen of zodat u het in een andere computer kan inladen.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Kies eerste ondertitel die beschikbaar is</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Plaatsing</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Standaard plaatsing van ondertitels op het scherm</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Kleursleutel:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Aanpassen...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Bovenaan</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Onderaan</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Stijlen:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">O&amp;ndertitels</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Audio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 seconde</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 seconden</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 minuten</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 minuten en %2 seconden</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 minuut</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 minuut en 1 seconde</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 minuut en %1 seconden</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 minuten en 1 seconde</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>ZoekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>icoon</translation>
    </message>
    <message>
        <source>label</source>
        <translation>label</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Equalizer</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Contrast</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Helderheid</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Tint</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Verzadiging</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Instellen als standaardwaarden</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Gebruik de huidige waarden als standaardwaarden voor nieuwe videobestanden.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Zet alle besturingselementen op nul.</translation>
    </message>
</context>
</TS>
