<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Front-end per mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>File da aprire</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Sviluppatore</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Versione: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Versione Qt: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Traduttori:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Tedesco</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovacco</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francese</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Cinese Semplificato</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Ungherese</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Giapponese</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Olandese</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraino</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portoghese Brasiliano</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Ceco</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo realizzato da %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Trova aggiornamenti su: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>Informazioni su SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 e %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polacco</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Compilato con supporto KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgaro</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Svedese</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbo</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Cinese Tradizionale</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Scorciatoia</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Salva</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Apri</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>File chiave</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Scegli il nome del file</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confermi sovrascrittura?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Il file  %1 esiste già.
Vuoi sovrascriverlo?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Scegli un file</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Non è stato possibile salvare il file</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Non è stato possibile caricare il file</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;File...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>C&amp;artella...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Lista di riproduzione...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD dal lettore</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD da una cartella...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Riproduci</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pausa</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Avanza per fotogramma</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>Ripeti</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>Velocità &amp;normale</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Dimezza velocità</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Raddoppia velocità</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Velocità &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Velocità &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Velocità</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Tutto schermo</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Modalità compatta</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizzatore</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Screenshot</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>Tieni s&amp;opra le altre</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocessing</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetect della fase</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Aggiungi r&amp;umore</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>&amp;Filtri</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Muto</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Ritardo -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>R&amp;itardo +</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtri</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Apri...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Ritardo &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Ritardo &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Su</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>G&amp;iù</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Lista di riproduzione</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>Mostra &amp;contatore fotogrammi</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>P&amp;referenze</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Vedi logs</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Informazioni &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>Informazioni su &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>A&amp;pri</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Riproduci</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>A&amp;udio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Sottotitoli</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>S&amp;foglia</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Opzioni</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Aiuto</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>File &amp;recenti</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>Pulisci</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>Grande&amp;zza</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Rapporto d&apos;aspetto</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlaccia</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>De&amp;noise</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>A&amp;utomatico</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;a 16:9</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Nessuno</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>&amp;Blend Lineare</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>Normale</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>Soft</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Traccia</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Canali</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Modo stereo</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>Pre&amp;definito</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>Canale &amp;Sinistro</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>Canale &amp;Destro</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Seleziona</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Titolo</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Capitolo</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Angolo</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Disabilitato</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Barra di ricerca</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Tempo</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Tempo + Tempo T&amp;otale</translation>
    </message>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - Log di mplayer</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - Log di smplayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;vuoto&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Liste di riproduzione</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Scegli un file</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Informazioni</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Le unità CDROM / DVD non sono ancora configurate.
Si aprirà ora il dialogo di configurazione, in modio che tu possa farlo.
</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Scegli una cartella</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Sottotitoli</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Informazioni Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>In riproduzione %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Riproduci / Pausa</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pausa / Per fotogramma</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Rimuovi</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Attenzione</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>La porta %1 è ià in uso da un&apos;altra applicazione.
Impossibile inizializzare il server.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>L&apos;opzione singola istanza è stata disabilitata.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Esci</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>C&amp;hiudi</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>&amp;Informazioni e proprietà</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Muovi a &amp;sinistra</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Muovi a &amp;destra</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Manda &amp;su</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Manda &amp;giù</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Pan &amp;&amp; scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>Linea &amp;precedente nei sottotitoli</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>Linea succ&amp;essiva nei sottotitoli</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Abbassa volume (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Alza volume (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Esci da tutto schermo</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Livello successivo</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Diminuisci contrasto</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Aumenta contrasto</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Diminuisci luminosità</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Aumenta luminosità</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Diminuisci tonalità</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Aumenta tonalità</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Diminuisci saturazione</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Diminuisci gamma</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Audio successivo</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Sottotitoli successivi</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Capitolo successivo</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Capitolo precedente</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Aumenta saturazione</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Aumenta gamma</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation>Grandezza doppia</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>Apri file &amp;esterno...</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normale)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (framerate doppio)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Prossimo</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>P&amp;recedente</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Normalizzazione volume</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer è ancora in esecuzione.</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>M&amp;ostra icona nella barra di sistema</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>Nascondi</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Ripristina</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>File &amp;recenti</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Esci</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Luminosità: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Contrasto: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Tonalità: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Saturazione: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Volume: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Benvenuto in  SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Sottotitoli</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Lista di riproduzione</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>Barra strumenti principale</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>Barra strumenti per le lingue</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>Barre strumenti</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Turco</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished">Russo</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation></translation>
    </message>
    <message>
        <source>icon</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Proprietà del file</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informazioni</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp; Seleziona il demuxer che sarà usato per questo file:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>Codec &amp;video</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Seleziona il codec video:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>Codec a&amp;udio</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Seleziona il codec audio:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>Opzioni &amp;Mplayer</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Opzioni</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Qui puoi passare filtri video addizionali.
Separali con &quot;,&quot;. Non usare spazi!
Esempio: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>Filtri v&amp;ideo</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Filtri video. Stesse regole dei filtri audio.
Esempio: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>&amp;Filtri audio</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>A&amp;pplica</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opzioni addizionali per MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Qui puoi passare opzioni extra a MPlayer.
Scrivile separate da spazi.
Esempio: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Percorso</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Grandezza</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Durata</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Artista</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autore</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Álbum</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Genere</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Traccia</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Commento</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Risoluzione</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Rapporto d&apos;aspetto</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Frame al secondo</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Codec Selezionato</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Flusso Audio Iniziale</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Frequenza campionamento</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Canali</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Flussi Audio</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>vuoto</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Sottotitoli</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation></translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation></translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Titolo flusso</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>URL flusso</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Scegli una cartella</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Puoi riprodurre un dvd direttamente dal disco. Seleziona semplicemente la cartella che contiene VIDEO_TS e AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Scegli una cartella...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Riproduci un DVD da una cartella</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Scegli il nome del file</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confermi sovrascrittura?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>il file esiste già.
Vuoi sovrascriverlo?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Errore durante il salvataggio del file</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Non é stato possibile salvare il log</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Finestra Log</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Copia negli appunti</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Durata</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Scegli un file</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Scegli il nome del file</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confermi sovrascrittura?</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Seleziona uno o più file da aprire</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Scegli una cartella</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Il file  %1 esiste già.
Vuoi sovrascriverlo?</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Modifica nome</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Inserisci il nome per questo file che sarà visualizzato nella lista di riproduzione:</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Riproduci</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Modifica</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Liste di riproduzione</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Apri</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Salva</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Prossimo</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>P&amp;recedente</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Manda &amp;su</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Manda &amp;giù</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Ripeti</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>Riproduzione &amp;Casuale</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Aggiungi il file &amp;corrente</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Aggiungi &amp;file(s)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Aggiungic&amp;artella</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>R&amp;imuovi selezionati</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Ri&amp;muovi tutti</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Lista di riproduzione</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Aggiungi...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Rimuovi...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Lista di riproduzione modificata</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Ci sono modifiche non salvate. Vuoi salvare la lista di riproduzione?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Sottotitoli</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Seleziona eseguibile mplayer</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Scegli un file TTF</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Seleziona una cartella</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Prestazioni</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzate</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Dispositivi</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Eseguibili</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Caratteri Truetype</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Salto breve</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Salto medio</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Salto lungo</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Salto rotellina mouse</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfaccia</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Mouse e tastiera</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Qui puoi specificare una cartella dove salvare gli screenshots. Se il campo é vuoto, la cattura degli screenshot sarà disabilitata.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Seleziona il driver di output video. Di norma, xv (linux) e directx (windows) danno prestazioni migliori.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Seleziona il driver di output audio.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Seleziona questa opzione se l&apos;equalizzatore video non é supportato dalla scheda grafica o dal driver video selezionato.&lt;br&gt;&lt;b&gt;Attenzione:&lt;/b&gt; questa opzione può essere incompatibile con alcuni driver video.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Seleziona questa opzione  per usare il mixer software, invece di quello della scheda audio.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Se selezioni questa opzione, smplayer riprodurrà tutti i file dall&apos;inizio.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Se selezioni questa opzione, tutti i video partiranno a tutto schermo.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Seleziona questa opzione per disabilitare lo screensaver.&lt;br&gt;Sarà poi ripristinato alla fine della riproduzione.&lt;br&gt;&lt;b&gt;Attenzione:&lt;/b&gt; Questa opzione funziona solo in X11 e Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Qui puoi specificare l&apos;eseguibile mplayer.&lt;br&gt;smplayer richiede almeno mplayer 1.0rc1 (svn raccomandato).&lt;br&gt;&lt;b&gt;Se questa opzione é errata, smplayer non riprodurrà nulla!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Se selezionata, smplayer salverà l&apos;output di mplayer (puoi visualizzarlo in &lt;b&gt;Opzioni-&gt;Vedi logs-&gt;mplayer&lt;/b&gt;). In caso di problemi, questo log può contenere informazioni importanti, si raccomanda quindi di tenere selezionata questa opzione.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Se questa opzione é selezionata, smplayer salverà i messaggi di debug (puoi visualizzarlo in &lt;b&gt;Opzioni-&gt;Vedi logs-&gt;smplayer&lt;/b&gt;). Queste informazioni possono essere utili per gli sviluppatori nel caso trovino un bug.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Questa opzione permette di filtrare i messaggi di log. Potete inserire qualsiasi espressione regolare. &lt;br&gt;Per esempio: &lt;i&gt;^Core::.*&lt;/i&gt; mostrerà solo le linee che iniziano con &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Attenzione:&lt;/b&gt; Questa opzione é solo per Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Predefinito</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Definisce la priorità per mplayer a seconda delle priorità predefinite disponibili in Windows. &lt;br&gt;&lt;b&gt;ATTENZIONE:&lt;/b&gt; Usare la priorità realtime può causare il blocco del sistema.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Normalmente smplayer ricorderà le opzioni per ogni file (traccia audio selezionata, volume, filtri...). Deseleziona l&apos;opzione se non ti piace questa caratteristica.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Qui puoi inserire la lingua preferita per i flussi audio. Quando viene trovato un media con flussi audio multipli, smplayer proverà a usare la lingua preferita.&lt;br&gt;Questo funzionerà solo con media che offrono informazioni sulla lingua dei flussi audio, come i DVD o i file mkv.&lt;br&gt; Questo campo accetta espressioni regolari. Ad esempio: lt;b&gt;es|esp|spa&lt;/b&gt; selezionerà la traccia audio che combacia con &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; o &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Qui puoi inserire la lingua preferita per i sottotitoli. Quando viene trovato un media con sottotitoli multipli, smplayer proverà a usare la lingua preferita.&lt;br&gt;Questo funzionerà solo con media che offrono informazioni sulla lingua dei sottotitoli, come i DVD o i file mkv.&lt;br&gt; Questo campo accetta espressioni regolari. Ad esempio: lt;b&gt;es|esp|spa&lt;/b&gt; selezionerà il sottotitolo che combacia con &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; o &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Questa opzione specifica quanta memoria (in kBytes) usare per il precaching di un  file o di un  URL. Molto utile con media lenti.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Salta alcuni frame per mantenere la sincronia Audio/Video su sistemi lenti.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Salto di frame molto intenso. Causa immagini distorte!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Aggiusta gradualmente la sincronia Audio/Video basandosi sulla misura del ritardo audio.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Cambia dinamicamente il livello di postprocessing a seconda del tempo di CPU disponibile. Il numero che specifichi sarà il massimo livello usato. Normalmente si possono usare numeri molto grandi.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Ceco</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Tedesco</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Inglese</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Spagnolo</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francese</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Ungherese</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Giapponese</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Olandese</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polacco</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portoghese Brasiliano</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovacco</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraino</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Cinese Semplificato</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Automatico&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgaro</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Selezionare questa opzione può ridurre lo sfarfallio, ma può anche produrre una errata riproduzione video.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Greco</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Finlandese</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Svedese</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Questa opzione specifica la posizione dei sottotitoli nella finestra. &lt;i&gt;100&lt;/i&gt; significa in basso, mentre  &lt;i&gt;0&lt;/i&gt; significa in alto.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Qui puoi sovrascrivere lo stile per i sottotitoli SSA/ASS. Può anche essere usato per personalizzare la visualizzazione dei sottotitoli srt e sub da parte della libreria SSA/ASS.&lt;br&gt;Esempio: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbo</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Cinese Tradizionale</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Qui puoi sovrascrivere lo stile per i sottotitoli SSA/ASS. Puoi anche usare queste opzioni per personalizzare ii rendering dei sottotitoli srt e sub.&lt;br&gt;Esempio: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Tastiera e mouse</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Preferenze</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Generale</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Percorsi</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Seleziona...</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Cerca...</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Audio:</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Sottotitoli</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Carattere</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Seleziona il tipo di carattere che si userà per i sottotitoli (e OSD):</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Scegli...</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Grandezza</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Scala automatica:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Nessuna scala automatica</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proporzionale all&apos;altezza del video</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proporzionale alla larghezza del video</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proporzionale alla diagonale del video</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Scala:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Apertura automatica</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Apri automaticamente i file dei sottotitoli (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Stesso nome del video</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Tutti quelli che contengono il nome del video</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Tutti i sottotitoli della cartella</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Seleziona automaticamente il primo sottotitolo disponibile</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Usare la libreria SSA/ASS per visualizzare i sottotitoli</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opzioni:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Filtri video:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Filtri audio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>A&amp;pplica</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>Font TTF: </translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Font di sistema:</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Disabilita salvaschermo</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Quando è necessario</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Solo dopo aver aperto in nuovo video</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Cache:</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>cartella degli screenshots:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Usa equalizzatore video software</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Usa controllo del volume software</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Metodo di scalatura della finestra principale:</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Colore del testo:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Colore del bordo:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Avanzate</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Prestazioni</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorità:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>tempo reale</translation>
    </message>
    <message>
        <source>high</source>
        <translation>alta</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>sopra al normale</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normale</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>sotto al normale</translation>
    </message>
    <message>
        <source>idle</source>
        <translation></translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Permetti scarto fotogrammi</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Permetti alto scarto fotogrammi (può corrompere l&apos;immagine)</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Seleziona il dispositivo DVD:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Seleziona il dispositivo CD:</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Opzioni per il video</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Ricorda le opzioni per tutti i file (traccia audio, sottotitoli...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Non ricordare la posizione temporale (la riproduzione riparte dell&apos;inizio)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Stile:</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Proporzioni monitor:</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Riproduci video a tutto schermo</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Unità disco</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Qualità automatica per il filtro di postprocessing:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Livello:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Il più basso</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Il più alto</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Drivers di uscita</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Sincronia</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Fattore:</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Sincronia automatica di audio e video</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Codifica dei sottotitoli:</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(si disabiliterà la cache e non é garantito il funzionamento)</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Selezione rapida dei capitoli nei DVD</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Usare una cache può migliorare il rendimento nei media lenti</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Cambio rapido della traccia audio</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Includi sottotitoli negli screenshot</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Singola istanza</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Usa una sola istanza di SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer ascolterà su questa porta per ricevere comandi da altre istanze:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(i cambi in questo gruppo richiedono il riavvio di SMPlayer)</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Puoi anche passare dei filtri video addizionali.
Separali con &quot;,&quot;. Non usare spazi!
Esempio: resize=512:384,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>E finalmente i filtri audio. Stessa regola dei filtri video.
Esempio: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Attualmente SMPlayer non trova automaticamente i dispositivi CDROM e DVD. Devi quindi selezionare qui i tuoi dispositivi (possono essere lo stesso).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation></translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>File recenti</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Max. numero di elementi</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Pulisci lista</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Ricerca</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Volume predefinito:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Mouse</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Funzione bottoni:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Doppio click:</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Click sinistro:</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Grandezza finestra:</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfaccia</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Funzione rotellina:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Ricerca nel file</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Controllo volume</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Mouse e tastiera</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Tastiera</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Questa opzione é pensata principalmente per scopi di debug.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Lingua:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Set icone:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Audio e sottotitoli preferiti</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Sottotitoli:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorità</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Seleziona l&apos;eseguibile mplayer</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Esegui mplayer nella sua finestra</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opzioni addizionali per MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Qui puoi passare opzioni addizionali a MPlayer.
Scrivile separate da spazi.
Esempio: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Seleziona la priorità del processo MPlayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Salva l&apos;output di MPlayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Salva l&apos;output di SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filtro per i log  di SMPlayer:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Non ridisegnare lo sfondo della finestra video</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Qui puoi cambiare le scorciatoie da tastiera. Per farlo, fai doppio click o scrivi nella cella corrispondente. Opzionalmente, puoi salvare la lista per condividerla con altre persone o utilizzarla su un altro computer.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Seleziona i primi sottotitoli disponibili</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posizione</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Posizione predefinita dei sottotitoli</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Colorkey:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Cambia...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Alto</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Basso</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Stili: </translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Usa cache</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Grandezza:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS passthrough S/PDIF</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Fine del file:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>Nessun video:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Sottotitoli</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>Usa l&apos;opzione -subfont (richiesta da recenti versioni di MPlayer)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>Libreria SSA/&amp;ASS</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>La nuova libreria SSA/ASS fornisce graziosi sottotitoli per file esterni SSA/ASS e tracce Matroska, ma può essere usata per visualizzare sottotitoli in altri formati, ad esempio SUB e SRT.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Qui si possono sovrascrivere gli stili per i sottotitoli SSA/ASS. Può anche essere usata per controllare il rendering dei sottotitoli SRT e SUB da parte della libreria SSA/ASS. Esempio: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>&amp;Avanzate</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>&amp;Logs</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>Lingua &amp;Mplayer</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>SMPlayer ha bisogno di leggere l&apos;output di MPlayer e talvolta fa affidamento sulla lingua inglese.Se state usando  MPlayer tradotto i un&apos;altra lingua, allora dovrete cambiare il testo cercato da SMplayer. (Tecnicamente, bisogna inserire una espressione regolare)&lt;br&gt;&lt;br&gt;
La lista può fornire delle espressioni reolari già fatte per alcuni linguaggi.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Tastiera</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Mouse</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation>Zoom video</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation>Massima amplificazione:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation>Normalizzazione volume</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished">Qui si possono sovrascrivere gli stili per i sottotitoli SSA/ASS. Può anche essere usata per controllare il rendering dei sottotitoli SRT e SUB da parte della libreria SSA/ASS. Esempio: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt; {2 or 4?}</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 secondo</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 secondi</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 minuti</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 minuti e %2 secondi</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 minuto e 1 secondo</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 minuto e %1 secondi</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 minuti e 1 secondo</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation></translation>
    </message>
    <message>
        <source>icon</source>
        <translation></translation>
    </message>
    <message>
        <source>label</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Contrast</source>
        <translation>Contrasto</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Luminosità</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Tonalità</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Saturazione</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>Equalizer</source>
        <translation>Equalizzatore</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>Salva come valori predefiniti</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Usa i valori correnti come valori predefiniti per i nuovi video.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Metti a zero tutti i controlli</translation>
    </message>
</context>
</TS>
