<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Developer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Version: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Version de Qt: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Traducteurs:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Allemand</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovène</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italien</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Français</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chinois-simplifié</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russe</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Hongrois</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonais</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Hollandais</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainien</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugais brésilien</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Géorgien</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tchèque</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo designé par %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Mises à jour: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>A propos de SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="unfinished">Polonais</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Turc</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nom</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished">&amp;Enregistrer</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation type="unfinished">&amp;Charger</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation type="unfinished">Choisir un nom de fichier</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished">Le fichier %1 existe déjà.
Voulez vous l&apos;écraser?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished">Choisir un fichier</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Fichier...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>Doss&amp;ier...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Liste de lecture...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD à partir d&apos;un lecteur</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD depuis le dossier...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Lecture</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pause</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Image par image</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Répéter</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Vitesse normale</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Réduire la vitesse</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Doubler la vitesse</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Vitesse &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Vitesse &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Vitesse</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Plein écran</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Mode compact</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Egaliseur</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Capture écran</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>Res&amp;ter au premier plan</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocessing</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodétection de la phase</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Ajout de &amp;bruit</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>&amp;Filtres</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Muet</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Délai -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>D&amp;élai +</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastéréo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtres</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Charger...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Délai &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Délai &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Haut</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;Bas</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Liste de lecture</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Voir compteur d&apos;images</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>P&amp;références</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Voir logs</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>A propos de &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>A propos de &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Ouvrir</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Lire</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Vidéo</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Sous-titres</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Naviguer</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>Op&amp;tions</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>A&amp;ide</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Fichier récents</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Effacer</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>T&amp;aille</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Aspect ratio</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Désentrelacement</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>Débr&amp;uiter</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Autodétection</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;à 16:9</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>Aucu&amp;n</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormal</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Léger</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Piste</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Canaux</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Mode stéréo</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;Défaut</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Stéréo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Canal gauche</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>Canal &amp;droit</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Sélectionner</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Titre</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Chapitre</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Angle</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Désactivé</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Barre de navigation</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Temps</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Temps + Te&amp;mps total</translation>
    </message>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer log</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer log</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;vide&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vidéo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Listes de lecture</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tous les fichiers</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Choisir un fichier</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Information</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Les lecteurs CD/DVD ne sont pas encore configurés.
La boîte de dialogue de configuration va s&apos;afficher pour que vous le fassiez maintenant.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Choisir un dossier</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Sous-titres</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>A propos de Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Lecture de %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Lecture / Pause</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pause / Saut d&apos;images</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>Déchar&amp;ger</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">&amp;Reset</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation type="unfinished">&amp;Monter</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation type="unfinished">&amp;Descendre</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;Suivant</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">&amp;Précédent</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation type="unfinished">&amp;Fichier récents</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Luminosité: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Contraste: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Ton: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Saturation: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Volume: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Bienvenue dans SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Sous-titres</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Liste de lecture</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>Barre d&apos;outils pri&amp;ncipale</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>Barre de &amp;langues</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Barre d&apos;outils</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Langues de l&apos;Europe de l&apos;ouest</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Langues de l&apos;Europe de l&apos;ouest avec Euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Langues de l&apos;Europe centrale/slave</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Malte, Turc</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Balte ancien</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cyrillic</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabe</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Grec moderne</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turc</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Balte</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Celte</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Caractères hébreux</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russe</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrainien, Biélorusse</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Chinois simplifié</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Chinois traditionel</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japonais</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Koréen</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thailandais</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Cyrillic Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Langues de l&apos;Europe centrale/slave</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation></translation>
    </message>
    <message>
        <source>icon</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation type="unfinished">&amp;Démultiplexeur</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation type="unfinished">&amp;Sélectionnez le démultiplexeur qui sera utilisé pour ce fichier:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation type="unfinished">Codec &amp;vidéo</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation type="unfinished">&amp;Sélectionnez le codec vidéo:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation type="unfinished">Codec a&amp;udio</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation type="unfinished">&amp;Sélectionnez le codec audio:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation type="unfinished">Options &amp;Mplayer</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation type="unfinished">&amp;Options:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="unfinished">Vous pouvez aussi passer des filtres vidéo supplémentaires.
Séparez les par &quot;,&quot;. N&apos;utilisez pas d&apos;espace!
Exemple: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation type="unfinished">Filtres V&amp;idéo:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="unfinished">Pour les filtres audios, même régle que pour les filtres vidéo.
Exemple: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation type="unfinished">&amp;Filtres audio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished">&amp;Appliquer</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Annuler</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation type="unfinished">Général</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished">Chemin</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Taille</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation type="unfinished">%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished">URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished">Durée</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nom</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation type="unfinished">Artiste</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished">Auteur</translation>
    </message>
    <message>
        <source>Album</source>
        <translation type="unfinished">Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation type="unfinished">Genre</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Date</translation>
    </message>
    <message>
        <source>Track</source>
        <translation type="unfinished">Piste</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation type="unfinished">Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">Commentaire</translation>
    </message>
    <message>
        <source>Software</source>
        <translation type="unfinished">Logiciel</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation type="unfinished">Informations sur le fichier</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Vidéo</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="unfinished">Résolution</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation type="unfinished">Aspect ratio</translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished">Format</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation type="unfinished">Débit</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation type="unfinished">%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation type="unfinished">Images par seconde</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation type="unfinished">Codec sélectionné</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation type="unfinished">Flux audio initial</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished">Taux</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation type="unfinished">%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation type="unfinished">Canaux</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation type="unfinished">Flux audio</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Langue</translation>
    </message>
    <message>
        <source>empty</source>
        <translation type="unfinished">vide</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="unfinished">Sous-titres</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation type="unfinished">#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Choisissez un dossier</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Vous pouvez lire un DVD depuis le disque dur. Selectionnez le dossier contenant VIDEO_TS et AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Choisissez un dossier...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Annuler</translation>
    </message>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Lire un DVD depuis un dossier</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Choisissez un nom de fichier pour sauver</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirmer écrasement?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Le fichier existe déjà.
Voulez vous le remplacer?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Erreur lors de la sauvegarde</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Le fichier de log n&apos;a pas pu être sauvegardé</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Log Window</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Sauver</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Copier dans le presse papier</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fermer</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Fermer</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Choisir un fichier</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Choisir un nom de fichier</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirmer remplacement?</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Selectionner un ou plusieurs fichiers à ouvrir</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Selectionner un dossier</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Le fichier %1 existe déjà.
Voulez vous l&apos;écraser?</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Editer le nom</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Taper le nom qui sera affiché dans la playlist pour ce fichier:</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Lire</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editer</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Listes de lecture</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tous les fichiers</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Charger</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Enregistrer</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Suivant</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Précédent</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>&amp;Monter</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>&amp;Descendre</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Répéter</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Aléatoire</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Ajouter le fichier &amp;courant</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Ajout de &amp;fichier(s)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Ajout d&apos;un &amp;dossier</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Effacer la &amp;sélection</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>&amp;Tout supprimer</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Liste de lecture</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Ajouter...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Supprimer...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Général</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Sous-titres</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Séléctionnez l&apos;éxécutable Mplayer</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Choisir un fichier ttf</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Choisir un dossier</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Performance</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avancé</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Lecteurs</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Exécutables</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tous les fichiers</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Polices truetype</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Saut court</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Saut moyen</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Saut long</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Saut sur molette</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Souris et clavier</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Ici vous pouvez choisir le dossier ou seront stockées les captures d&apos;écran. Si ce champs est vide, la fonction de capture sera désactivée.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Sélectionnez le driver de sortie vidéo. Généralement, xv (Linux) et directx (Windows) donnent les meilleures performances.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Sélectionnez le driver de sortie audio.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Vous pouvez sélectionner cette option si l&apos;égaliseur n&apos;est pas supporté par votre carte graphique ou le driver de sortie vidéo sélectionné.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; cette option peut être incompatible avec certains drivers de sortie vidéo.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Sélectionnez cette option pour utiliser le mixeur logiciel au lieu du mixeur matériel.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Si vous sélectionnez cette option, smplayer lira tous les fichiers à partir du début.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Si cette option est sélectionnée, toutes les vidéos seront lancées en plein écran.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Sélectionnez cette option pour désactiver l&apos;économiseur d&apos;écran pendant la lecture.&lt;br&gt;L&apos;économiseur d&apos;écran sera réactivé à la fin de la lecture.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; cette option fonctionne seulement sous X11 et Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Ici vous devez spécifier l&apos;éxécutable pour mplayer.&lt;br&gt;smplayer nécessite au moins mplayer 1.0rc1 (svn recommandé).&lt;br&gt;&lt;b&gt;Si ce réglage n&apos;est pas bon, smplayer ne pourra rien jouer!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Si cette options est sélectionnée, smplayer stockera le log de mplayer (pour voir: &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). En cas de problème ce log peut contenir des informations importantes; il est donc recommandé de laissé cette option sélectionnée.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Si cette option est activée, smplayer stockera le log de mplayer (pour voir: &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). Ces informations peuvent être utiles pour les développeurs en cas de bug.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Cette option permet de filtrer les messages qui seront stockées dans le log. Ici vous pouvez écrire n&apos;importe quelle expression régulière.&lt;br&gt;Par exemple: &lt;i&gt;^Core::.*&lt;/i&gt; affichera seulement les lignes qui commencent par &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; Cette option est seulement pour Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Défaut</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Définir la priorité du processus pour mplayer.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; &quot;Temps réel&quot; peut conduire à un blocage du système.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Normalement, smplayer se rappellera des configurations pour chaque fichier (piste audio, volume, filtres...). Désactivez cette option si ça ne vous plait pas.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Ici vous pouvez choisir votre langue audio préférée. Quand un média avec plusieurs pistes audio est trouvé, smplayer essaye d&apos;utiliser votre préférée.&lt;br&gt;Ceci ne fonctionne que lorsque la langue est renseignée dans les flux audio, comme dans un DVD ou un mkv.&lt;br&gt;Ce champs accepte les expression régulières. Exemple: &lt;b&gt;es|esp|spa&lt;/b&gt; choisira la piste audio &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Ici vous pouvez choisir votre langue de sous-titres préférée. Quand un média avec plusieurs sous-titres est trouvé, smplayer essaye d&apos;utiliser votre préféré.&lt;br&gt;Ceci ne fonctionne que lorsque la langue est renseignée dans les sous-titres, comme dans un DVD ou un mkv.&lt;br&gt;Ce champs accepte les expression régulières. Exemple: &lt;b&gt;es|esp|spa&lt;/b&gt; choisira les sous-titres &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Cette option indique combien de mémoire (en KO) est utilisée pour le préchargement d&apos;un fichier ou d&apos;une URL. Particulièrement utile pour les médias lents.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Sauter des images pour conserver la synchronisation Audio/Vidéo sur les systèmes lents.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Saut d&apos;images intense (destructif). Induit des distorsions d&apos;images!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Ajustement graduel de la synchronisation A/V basé sur les mesures de délai audio.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Changer dynamiquement le niveau de postprocessing selon la charge CPU disponible. Le nombre spécifié sera le niveau maximum. Généralement, vous pouvez choisir de grands nombres.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tchèque</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Allemand</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Anglais</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Espagnol</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Français</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Hongrois</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italien</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonais</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Géorgien</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Hollandais</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polonais</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugais brésilien</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russe</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovène</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainien</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chinois-simplifié</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Autodétection&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Turc</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Préférences</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Général</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Chemins</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Sélectionner...</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Rechercher...</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Vidéo:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Audio:</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Sous-titres</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Police</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Sélectionner la police des sous-titres (et OSD):</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Choisir...</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Taille</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Echelle automatique:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Pas d&apos;échelle automatique</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proportionnel à la hauteur du film</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proportionnel à la largeur du film</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proportionnel à la diagonale du film</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Echelle:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Chargement automatique</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Chargement auto des sous-titres (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Même nom que la vidéo</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Tous les sous-titres contenant le nom de la vidéo</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Tous les sous-titres du dossier</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Sélectionner automatiquement les premier sous-titres disponibles</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Utiliser SSA/AAS pour le rendu</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Options:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Filtres vidéo:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Filtres audio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Appliquer</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Annuler</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>Police ttf: </translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Police du système:</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Désactiver l&apos;écran de veille</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Jamais</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Quand nécessaire</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Seulement après le chargement d&apos;une nouvelle vidéo</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Cache:</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Dossier pour stocker les captures d&apos;écran:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Utiliser l&apos;égaliseur vidéo logiciel</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Utiliser le control de volume logiciel</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Méthode de redimensionnement de la fenêtre principale:</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Couleur du texte:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Couleur de bordure:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Avancé</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Performance</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorité:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>Temps réel</translation>
    </message>
    <message>
        <source>high</source>
        <translation>Haut</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>Au dessus de la normale</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>Au dessous de la normale</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>Idle</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Activer le saut d&apos;images</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Autoriser le saut d&apos;images plus fort (peut conduire à des distorsions)</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Sélectionnez le lecteur DVD:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Sélectionnez le lecteur CD:</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Configurations du média</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Se rappeler des configurations pour chaque fichier (piste audio, sous-titres...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Ne pas se rappeler la position dans le fichier (lecture à partir du début)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Style:</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Aspect du moniteur:</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Lancer les vidéos en plein écran</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Lecteurs</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Auto-régulation du postprocessing:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Niveau:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Minimum</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Maximum</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Drivers de sortie</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Synchronisation</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Facteur:</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Synchronisation auto audio/video</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Encodage par défaut des sous-titres:</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(le cache va être désactivé et ce n&apos;est pas garantit que ça fonctionne)</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Sauts de chapitres rapides dans les DVD</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Régler le cache peut améliorer les performances sur les médias lents</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Changement rapide de pistes audio</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Inclure les sous-titres sur les captures d&apos;écran</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Instance unique</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Utiliser une seule instance de SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer écoutera ce port pour recevoir les commandes des autres instances:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(les changements dans ce groupe demandent un redémarrage de SMPlayer)</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Vous pouvez aussi passer des filtres vidéo supplémentaires.
Séparez les par &quot;,&quot;. N&apos;utilisez pas d&apos;espace!
Exemple: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Pour les filtres audios, même régle que pour les filtres vidéo.
Exemple: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Actuellement SMPlayer ne détecte pas automatiquement les lecteurs CD ou DVD. Vous devez donc indiquer ici vos lecteurs.</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>icon</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Fichiers récents</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Max. items</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Effacer la liste</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Navigation</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Volume par défaut:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Souris</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Fontions des boutons:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Double clic</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Clic gauche</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Taille de la fenêtre</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Fonction de la molette:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Navigation dans le média</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Contrôle du volume</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Souris et clavier</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Clavier</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Cette option est principalement utile pour le débuggage.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Langue:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Thème d&apos;icones:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Audio et sous-titres préférés</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Sous-titres:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorité</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">&amp;Sous-titres</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Vidéo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Audio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>icon</translation>
    </message>
    <message>
        <source>label</source>
        <translation>label</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Contrast</source>
        <translation>Contraste</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Luminosité</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Ton</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Saturation</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>Equalizer</source>
        <translation>Egaliseur</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>Choi&amp;sir en tant que valeur par défaut</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Utiliser les valeurs actuelles comme valeurs par défaut pour les nouvelles vidéos.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Mettre tous les contrôles à zéro.</translation>
    </message>
</context>
</TS>
