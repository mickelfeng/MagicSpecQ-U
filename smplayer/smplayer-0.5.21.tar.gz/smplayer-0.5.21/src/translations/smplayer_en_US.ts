<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Developer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Key files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Genre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drives</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>realtime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>high</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>idle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drives</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Double click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Window size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
