<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Interface gráfica para o mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Arquivo para abrir</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Desenvolvedor</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Versão: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Versão Qt: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Este programa é software livre, você pode redistribui-lo e/ou modificá-lo de acordo com os termos da Licença Pública Geral GNU que é publicado pela Free Software Foundation; seja na versão 2 dessa licença, ou (a sua escolha) em qualquer versão posterior.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Tradutores:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Alemão</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Eslovênio</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francês</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chinês Simplificado</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Hungaro</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonês</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandês</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraniano</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Português (Brasil)</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tcheco</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logotipo criado por %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Verificar atualizações em: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>Sobre o SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 e %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polonês</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Compilado com suporte ao KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgaro</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Sérvio</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chinês Tradicional</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romeno</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Português do Brasil</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Português de Portugal</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Atalho</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Gravar</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Arquivos chaves</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Escolhar um nome de arquivo</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirma a sobregravação?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>O arquivo %1 já existe.
Você quer sobregravá-lo?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Escolhar um arquivo</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>O arquivo não pode ser salvo</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>O arquivo não pode ser carregado</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer log</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - SMPlayer log</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Reproduzir</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Vídeo</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>Áu&amp;dio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Legendas</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Navegar</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Opções</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Arquivo...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>D&amp;iretório...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>Lista de &amp;reprodução...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD do drive</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD de um diretório...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Limpar</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Arquivos recentes</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Reproduzir</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Parar</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>Avanço de &amp;quadro</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Velocidade Normal</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Metade da velocidade</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>Velocidade &amp;Dupla</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Velocidade &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Velocidade &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>Vel&amp;ocidade</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Repetir</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Tela cheia</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Modo compacto</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Tamanho</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Autodetectar</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;para 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Relação de tamanho</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Nenhum</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Desentrelaçar</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocessing</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetectar fase</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Adicionar r&amp;uido</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>F&amp;iltros</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizador</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Screenshot</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>Man&amp;ter no topo</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Trilha</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastéreo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtros</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;Padrão</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>E&amp;stéreo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Canais</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>Canal &amp;Esquerdo</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>Canal &amp;Direito</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Modo estéreo</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Silêncio</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Atraso -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>A&amp;traso +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Selecionar</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Carregar...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Atraso &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Atraso &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Acima</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>A&amp;baixo</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Título</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Capítulo</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>Â&amp;ngulo</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Lista de reprodução</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Mostrar contador de quadros</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Desativado</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Barra de procura</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Tempo</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Tempo + T&amp;empo Total</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Ver logs</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>P&amp;referências</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Sobre o &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>Sobre o &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;vazio&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Lista de reprodução</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Todos os arquivos</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Escolha um arquivo</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Informações</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Os drives de CDRom / DVD não estão configurados ainda.
O diálogo de configuração será aberto agora, e você poderá faze-lo.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Escolha um diretório</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Legendas</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Sobre Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Reproduzindo %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>De&amp;noise</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormal</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Suave</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Reproduzir / Pausar</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pausar / Pulo de quadro</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Descarregar</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Advertência</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Porta %1 já está em uso por outra aplicação.
Não posso inicializar o servidor.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Servidor na porta %1 não responde.
A opção de instância simples foi desabilitada.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>F&amp;echar</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Ver &amp;informações e propriedades...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Resetar</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Mover &amp;esquerda</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Mover &amp;direita</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Mover para ci&amp;ma</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Mover para &amp;baixo</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Pan &amp;&amp; scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>Linha &amp;prévia nas legendas</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>&amp;Próxima linha nas legendas</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Reduzir volume (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Aumentar volume (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Sair de tela cheia</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Próximo nível</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Reduzir contraste</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Aumentar contraste</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Reduzir brilho</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Aumentar brilho</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Reduzir matiz</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Aumentar matiz</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Reduzir Saturação</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Reduzir gamma</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Próximo áudio</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Proxima legenda</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Próximo capítulo</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Capítulo prévio</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Aumentar saturação</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Aumentar gamma</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation>Alternar tamanho duplo</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>&amp;Carregar arquivo externo...</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (dupla velocidade)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Próximo</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>Pré&amp;vio</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Normalização do volume</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation>CD de áu&amp;dio</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer continua sendo executado aqui</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>&amp;Mostrar icone ao painel do sistema</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Esconder</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Restaurar</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Arquivo recente</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Sair</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Brilho: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Contraste: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Matiz: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Saturação: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Volume: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Bemvindo ao SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Legenda</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Lista de Reprodução</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>Barra de Ferramentas &amp;Principal</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>Barra de Ferramentas de &amp;Linguagem </translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp; Barras de Ferramentas</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Línguas do Oeste Europeu</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Línguas do Oeste Europeu com Euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Línguas Centro-Européias e Eslavas</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galício, Maltês, Turco</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Antigo Charset Báltico</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cirílico</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Árabe</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Grego Moderno</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Báltico</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Celta</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Charsets Hebreus</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ucraniano, Bielorusso</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Charset Chinês Simplificado</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Charset Chinês Tradicional</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Charset Japonês</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Charset Coreano</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Charset Tailandês</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Windows Cirílico</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Windows Europa Central e Eslavo</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqSlider</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>Icone</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - propriedades do arquivo</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informação</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Selecione o demuxer que será usado para este arquivo:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Resetar</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;Video codec</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Selecionar o codec de vídeo:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>Codec de Á&amp;udio</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Selecione o codec de áudio:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>Opções do &amp;MPlayer</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Opções:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Você pode também passar filtros adicionais de video.
Separe-os com &quot;,&quot;. Não use espaços!
Exemplo: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>Filtro&amp;s de Vídeo:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>E finalmente filtros de áudio. As mesmas regras dos filtros de video.
Exemplo: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>&amp;Filtros de áudio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Aplicar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opções adicionais do MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Aqui você pode passar opções extras para o MPlayer.
Escreva-as separadas por espaços.
Exemplo: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Duração</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Artista</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Álbum</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Gênero</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Trilha</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Informações do clip</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Relação de tamanho</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Taxa de bits</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Quadros por segundo</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Codec selecionado</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Fluxo de vídeo inicial</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Taxa</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Canais</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Faixas de áudio</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Língua</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>vazio</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Legendas</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Título da faixa</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>URL da faixa</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Escolha um diretório</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Reproduzir um DVD a partir de um diretório</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Você pode reproduzir um DVD de seu HD. Apenas selecione o diretório que contém as pastas VIDEO_TS e AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Escolhar um diretório...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Escolha com que nome o arquivo será gravado</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirma a sobregravação?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Este arquivo já existe.
Você quer sobregravá-lo?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Erro ao gravar o arquivo</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>O arquivo de log não pode ser gravado</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Janela de Log</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Gravar</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Copiar para a área de transferência</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Duração</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Reproduzir</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Lista de reprodução</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Escolhar um arquivo</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Escolhar um nome de arquivo</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirma a sobregravação?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Este arquivo já existe.
Você quer sobregravá-lo?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Todos os arquivos</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Selecione um ou mais arquivos para abrir</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Escolhar um diretório</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Editar o nome</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Digite o nome que será usado na lista de reprodução para este arquivo:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Carregar</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Gravar</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Próximo</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>Pré&amp;vios</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Mover &amp;acima</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Mover a&amp;baixo</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Repetir</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Aleatório</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Adicionar arquivo &amp;atual</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Adicionar a&amp;rquivo(s)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Adicionar &amp;diretório</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Remover &amp;selecionado</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Remover &amp;tudos</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Lista de Reprodução</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Adicionar...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Remover...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Lista de reprodução modificada</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Existe modificações não salvas, você gostaria de gravar a lista de reprodução?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Drives</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Performance</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Legendas</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Executáveis</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Todos os arquivos</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Selecione o executável do mplayer</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Selecione um diretório</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Fontes TrueType</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Escolha um arquivo ttf</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Avanço curto</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Avanço médio</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Avanço longo</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Avançar com a rodinha do mouse</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Mouse e teclado</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Aqui você pode especificar uma pasta onde os screenshots feitos pelo smplayer serão guardados. Se este campo estiver vazio a função de screenshot será desativada.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Selecione um driver de saída de vídeo. Geralmente xv (linux) e directx (windows) geram um melhor desempenho.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Selecione um driver de saída de áudio.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Você pode escolher esse opção a equalização de vídeo não é suportada por sua placa de vídeo ou pelo driver de saída de vídeo selecionado. &lt;br&gt;&lt;b&gt;Observação:&lt;/b&gt; esta opção pode ser incompatível com alguns drivers de saída de vídeo.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Escolha essa opção para usar um mixer por software, ao invés de usar o mixer da placa de som.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Se você escolher essa opção, o SMPlayer irá reproduzir todos os arquivos desde o ínicio.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Se esta opção for escolhida, todos os vídeos serão reproduzidos no modo de tela cheia.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Escolha essa opção para desativar o sala telas enquanto reproduzindo. &lt;br&gt;O salva telas será ativado novamente ao final da reprodução.&lt;br&gt;&lt;b&gt;Observação:&lt;/b&gt; Esta opção funciona apenas com o X11 e Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Aqui você deve especificar o executável do mplayer que o SMPlayer usará. &lt;br&gt;SMPlayer necessita pelo menos do mplayer 1.0rc1 (recomendado do svn)&lt;br&gt;&lt;b&gt;Se esta escolha estiver errada, o SMPlayer não poderá reproduzir nada!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Se escolher essa opção, o SMPlayer irá salvar o log do mplayer (você pode vê-lo em &lt;b&gt;Opções -&gt; Ver logs -&gt; mplayer&lt;/b&gt;). Em caso de problemas o log contém importantes informações, portanto é recomendável escolher essa opção.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Se está opção for escolhida, SMPlayer irá salvar as mensagens de debuggin da saída do SMPlayer (você pode ver esse log em &lt;b&gt;Opções -&gt; Ver logs -&gt; SMPlayer&lt;/b&gt;). Esta informação pode ser muito útil para os desenvolvedores no caso de você encontrar um bug.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Esta opção permite filtrar mensagens do SMPlayer que será salva no log. Aqui você pode escrever qualquer expressão regular. &lt;br&gt;Por exemplo: &lt;i&gt;^Core::.*&lt;/i&gt; ira mostrar apenas linhas começando com &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Observação:&lt;/b&gt; Esta opção é apenas para Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Definir a prioridade do processo do mplayer de acordo com as prioridades definidas pelo Windows.&lt;br&gt;&lt;b&gt;AVISO:&lt;/b&gt; Usar prioridade tempo real pode causar o travamento do sistema.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Geralmente o SMPlayer irá lembrar dos ajustes de cada um dos arquivos que você reproduziu (trilha de áudio selecionada, volume, filtros,...). Não selecione essa opção caso você não gosta dessa função.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Aqui você pode digitar a sua linguagem preferida para faixas de áudio. Quando uma mídia com várias faixas de áudio for detectada, o smplayer tentará usar sua linguagem preferida &lt;br&gt; Isso apenas funciona com mídia que oferece informações sobre a linguagem da faixa de áudio, como DVD ou arquivos mkv. &lt;br&gt; Este arquivo aceita expressões regulares. Exemplo: &lt;b&gt; ptbr|pt|es&lt;/b&gt; vai selecionar faixas de áudio que combinem com &lt;i&gt;ptbr&lt;/i&gt; &lt;i&gt;pt&lt;/i&gt; ou &lt;i&gt;es&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Aqui você pode digitar a sua linguagem preferida para as legendas. Quando uma mídia com várias legendas for detectada, o smplayer tentará usar sua linguagem preferida &lt;br&gt; Isso apenas funciona com mídia que oferece informações sobre legendas, como DVD ou arquivos mkv. &lt;br&gt; Este arquivo aceita expressões regulares. Exemplo: &lt;b&gt; ptbr|pt|es&lt;/b&gt; vai selecionar legendas que combinem com &lt;i&gt;ptbr&lt;/i&gt; &lt;i&gt;pt&lt;/i&gt; ou &lt;i&gt;es&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Esta opção especifica quanto de memória (em kBytes) será usada para o pré-cache de um arquivo ou URL. Especialmente útil em mídias lentas.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Descartar a exibição de alguns quadros para manter a sincronia A/V em sistemas lentos.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Descarte de quadros mais intenso (quebra decodificação). Pode gerar distorção da imagem!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Gradualmente ajusta o sincronismo A/V baseado na medida de atraso de áudios.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Muda dinamicamente o nivel de pós-processamento dependendo da disponibilidade de tempo na CPU. O número que você especificar será o máximo nível usado. Geralmente você pode usar números grandes.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tcheco</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Alemão</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Inglês</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Espanhol</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francês</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Hungaro</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonês</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandês</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polonês</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Português do Brasil</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Eslovênio</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraniano</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chinês Simplificado</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Autodetectar&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgaro</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Marcando essa opção poderá reduzir a cintilação, mas poderá também produzir um vídeo não adequado para exibição.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Grego</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Finlandês</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Esta opção especifica a posição das legendas sobre a janela de vídeo. &lt;i&gt;100&lt;/i&gt; significa a parte de baixo, enquanto &lt;i&gt;0&lt;/i&gt; significa a parte de cima.</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Sérvio</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chinês Tradicional</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Aqui você pode sobrepôr estilos de legendas SSA/ASS. Pode ser usado para o ajuste fino da renderização de legendas srt e sub pela biblioteca SAA/ASS. &lt;br&gt;Exemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Teclado e mouse</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romeno</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Português do Brasil</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Português de Portugal</translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Preferências</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Aplicar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Geral</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Caminhos</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Procurar...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Selecionar...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Pasta para salvar os screenshots:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Drivers de saída</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Vídeo:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Áudio:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Usar equalizador de vídeo por software</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Usar controle de volume por software</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Ajustes da mídia</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Lembrar dos ajustes de todos os arquivos (trilhas de áudio, legendas,...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Não lembrar da posição do filme (arquivos começam a reproduzir do ínicio)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Iniciar os vídeos em tela cheia</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Legendas</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fontes</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Selecione qual fonte será usada nas legendas (e OSD):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>Fonte TTF:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Escolha...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Fonte do Sistema:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Autoescala:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Sem autoescala</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proporcional à altura do filme</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proporcional à largura do filme</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proporcional ao tamanho da diagonal</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Escala:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Autocarregar</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Automaticamente selecionar a primeira legenda disponível</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>O mesmo nome do filme</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Todos as legendas contendo o nome do filme</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Todas as legendas no diretório</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Autocarregar arquivos de legenda (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Codificação padrão da legenda:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Usar biblioteca SSA/ASS para renderização das legendas</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Cor do texto:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Cor da borda:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Incluir legendas nos screenshots</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Avançado</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opções:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Você pode também passar filtros adicionais de video.
Separados com &quot;.&quot;. Não use espaços!
Exemplo: scale=512:-2.eq2=1.1</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Filtros de video:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>E finalmente filtros de áudio. As mesmas regras dos filtros de video.
Exemplo: resample=44100:0:0.volnorm</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Filtros de áudio:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Performance</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioridade:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>tempo real</translation>
    </message>
    <message>
        <source>high</source>
        <translation>alto</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>acima do normal</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>abaixo do normal</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>baixo</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Selecionando um cache pode melhorar a performance em mídia lenta</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Cache:</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Permitir eliminação de quadros</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Permitir uma eliminação de quadros pesada (pode gerar distorção na imagem)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Sincronização</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Sincronização de áudio/vídeo automática</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Fator:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Auto qualidade para filtro de pós processamento:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Nível:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Mais baixo</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Mais alto</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Troca de trilha de áudio rápida</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Busca rápida de capítulos em DVDs</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(cache será desativado e não é garantia de que realmente funcionará)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Desativar salva telas</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Relação do monitor:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Método de redimensionara a janela principal:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Sempre que necessário</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Apenas após carregar um novo vídeo</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Instância simples</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Usar apenas uma instância em execução do SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer irá ouvir esta porta para receber comandos de outras instâncias:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(mudanças nesse grupo exigem que o SMPlayer seja reiniciado)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Estilo:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Drives</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Atualmente o SMPlayer não auto-detecta dispositivos cdrom ou dvd. Portanto para usar um cdrom ou dvd você deve primeiro selecionar aqui os seus dispositivos (que podem ser o mesmo).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>icone</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Selecione seu dispositivo de CD:</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Selecione seu dispositivo de DVD:</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Arquivos recentes</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Max. items</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Limpar lista</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Procurando</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Volume padrão:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Mouse</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Botão de função:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Duplo clique</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Clique esquerdo</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Tamanho da janela</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Função da rodinha:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Procurar na mídia</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Controle de volume</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Mouse e teclado</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Teclado</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Esta opção é usada principalmente para o debugging da aplicação.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Língua:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Conjunto de icones:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Legenda e áudio preferenciais</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Legendas:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Selecionar o executável MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Executar o MPlayer em sua própria janela</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opções adicionais para o MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Aqui você pode passar opções extras para o MPlayer.
Escreva-as separadas por espaços.
Exemplo; -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Selecionar a prioridade para o processo do MPlayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Saída de log do MPlayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Saída de log do SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filtro para logs do SMPlayer:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Não repinte o fundo da janela de vídeo</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Aqui você pode modificar qualquer atalho de teclado. Para fazê-lo de um duplo clique ou digite sobre uma célula de atalho. Opcionalmente grave a lista e compartilhe com outras pessoas ou carregue em outro computador.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Selecione a primeira legenda disponível</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Posição padrão da legenda na tela</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Chave de cor:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Modificando...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Acima</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Abaixo</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Estilos:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Cachê</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Usar cachê</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS passando via S/PDIF</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Final do arquivo:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>Nenhum vídeo:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Legendas</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>Usar opção -subfont (requerida por recentes lançamentos do MPlayer)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>Biblioteca SSA/&amp;ASS</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>A nova biblioteca SSA/ASS irá provêr belos estilos de legenda para arquivos externos de legenda SSA/ASS e trilhas Matroska. Mas será também usada para renderizar outros formatos de arquivo como SUB e SRT.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Aqui você pode sobrepôr os estilos para legendas SSA/ASS. Também pode ser usado para um ajuste fino na renderização de legendas SRT e SUB pela biblioteca SSA/ASS. Exemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>&amp;Avançado</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>&amp;Logs</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>Linguagem do &amp;MPlayer</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>SMPlayer necessita de ler e converter a saída do MPlayer e muitas vezes isso é feito em inglês. Se você está usando um MPlayer traduzido para outra linguagem, então você deve modificar os textos que o SMPlayer procura. (Técnicamente você deve entrar com expressões regulares)&lt;br&gt;&lt;br&gt;
A lista drop-down vai providenciar as expressões regulares para várias linguagens.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Teclado</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Mouse</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation>Zoom vídeo</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation>Máx. Amplificação:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation>Normalização de volume</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation>Habilitar pós-processamento para todos os vídeos</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Qualidade:</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation>Aqui você pode sobrepôr os estilos para legendas SSA/ASS. Também pode ser usado para um ajuste fino na renderização de legendas SRT e SUB pela biblioteca SSA/ASS. Exemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 segundo</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 segundos</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 minutos</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%! minutos e %2 segundos</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 minuto e 1 segundo</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 minuto e %1 segundos</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 minutos e 1 segundo</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>icone</translation>
    </message>
    <message>
        <source>label</source>
        <translation>rótulo</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Equalizador</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Contraste</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Brilho</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Matiz</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Saturação</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Resetar</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>Definir como valor &amp;padrão</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Usar os valores atuais como padrão para novos vídeos.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Definir todos os controles como zero.</translation>
    </message>
</context>
</TS>
