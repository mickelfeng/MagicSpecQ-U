<!DOCTYPE TS><TS>
<defaultcodec></defaultcodec>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Frontend für mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Zu öffnende Datei</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Entwickler</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Version: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt Version: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Dieses Programm ist freie Software; Sie können es weitergeben und/oder es unter den Bedingungen der allgemeinen  GNU Lizenz verändern, wie es durch die Free Software-Foundation festgelegt wurde; entweder Version 2 der Lizenz, oder (nach ihrer Wahl) eine neuere Version.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Übersetzer:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Deutsch</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slowenisch</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italienisch</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Französisch</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Vereinfachtes Chinesisch</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russisch</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Ungarisch</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japanisch</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Niederländisch </translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainisch</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Brasilianisches Portugiesisch</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgisch</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tschechisch</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo designed von %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Updates erhalten von : %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>Über  SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 and %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polnisch</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Kompiliert mit KDE Unterstützung</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgarisch</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Türkisch</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Schwedisch</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbisch</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Traditionelles Chinesisch</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romanisch</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Portugiesisch aus Portugal</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Portugiesisch - Brasilien</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Portugiesisch - Portugal</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Tastaturkurzbefehl</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Speichern</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Laden</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Kurzbefehl-Dateien</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Dateinamen auswählen</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Überschreiben bestätigen ?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Die Datei %1 existiert bereits.
Überschreiben ?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Datei auswählen</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Die Datei konnte nicht gespeichert werden</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Die Datei konnte nicht geladen werden</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Datei...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>V&amp;erzeichnis...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Abspiellisten...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD im Laufwerk</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD Ordner...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Wiedergabe</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pause</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Bildlauf</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Wiederholen</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normale Geschwindigkeit</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Halbe Geschwindigkeit</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Doppelte Geschwindigkeit</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Geschwindigkeit &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Geschwindigkeit &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Geschwindigkeit</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Vollbild</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Kompaktmodus</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizer</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Bildschirmfoto</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>&amp;Immer im Vordergrund</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Nachbearbeitung</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Automatisch</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblocking</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ringing</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>&amp;Rauschen hinzufügen</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>F&amp;ilter</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Stumm</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Leiser &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Lauter &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Delay -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>D&amp;elay +</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filter</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Laden...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Delay &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Delay &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Hoch</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;Runter</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Abspielliste</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Anzahl der Einzelbilder anzeigen</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Einstellungen</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Logs einsehen</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Über &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>Über &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Öffnen</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Wiedergabe</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Untertitel</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Navigation</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Optionen</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Neueste Dateien</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Größe</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Aspect Ratio</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlacing</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>&amp;Rauschfilter</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Automatisch</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Pan &amp;&amp; Scan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;zu 16:9</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Keine</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Tiefpass(filter)5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>&amp;Lineare Überblendung</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormal</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Soft</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Spur</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Kanäle</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Stereo Mode</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>S&amp;tandard</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Linker Kanal</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Rechter Kanal</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Auswahl</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Titel</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Kapitel</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Blickwinkel</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Ausgeschaltet</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Zeitleiste</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Zeit</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Zeit + Zeit t&amp;otal</translation>
    </message>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer log</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer log</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;leer&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Abspiellisten</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle Dateien</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Datei wählen</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Information</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Die CDROM /DVD Laufwerke wurden nocht nicht konfiguriert. 
Das kann im folgenden Konfigurationsdialog gemacht werden.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Verzeichnis auswählen</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Untertitel</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Über Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Wiedergabe %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Wiedergabe / Pause</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pause / Bildlauf</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Entladen</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Warnung</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Port %1 wird schon von einer anderen Anwendung benutzt. 
Server kann nicht gestartet werden.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Server an Port %1 antwortet nicht. 
Die Option Einzelprozess wurde deaktiviert.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Beenden</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Ansicht &amp;Info und Eigenschaften...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>&amp;Nach links bewegen</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>&amp;Nach rechts bewegen</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>&amp;Hoch bewegen</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>&amp;Runter bewegen</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Pan &amp;&amp; Scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Vorherige Untertitelzeile</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>&amp;Nächste Untertitelzeile</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Leiser (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Lauter (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Vollbild beenden</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Nächste Stufe</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Kontrast -</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Kontrast +</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Helligkeit -</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Helligkeit +</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Farbe -</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Farbe +</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Sättigung -</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Gamma -</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Nächste Audiodatei</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Nächster Untertitel</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Nächstes Kapitel</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Vorheriges Kapitel</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Sättigung +</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Gamma +</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation>Doppelte Größe schalten</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>&amp;Externe Datei laden...</translation>
    </message>
    <message>
        <source>Y&amp;adif (mode 1)</source>
        <translation type="obsolete">Y&amp;adif (Mode 1)</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (mode 0)</source>
        <translation type="obsolete">&amp;Yadif (Mode 0)</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (Normal)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (Doppelte Framerate)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Nächster</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Vorheriger</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation>Lautstärke &amp;normalisieren</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation>&amp;Audio CD</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer läuft noch hier</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>&amp;Icon im Sytem-Tray zeigen</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Ausblenden</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Wiederherstellen</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Neueste Dateien</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Beenden</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Helligkeit: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Kontrast: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Farbe: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Sättigung: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Lautstärke: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Willkommen im SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Lautstärke</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Untertitel</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Abspielliste</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>Hauptsymbolleiste</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Symbolleiste für Sprachen</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Symbolleisten</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>West-Europäische Sprachen</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>West-Europäische Sprachen mit Euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Slavische/Zentral-Europäische Sprachen</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galicisch, Maltesisch, Türkisch</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Alte Baltische Zeichenkodierung</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Kyrillisch</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabisch</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Modern Griechisch</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Türkisch</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Baltisch</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Celtic</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Hebräische Zeichkodierung</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russisch</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrainisch, Weißrussisch</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Vereinfachte Chinesische Zeichenkodierung</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Traditionelle Chinesische Zeichnenkodierung</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japanische Zeichenkodierung</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Koreanische Zeichenkodierung</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thailändische Zeichenkodierung</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Kyrillisch Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Slavisch/Zentral-Europäisches Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqRegler</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>Icon</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Datei-Eigenschaften</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Auswahl Demuxer, der auf die Datei angewendet wird:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;Video-Codec</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Auswahl Video-Codec:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>A&amp;udio-Codec</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Auswahl Audio-Codec:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>&amp;MPlayer Optionen</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Optionen:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Zusätzliche Angaben für Videofilter. 
Angaben werden durch &quot;,&quot; gerennt.
Keine Leerzeichen verwenden! 
Beispiel: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>&amp;Videofilter:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Audiofilter.
Regeln wie bei den Videofiltern. 
Beispiel: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>&amp;Audiofilter:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Übernehmen</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Zusätzliche Optionen für MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Hier können zusätzliche mplayer-Optionen angeben werden. 
Angaben werden durch Leerzeichen getrennt .
Beispiel: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Pfad</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Dauer</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Künstler</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Genre</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Track</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Urheberrecht</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Clip Info</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Auflösung</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Aspect Ratio</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Bilder pro Sekunde</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Verwendeter Codec</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Startwert Audio Stream</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Samplingrate</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanäle</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Audio Stream</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>leer</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Untertitel</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Streamtitel</translation>
    </message>
    <message>
        <source>Stream url</source>
        <translation type="obsolete">Stream URL</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>Stream URL</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Verzeichnis auswählen</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Wiedergabe der DVD, kann auch von der Festplatte erfolgen. 
Auswahl des Ordners, der das VIDEO_TS und das AUDIO_TS Verzeichnis enthält.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Verzeichnis auswählen...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer -Wiedergabe DVD aus einem Ordner</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Wähle Dateinamen für speichern unter</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Überschreiben bestätigen ?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Die Datei existiert bereits. 
Überschreiben ?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Fehler beim Speichern der Datei</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Log-Datei konnte nicht gespeichert werden</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Log Window</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Kopiere zum Clipboard</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Dauer</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Datei auswählen</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Dateinamen auswählen</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Überschreiben bestätigen ?</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Auswahl von einer, oder mehrerer Dateien, zum Öffnen</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Verzeichnis auswählen</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Die Datei %1 existiert bereits.
Überschreiben ?</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Name bearbeiten</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Den Dateinamen schreiben, wie er in der Abspielliste angezeigt werden soll:</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Wiedergabe</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Bearbeiten</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Abspiellisten</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle Dateien</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Laden</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Speichern</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Nächster</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Vorheriger</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>&amp;Hoch</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>&amp;Runter</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Wiederholen</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Zufall</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>&amp;Aktuelle Datei hinzufügen</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>&amp;Datei(en) hinzufügen</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>&amp;Verzeichnis hinzufügen</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>&amp;Ausgewählte Datei entfernen</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>&amp;Alles entfernen</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Hinzufügen...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Entfernen...</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Abspielliste</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Abspielliste geändert</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Ungesicherte Änderungen, soll die Abspielliste gespeichert werden ?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Untertitel</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>mplayer (*.exe) auswählen</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>TTF-Datei wählen</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Verzeichnis auswählen</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Leistungsverhalten</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Erweitert</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Laufwerke</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Ausführbare Datei</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Alle Dateien</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype Schriftarten (*.ttf)</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Kleiner Sprung</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Normaler Sprung</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Langer Sprung</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Sprung per Mausrad</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nichts</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Maus und Tastatur</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Hier wird der Order zur Speicherung der Bildschirmfotos festgelegt. 
Ohne Eingabe wird die Funktion abgeschaltet.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Auswahl Video-Ausgabe Treiber. Gewöhnlich erzielt xv (Linux) und DirectX (Windows) die beste Leistung.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Audio-Ausgabe 
Treiber 
wählen.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Option, falls der Video-Equalizer die Grafikkarte, oder den Video-Ausgabe Treiber nicht unterstützt.&lt;br&gt;&lt;b&gt;Hinweis:&lt;/b&gt; Die Option kann inkompatibel zu einigen Video-Ausgabe Treibern sein.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Optional kann der Software-Mixer anstelle des Karten-Mixers eingestellt werden.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Mit dieser Option erfolgt die smplayer Wiedergabe aller Dateien immer von Anfang an.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Mit dieser Option erfolgt die Wiedergabe von smplayer im Vollbild-Modus.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Optional kann der Bildschirmschoner während der Wiedergabe deaktiviert werden.&lt;br&gt; Aktiviert wird der Bildschirmschoner nach Beendigung der Wiedergabe.&lt;br&gt;&lt;b&gt; Diese Option ist nur für X11 und Windows. </translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Hier muß die ausführbare mplayer-Datei angegeben werden.&lt;br&gt; smplayer benötigt mindestens mplayer 1.0rc1 (svn empfohlen)&lt;br&gt;&lt;b&gt;Sollte diese Einstellung falsch sein, ist die Wiedergabe von smplayer ausser Funktion.</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Die Ausgabeinformationen von mplayer kann optinoal von smplayer gespeichert werden.(hier zu finden &lt;b&gt;Optionen-&gt;Logs einsehen-&gt;mplayer&lt;/b&gt;. In Problemfällen können die Logs wichtige Informationen enthalten,daher wird diese Option empfohlen.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Optional speichert smplayer die debugging Informationen von smplayer. (Hier zu finden &lt;b&gt;Optionen-&gt;Logs einsehen-&gt;smplayer&lt;/b&gt;) Diese Informationen können wichtig für Entwickler, bei der Fehlersuche, sein.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Optional können Nachrichten von smplayer gefiltert werden. Hier kann man irgendeinen regelulärer Ausdruck schreiben.&lt;br&gt;Zum Beispiel: &lt;i&gt;^Core::.*&lt;/i&gt; Nur Zeilen werden  dargestellt, beginned mit &lt;i&gt;Core: :&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Hinweis:&lt;/b&gt; Diese Option ist nur für Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Festlegen der Prozessorpriorität gemäß der Verfügbarkeit unter Windows.&lt;br&gt;&lt;b&gt;WARNUNG:&lt;/b&gt;Echtzeitpriorität kann das System blockieren.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Normalerweise erinnert sich smplayer an die Einstellungen jeder wiedergegebenen Datei (gewählte Tonspur, Lautstärke,Filter...). Bei Nichtgefallen,abstellen.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Hier kann die bevorzugte Sprache der Tonspur gewählt werden.Bei Medien mit mehreren Tonspuren,wird Smplayer versuchen die bevorzugte Sprache zu benutzen.Das funktioniert nur mit Medien die eine Info über die Tonspuren bereit stellen, wie DVDs oder mkv-Dateien.&lt;br&gt;Das Feld akzeptiert normale Ausdrücke. Beispiel: &lt;b&gt;es|esp|spa&lt;/b&gt; die Tonspur mit folgender Info wird ausgewählt &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Hier kann die bevorzugte Sprache der Tonspur gewählt werden.Bei Medien mit mehreren Tonspuren,wird Smplayer versuchen die bevorzugte Sprache zu benutzen.Das funktioniert nur mit Medien die eine Info über die Tonspuren bereit stellen, wie DVDs oder mkv-Dateien.&lt;br&gt;Das Feld akzeptiert normale Ausdrücke. Beispiel: &lt;b&gt;es|esp|spa&lt;/b&gt; die Tonspur mit folgender Info wird ausgewählt &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Diese Option legt fest,wieviel Speicher (in kBytes) zum Vorausladen einer Datei, oder URL bereitgestellt werden. Besonders nützlich bei langsamen Medien.  </translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Überspringen einiger Einzelbilder, um A/V Synchronisation auf langsamen Systemen zu gewährleisten.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Intensive Einzelbildersprünge (Brüche beim Dekodieren) . Führt zu Bildverzerrungen!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Justiert stufenweise die A/V Synchronisierung, die auf Audioverzögerungen (Delay) basiert.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Ändert dynamisch das Niveau der Nachbearbeitung, abhängig von der vorhandenen freien CPU Zeit. Die spezifizierte Zahl, ist das maximale benutzte Niveau. Normalerweise kann irgendeine grosse Zahl angeben werden.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tschechisch</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Deutsch</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Englisch</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Spanisch</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Französisch</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Ungarisch</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italienisch</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japanisch</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgisch</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Niederländisch </translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polnisch</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Brasilianisches Portugiesisch</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russisch</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slowenisch</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrainisch</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Vereinfachtes Chinesisch</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Automatisch&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgarisch</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Aktivieren der Option kann Flackern/Flimmern verringern, aber es könnte auch sein, dass das Video nicht mehr ordentlich dargestellt wird. </translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Türkisch</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Griechisch</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Finnisch</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Schwedisch</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Diese Option bestimmt die Position der Untertitel über dem Videofenster.&lt;i&gt;100&lt;/i&gt; bedeutet Unten (Buttom), während &lt;i&gt;0&lt;/i&gt; Oben  (Top) bedeutet.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Die Stilart für die SSA/AAS Utertitel kann hier außer Kraft gesetzt werden. Es kann auch zum Fine-Tunning, für die gerenderten srt und sub Untertitel,  durch die SSA/ASS Library, benutzt werden.&lt;br&gt;Beispiel: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbisch</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Traditionelles Chinesisch</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Hier kann der Stil für die SSA/ASS Untertitel aufgehoben werden. Ebenfalls können Feinabstimmungen zur Darstellung von srt und sub Untertiteln, mit der SSA/ASS Library, vorgenommen werden.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>MPlayer language</source>
        <translation type="obsolete">MPlayer Sprache</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Tastatur und Maus</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Portugiesisch aus Portugal</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romanisch</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Portugiesisch - Brasilien</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Portugiesisch - Portugal</translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Einstellungen</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Allgemein</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Pfade</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Auswahl...</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Suchen...</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Audio:</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Untertitel</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Schriftart</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Auswahl der Schriftart für Untertitel (und OSD):</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Auswählen...</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Automatische Skalierung:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Keine automatische Skalierung</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proportional  zu Filmhöhe</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proportional  zur Fimbreite</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proportional zur Filmdiagonale</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Skalierung:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Automatisch laden</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Untertitel automatisch laden (*.srt,*.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Filmtitel als Name</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Alle Untertitel die Filmnamen enthalten</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Alle Untertitel im Verzeichnis</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Automatische Auswahl der ersten verfügbaren Untertiteldatei</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>SSA/ASS-Programmbibliothek zum Rendern von Untertiteln benutzen</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Optionen:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Videofilter:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Audiofilter:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Übernehmen</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF Schriftart:</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>System-Schriftart:</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Bilschirmschoner abschalten</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Niemals</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Wann immer es benötigt wird</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Erst nach dem Laden eines neuen Videos</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Cache:</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Verzeichnis für Bilschirmfotos:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Benutze Software-Video-Equalizer</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Benutze Software-Lautstärkeregelung</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Hauptfenster Resizing Methode:</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Textfarbe:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Rahmenfarbe:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Erweitert</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Leistungsverhalten</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorität:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>Realzeit</translation>
    </message>
    <message>
        <source>high</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>Über Normal</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>Niedrig</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>Leerlauf</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Überspringen von Bildern erlauben</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Verstärktes überspringen von Bildern erlauben. (Kann zu Bildverzerrungen führen)</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>DVD Laufwerk auswählen:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>CD Laufwerk auswählen:</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Media-Einstellungen</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Einstellungen für alle Dateien beibehalten (Audiospur, Untertitel...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Zeitposition nicht wieder herstellen (Wiedergabe startet von Anfang an)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Stil:</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Seitenverhältnis:</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Starte Video im Vollbildmodus</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Laufwerke</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Automatische Qualitätsstufe für die Filter zur Nachbearbeitung:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Stufe:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Niedrigste</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Höchste</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Ausgabe Gerätetreiber</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Synchronisation</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Automatische Audio/Video Synchronisation</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Standard Untertitel Encodierung:</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(Cache wird abgeschaltet und es gibt keine Garantie auf Funktionstüchtigkeit)</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Schnelle Suche in DVD-Kapiteln</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Einstellung des Cachespeichers, kann Leistungsverhalten auf langsamen Systemen verbessern</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Schneller Tonspurwechsel</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Untertitel miteinbeziehen auf Bidschirmfotos</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Einzelprozess</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Nur einen laufenden SMPlayer-Prozess verwenden</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer wird diesen Port überwachen, um Befehle von anderen Prozessen zu empfangen: </translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(Änderungen in dieser Gruppe, erfordern einen Neustart von SMPlayer)</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Zusätzliche Angaben für Videofilter.
Angaben werden durch &quot;,&quot; gerennt. Keine Leerzeichen verwenden!
Beispiel: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Audiofilter.
Regeln wie bei den Videofiltern. 
Beispiel: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Momentan kann SMPlayer CD- und DVD-Laufwerke nicht automatisch finden.
Um CDs oder DVDs abzupielen, müßen die Laufwerke vorher bestimmt werden.</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>Icon</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Neueste Dateien</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Max. Stücke</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Liste löschen</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Positionierung</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Lautstärke</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Standard Lautstärke:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Maus</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Tasten-Funktion:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Doppel Click</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Click links</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Fenstergröße</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>(Maus) Rad-Funktion:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Media Positionierung</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Kontrolle Lautstärke</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Maus und Tastatur</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Tastatur</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Diese Option ist hauptsächlich zum Austesten der Anwendung. </translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Sprache:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Iconsatz:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Bevorzugter Ton und Untertitel</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Untertitel</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Die ausführbare mplayer-Datei auswählen:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Wiedergabe im mplayer-Fenster</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Zusätzliche Optionen für MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Hier können zusätzliche mplayer-Optionen angeben werden. 
Angaben werden durch Leerzeichen getrennt .
Beispiel: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Auswahl der Prozessorpriorität für mplayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Log mplayer Ausgabe</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Log SMPlayer Ausgabe</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filter für SMPlayer logs:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Hintergrund vom Videofenster nicht ausfüllen.</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Hier kann jeder Tastaturkurzbefehl geändert werden. Doppelklick, oder direktes editieren, in dem  Eingabefeld des Tastaturkurzbefehls. Optional kann die Liste zur Weitergabe gespeichert und auf einem anderen Computer weiterverwendet werden.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Den ersten vorhandenen Untertitel auswählen</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Standard Position der Untertitel auf dem Bildschirm</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Farbschlüssel:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Ändern…</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Höchste Position</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Niedrigste Position</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Stilarten:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Cache benutzen</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Größe:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS über S/PDIF</translation>
    </message>
    <message>
        <source>Use subfont (required by recent MPlayer releases)</source>
        <translation type="obsolete">Subfont anwenden (erfoderlich bei neueren Mplayer Versionen)</translation>
    </message>
    <message>
        <source>MPlayer language</source>
        <translation type="obsolete">MPlayer Sprache</translation>
    </message>
    <message>
        <source>SMPlayer looks for English texts in the MPlayer output. If your MPlayer is configured to display the output in another language you need to change here the texts that SMPlayer should look for.</source>
        <translation type="obsolete">SMPlayer verwendet englische Texte der MPlayer Ausgabe. Wenn MPlayer so  konfiguriert wurde, um die Ausgabe in einer anderen Sprache darzustellen, müssen hier die Texte geändert werden, die SMPlayer verwenden soll. </translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Dateiende:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>Kein Video:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Untertitel</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>Subfont Optionen anwenden (erfoderlich bei neueren Mplayer Versionen)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>SSA/&amp;ASS Library</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>Die neue SSA/ASS Bibliothek produziert schön gestaltete Untertitel für externe SSA/ASS und Matroska-Dateien. Aber sie wird auch zum Rendern anderer Formate verwendet, wie sub und srt-Dateien.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Hier kann der Stil für die SSA/ASS Untertitel aufgehoben werden. Ebenfalls können Feinabstimmungen zur Darstellung von srt und sub Untertiteln, mit der SSA/ASS Library, vorgenommen werden.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>&amp;Erweitert</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>&amp;Logs</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>&amp;Mplayer Sprache</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>SMPlayer muß die meist englischsprachige Textausgabe von MPlayer lesen und analysieren. Liegt eine übersetzte MPlayer-Version vor, muß die Textsuche von SMPlayer angepasst werden.(Technisch sollten reguläre Ausdrücke eintragen werden) &lt;br&gt;&lt;br&gt;
Die Auswahl-Liste enthält evt.schon die regulären Ausdrücke.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Tastatur</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Maus</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation>Zoom Video</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation>Max. Verstärker:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation>Lautstärke normalisieren</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation>Nachbearbeitung für alle Videos aktivieren</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Qualität:</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation>Hier kann der Stil für die SSA/ASS Untertitel aufgehoben werden. Ebenfalls können Feinabstimmungen zur Darstellung von srt und sub Untertiteln, mit der SSA/ASS Library, vorgenommen werden.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt; {2 or 4?}</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 Sekunde</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 Sekunden</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 Minuten</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 Minuten und %2 Sekunden</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 Minute</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 Minute und 1 Sekunde</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 Minute und %1 Sekunden</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 Minuten und 1 Sekunde</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>Positionierungsgerätebasis</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>Icon</translation>
    </message>
    <message>
        <source>label</source>
        <translation>Kennzeichnung</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Helligkeit</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Farbe</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Sättigung</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>Equalizer</source>
        <translation>Equalizer</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Als Standard Wert einstellen</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Die jetzigen Werte als Standardwerte für neue Videos.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Alle Steuerungen auf Null.</translation>
    </message>
</context>
</TS>
