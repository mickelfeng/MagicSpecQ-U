<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Front-end para el mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Fichero para abrir</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Programador</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Versión: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Versión Qt: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Este programa es Software Libre; usted puede redistribuirlo y/o modificarlo bajo los términos de la &quot;GNU General Public License&quot; como lo publica la &quot;FSF Free Software Foundation&quot;, o (a su elección) de cualquier versión posterior.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Traductores:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Alemán</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Eslovaco</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francés</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chino simplificado</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Ruso</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Húngaro</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonés</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandés</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraniano</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugués de Brasil</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Checo</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo diseñado por %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Consigue actualizaciones en: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>Acerca de SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 y %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polaco</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Compilado con soporte para el KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Búlgaro</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbio</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chino tradicional</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Rumano</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Portugués de Portugal</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Portugués - Brasil</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Portugués - Portugal</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Atajo</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Grabar</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Cargar</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Ficheros de atajos</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Elige un fichero</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>¿Confirmar sobreescribir?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>El fichero %1 ya existe.
¿Quieres sobreescribirlo?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Elige un fichero</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>El fichero no se ha podido grabar</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>El fichero no se ha podido cargar</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer log</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer log</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>A&amp;brir</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Reproducir</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Vídeo</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>A&amp;udio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Subtítulos</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Navegar</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Opciones</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ayuda</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Fichero...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>D&amp;irectorio...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Lista de reproducción...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD desde unidad lectora</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD desde una carpeta...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Borrar</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>Ficheros &amp;recientes</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Reproducir</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pausa</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Detener</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Avanzar fotograma</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>Velocidad &amp;normal</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Reducir a la mitad</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Doblar</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Velocidad &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Velocidad &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Velocidad</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>R&amp;epetir</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Pantalla completa</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Modo compacto</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Tamaño</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>A&amp;utodetectar</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;a 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation type="unfinished">&amp;Aspect ratio</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Ninguno</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Desentrelazado</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocesado</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetección de fase</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Añadir r&amp;uido</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>&amp;Filtros</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Ecualizador</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Captura</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>E&amp;ncima de todas las ventanas</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Pista</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtros</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>Por &amp;defecto</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>E&amp;stéreo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Canales</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>Canal &amp;izquierdo</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>Canal &amp;derecho</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Modo estéreo</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Silenciar</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Volumen &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Volumen &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Retrasar -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>R&amp;etrasar +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Seleccionar</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Cargar...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Retrasar &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Retrasar &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Arriba</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>A&amp;bajo</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Título</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Capítulo</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Ángulo</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Lista de reproducción</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Mostrar contador de imágenes</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Desactivado</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Barra de progreso</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Tiempo</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Tiempo + Tiempo t&amp;otal</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Ver logs</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>P&amp;referencias</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Acerca de &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>Acerca de &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;vacío&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Listas de reproducción</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Todos los ficheros</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Elige un fichero</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Información</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Las unidades de CDROM / DVD no han sido configuradas.
Se mostrará a continuación el diálogo de configuración.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Elige un directorio</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Subtítulos</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Acerca de Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Reproduciendo %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>&amp;Quitar ruido</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormal</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Suave</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Reproducir / Pausa</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pausa / Avanzar fotograma</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Descargar</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Advertencia</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>El puerto %1 ya está siendo utilizado por otro programa.
No se puede iniciar el servidor.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>El servidor del puerto %1 no responde.
Se ha desactivado la opción de una única instancia.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Salir</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>C&amp;errar</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Ver &amp;información y propiedades...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reiniciar</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Desplazar &amp;izquierda</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Desplazar &amp;derecha</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Desplazar &amp;arriba</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Desplazar a&amp;bajo</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>Pan &amp;&amp; &amp;scan</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>Ir a línea a&amp;nterior</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>Ir a línea &amp;posterior</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Bajar volumen (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Subir volumen (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Salir de pantalla completa</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Siguiente nivel</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Bajar contraste</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Subir contraste</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Bajar brillo</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Subir brillo</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Bajar tono</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Subir tono</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Bajar saturación</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Bajar gamma</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Siguiente audio</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Siguiente subtítulo</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Siguiente capítulo</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Capítulo anterior</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Subir saturación</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Subir gamma</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation>Tamaño normal / tamaño doble</translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>C&amp;argar archivo externo...</translation>
    </message>
    <message>
        <source>Y&amp;adif (mode 1)</source>
        <translation type="obsolete">Y&amp;adif (modo 1)</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (mode 0)</source>
        <translation type="obsolete">&amp;Yadif (modo 0)</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normal)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (doble framerate)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Siguiente</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Anterior</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Normalización de volumen</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation>CD de &amp;audio</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer sigue funcionando aquí</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>I&amp;cono en la bandeja del sistema</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Ocultar</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Restaurar</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>Ficheros &amp;recientes</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Salir</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Brillo: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Contraste: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Tono: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Saturación: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Volumen: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Bienvenido a SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volumen</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Subtítulo</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Lista de reproducción</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>Barra &amp;principal</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>Barra de &amp;idioma</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Barras de herramientas</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Occidental</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Occidental con euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Eslavo/Centroeuropeo</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Gallego, Maltés, Turco</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Báltico antiguo</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cirílico</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Árabe</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Griego moderno</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Báltico</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Céltico</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Hebreo</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Ruso</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ucraniano, Belaruso</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Chino simplificado</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Chino tradicional</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japonés</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Coreano</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thai</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Cirílico Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Eslavo/Centroeuropeo Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Propiedades del fichero</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Información</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Selecciona el demuxer que se usará para este fichero:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reiniciar</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>Códec de &amp;vídeo</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Selecciona el códec de vídeo:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>Códec de a&amp;udio</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Selecciona el códec de audio:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>Opciones para el &amp;MPlayer</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Opciones:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>También puedes pasar filtros de vídeo adicionales.
Sepáralos con &quot;,&quot;. ¡No uses espacios!
Ejemplo: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>Filtros de víd&amp;eo:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Y finalmente los filtros de audio. Misma norma que para los filtros de audio.
Ejemplo: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>&amp;Filtros de audio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>A&amp;plicar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opciones Adicionales para el MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Aquí puedes pasar opciones extra al MPlayer.
Escríbelas separadas por espacios.
Ejemplo: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Duración</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Artista</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Álbum</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Género</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Pista</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resolución</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Imágenes por segundo</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Códec seleccionado</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Pista de audio inicial</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Canales</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Pistas de audio</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>vacío</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Subtítulos</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>nº</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Título del stream</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>URL del stream</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Elige un directorio</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Es posible reproducir un dvd desde el disco duro. Simplemente selecciona la carpeta que contiene los directorios VIDEO_TS y AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Elegir un directorio...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Reproducir un DVD desde una carpeta</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Elige el nombre de fichero</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>¿Confirmar sobreescribir?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>El fichero ya existe.
¿Quieres sobreescribirlo?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Error al grabar el fichero</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>No se ha podido grabar el fichero log</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Log Window</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Copiar al portapapeles</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Duración</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Elige un fichero</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Elige un fichero</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>¿Confirmar sobreescribir?</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Selecciona uno o más ficheros</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Elige un directorio</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>El fichero %1 ya existe.
¿Quieres sobreescribirlo?</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Editar nombre</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Teclea el nombre que se mostrará en la lista para este fichero:</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Reproducir</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Listas de reproducción</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Todos los ficheros</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Cargar</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Grabar</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Siguiente</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Anterior</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>&amp;Bajar</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>&amp;Subir</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>R&amp;epetir</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Desordenar</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Añadir fichero &amp;actual</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Añadir &amp;fichero(s)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Añadir &amp;directorio</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Borrar &amp;selección</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Borrar &amp;todo</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Lista de reproducción</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Añadir...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Borrar...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Lista de reproducción modificada</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Hay cambios sin guardar, ¿quieres grabar la lista de reproducción?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Subtítulos</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Selecciona el ejecutable del mplayer</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Elige un fichero ttf</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Seleccionar un directorio</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Rendimiento</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Unidades de disco</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Ejecutables</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Todos los ficheros</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Fuentes Truetype</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Salto corto</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Salto medio</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Salto largo</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Rueda del ratón</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguna</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfaz</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Ratón y teclado</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Aquí puedes especificar la carpeta donde se guardarán las capturas de pantalla. Si dejas el campo vacío no se realizarán capturas de pantalla.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Selecciona el driver de vídeo. Normalmente xv (linux) y directx (windows) proporcionan el mejor rendimiento.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Selecciona el driver de audio.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Puedes marcar esta opción si tu tarjeta gráfica o el driver de vídeo no tienen soporte para ecualizador de vídeo.&lt;br&gt;&lt;b&gt;Nota:&lt;/b&gt; esta opción puede ser incompatible con algunos drivers de vídeo.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Marca esta opción para usar el mezclador por software, en lugar del mezclador de la tarjeta de sonido.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Si marcas esta opción, smplayer reproducirá todos los ficheros desde el principio.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Si esta opción está marcada, todos los vídeos comenzarán a reproducirse a pantalla completa.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Marca esta opción para desactivar el salvapantallas durante la reproducción.&lt;br&gt;El salvapantallas se volverá a activar cuando la reproducción acabe.&lt;br&gt;&lt;b&gt;Nota:&lt;/b&gt; Esta opción sólo funciona en X11 y Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Aquí debes especificar el ejecutable del mplayer que será usado por el smplayer.&lt;br&gt;smplayer requiere al menos mplayer 1.0rc1 (svn recomendado).&lt;br&gt;&lt;b&gt;Si esta opción es incorrecta, ¡smplayer no será capaz de reproducir nada!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Si está marcada, smplayer almacenará la salida del mplayer (la puedes ver en &lt;b&gt;Opciones-&gt;Ver logs-&gt;mplayer&lt;/b&gt;). En caso de problemas este log puede contener información importante, por tanto es recomendable mantener activada esta opción.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Si esta opción está marcada, smplayer almacenará los mensajes de depuración que emite (puedes verlos en &lt;b&gt;Opciones-&gt;Ver logs-&gt;smplayer&lt;/b&gt;). Esta información puede ser muy útil para el programador en caso de que encuentres algún bug.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Esta opción permite filtrar los mensajes que se almacenarán en el log. Aquí puedes escribir cualquier expresión regular.&lt;br&gt;Por ejemplo: &lt;i&gt;^Core::.*&lt;/i&gt; mostrará sólo las líneas que comiencen por &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Nota:&lt;/b&gt; Esta opción es sólo para Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Por defecto</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Establece la prioridad del proceso del mplayer según las prioridades disponibles en Windows.&lt;br&gt;&lt;b&gt;ADVERTENCIA:&lt;/b&gt; Usar la prioridad realtime puede causar el cuelgue del sistema.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Normalmente smplayer recordará las opciones para cada fichero que reproduzcas (la pista de audio seleccionada, el volumen, los filtros...). Desmarca esta opción si no te gusta que haga esto.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Aquí puedes introducir el idioma preferido para la pista de audio. Cuando se reproduzca un vídeo con múltiples pistas de audio, smplayer intentará usar tu idioma preferido.&lt;br&gt;Esto sólo funcionará con medios que ofrezcan información sobre los idiomas de las pistas de audio, como los DVDs o ficheros mkv.&lt;br&gt;Este campo acepta expresiones regulares. Ejemplo: &lt;b&gt;es|esp|spa&lt;/b&gt; seleccionará la pista de audio si coincide con &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; o &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Aquí puedes introducir el idioma preferido para los subtítulos. Cuando se reproduzca un vídeo con múltiples subtítulos, smplayer intentará usar tu idioma preferido.&lt;br&gt;Esto sólo funcionará con medios que ofrezcan información sobre los idiomas de los subtítulos, como los DVDs o ficheros mkv.&lt;br&gt;Este campo acepta expresiones regulares. Ejemplo: &lt;b&gt;es|esp|spa&lt;/b&gt; seleccionará el subtítulo si coincide con &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; o &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Checo</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Alemán</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Inglés</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Español</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francés</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Húngaro</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonés</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandés</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polaco</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugués de Brasil</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Ruso</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Eslovaco</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraniano</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chino simplificado</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Autodetectar&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Búlgaro</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Marcando esta opción se pueden reducir los parpadeos, pero también podría pasar que el vídeo no se mostrase correctamente.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Griego</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Finés</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Esta opción especifica la posición de los subtítulos en la ventana de vídeo. &lt;i&gt;100&lt;/i&gt; es abajo del todo, mientras que &lt;i&gt;0&lt;/i&gt; es la parte más alta.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Aquí puedes modificar los estilos de los subtítulos SSA/ASS. También se puede utilizar para ajustar la forma en que la libreria SSA/ASS genera los subtítulos srt y sub.&lt;br&gt;Ejemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbio</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chino tradicional</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Aquí puedes modificar los estilos de los subtítulos SSA/ASS. También se puede utilizar para ajustar la forma en que la libreria SSA/ASS genera los subtítulos srt y sub.&lt;br&gt;Ejemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>MPlayer language</source>
        <translation type="obsolete">Idioma de MPlayer</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Teclado y ratón</translation>
    </message>
    <message>
        <source>Portuguese from Portugal</source>
        <translation type="obsolete">Portugués de Portugal</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Rumano</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Portugués - Brasil</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Portugués - Portugal</translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Preferencias</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">General</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Trayectorias</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Seleccionar...</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Buscar...</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Vídeo:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Audio:</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Subtítulos</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Tipo de letra</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Selecciona el tipo de letra que se usará para los subtítulos (y OSD):</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Elegir...</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Autoescalar:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>No autoescalar</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proporcional a la altura del vídeo</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proporcional a la anchura del vídeo</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proporcional a la diagonal del vídeo</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Escala:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Autocargar</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Autocargar ficheros de subtítulos (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>De igual nombre que el vídeo</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Todos los que contengan el nombre del vídeo</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Todos los subtítulos del directorio</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Seleccionar automáticamente el primer subtítulo disponible</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Usar la librería SSA/ASS para dibujar los subtítulos</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opciones:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Filtros de vídeo:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Filtros de audio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>A&amp;plicar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>Fuente ttf: </translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Fuente del sistema:</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Desactivar salvapantallas</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Siempre que sea necesario</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Sólo después de cargar un nuevo vídeo</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Cache:</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Carpeta donde se guardarán las capturas:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Usar ecualizador de vídeo por software</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Usar control de volumen por software</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Ajuste del tamaño de la ventana:</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Color del texto:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Color del borde:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Avanzado</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Rendimiento</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioridad:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>high</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>idle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Permitir saltar fotogramas</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Permitir saltar aún más fotogramas (puede corromper la imagen)</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Selecciona tu dispositivo DVD:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Selecciona tu dispositivo CD:</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Opciones para el vídeo</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Recordar las opciones para cada vídeo (pista de audio, subtítulos...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>No recordar por donde se quedó el vídeo (reproducción desde el inicio)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Estilo:</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Aspect ratio del monitor:</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Comenzar los vídeos a pantalla completa</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Unidades de disco</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Calidad para el filtro de postprocesado:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Nivel:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">El más bajo</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">El mayor</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Drivers de salida</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Sincronización</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Factor:</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Sincronización automática de audio y vídeo</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Codificación de los subtítulos:</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(se deshabilitará la caché y no hay garantía de que realmente funcione)</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Selección rápida de capítulos en dvds</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Usar una caché puede mejorar el rendimiento en medios lentos</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Cambio rápido de pista de audio</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Incluir subtítulos en las capturas de pantalla</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Instancias de SMPlayer</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Usar sólo una única instancia de SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer escuchará este puerto para recibir órdenes de otras instancias:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(los cambios en este grupo requieren que el programa sea reiniciado)</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>También puedes pasar filtros de vídeo adicionales.
Sepáralos con &quot;,&quot;. ¡No uses espacios!
Ejemplo: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Y finalmente los filtros de audio. Misma norma que para los filtros de audio.
Ejemplo: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Actualmente SMPlayer no autodetecta unidades de cdrom o dvd. Por tanto para que sea posible reproducir cdroms o dvds es necesario que selecciones tu unidad de cd y dvd (pueden ser la misma).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Ficheros recientes</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Máx. entradas</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Borrar lista</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Búsqueda</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volumen</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Volumen por defecto:</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished">0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Ratón</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Funciones de los botones:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Doble click</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Botón izquierdo</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Tamaño de la ventana</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfaz</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Función de la rueda:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Desplazarse por el medio</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Controlar el volumen</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Ratón y teclado</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Teclado</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logs</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Esta opción es principalmente para depurar la aplicación.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Idioma:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Juego de iconos:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Audio y subtítulos preferidos</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Subtítulos:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Selecciona el ejecutable del MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Ejecutar el MPlayer en su propia ventana</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opciones Adicionales para el MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Aquí puedes pasar opciones extra al MPlayer.
Escríbelas separadas por espacios.
Ejemplo: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Selecciona la prioridad con la que se ejecutará el MPlayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Guardar los textos de la salida del MPlayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Guardar los textos de la salida del SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filtro para los logs del SMPlayer:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>No redibujar el fondo de la ventana de vídeo</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Aquí puedes cambiar los atajos de teclado. Para hacerlo haz doble click o empieza a escribir sobre un atajo. Opcionalmente también puedes guardar la lista para compartirla con otras personas o usarla en otro ordenador.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Seleccionar el primer subtítulo disponible</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Posición por defecto de los subtítulos en la pantalla</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Colorkey:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Cambiar...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Estilos:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Caché</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Usar caché</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use subfont (required by recent MPlayer releases)</source>
        <translation type="obsolete">Usar subfont (necesario en versiones recientes de MPlayer)</translation>
    </message>
    <message>
        <source>MPlayer language</source>
        <translation type="obsolete">Idioma de MPlayer</translation>
    </message>
    <message>
        <source>SMPlayer looks for English texts in the MPlayer output. If your MPlayer is configured to display the output in another language you need to change here the texts that SMPlayer should look for.</source>
        <translation type="obsolete">SMPlayer busca textos en inglés en la salida de MPlayer. Si tu MPlayer está configurado para mostrar los mensajes en otro idioma, necesitarás cambiar aquí los textos que SMPlayer debe buscar.</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Final de fichero:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>No hay vídeo:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Subtítulos</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>Usar la opción -subfont (necesario en versiones recientes de MPlayer)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>Librería SSA/&amp;ASS</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>La nueva librería SSA/ASS es capaz de mostrar estupendos subtítulos para ficheros SSA/ASS y pistas Matroska. También se usará para mostrar subtítulos en otros formatos, como ficheros SUB y SRT.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Aquí puedes modificar los estilos de los subtítulos SSA/ASS. También se puede utilizar para ajustar la forma en que la libreria SSA/ASS genera los subtítulos SRT y SUB. Ejemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>&amp;Avanzado</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>&amp;Logs</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>&amp;Idioma del MPlayer</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>Para el perfecto funcionamiento del programa, SMPlayer tiene que leer e interpretar los mensajes de salida del MPlayer y a veces busca textos en inglés. Si estás usando un MPlayer traducido a otro idioma, entonces necesitas cambiar los textos que SMPlayer busca. (Técnicamente debes introducir expresiones regulares)&lt;br&gt;&lt;br&gt;
Los combos proporcionan algunas expresiones regulares ya hechas para varios idiomas.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Teclado</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Ratón</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation>Hacer zoom en el vídeo</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation>Máx. amplificación:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation>Normalización de volumen</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation>Activar el postprocesado para todos los vídeos</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Calidad:</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation>Aquí puedes modificar los estilos de los subtítulos SSA/ASS. También se puede utilizar para ajustar la forma en que la libreria SSA/ASS genera los subtítulos SRT y SUB. Ejemplo: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation>&amp;General</translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation>&amp;Vídeo y audio</translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation>&amp;Tipo de letra</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 segundo</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 segundos</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 minutos</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 minutos y %2 segundos</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 minuto y 1 segundo</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 minuto y %1 segundos</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 minutos y 1 segundo</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Contrast</source>
        <translation>Contraste</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Brillo</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Tono</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Saturación</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>Equalizer</source>
        <translation>Ecualizador</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reiniciar</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Usar como valores por defecto</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Usa los valores actuales como valores por defecto para los nuevos vídeos.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Pone todos los controles a cero.</translation>
    </message>
</context>
</TS>
