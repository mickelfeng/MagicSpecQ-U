<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>MPlayer 的前端</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>要開啟的檔案</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>開發者</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>確定(&amp;O)</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>版本: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt 版本: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>這個軟體是自由軟體; 你可以在 GPL 或 GPL2 或之後版本下修改/重新發佈它。</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>翻譯者:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>德語</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>斯洛伐克語</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>意大利語</translation>
    </message>
    <message>
        <source>French</source>
        <translation>法語</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>簡體中文</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>俄羅斯語</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>匈牙利語</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>日語</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>荷蘭語</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>烏克蘭語</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">葡萄牙語 (巴西)</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation> 喬治亞語</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>捷克語</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo 設計 %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>於 %1 獲得最新版本</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>關於 SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 和 %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>波蘭語</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>編譯包括 KDE 支持</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>保加利亞語</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>土耳其語</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>瑞典語</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>塞爾維亞語</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>正體中文</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>快捷鍵</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>儲存(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>載入(&amp;L)</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation type="unfinished">Key files</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>選擇一個檔名</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>是否覆寫?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>檔案 %1 己存在。
是否覆寫?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>選擇一個檔案</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>檔案無法儲存</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>檔案無法載入</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - Mplayer 日誌</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - SMPlayer 日誌</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>開啟(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>播放(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>視訊(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>音訊(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>字幕(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>瀏覽(&amp;B)</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>選項(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>說明(&amp;H)</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>檔案(&amp;F)...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>目錄(&amp;I)...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>播放清單(&amp;P)...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>從磁碟機開啟 &amp;DVD</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>從目錄開啟 D&amp;VD...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>清空(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>最近使用的文件(&amp;R)</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>播放(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>暫停(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>停止(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation type="unfinished">Frame step(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>常速(&amp;N)</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>半速(&amp;H)</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>兩倍速(&amp;D)</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>速度 &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>速度 &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>速度(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>重復(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>全螢幕(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>精簡模式(&amp;C)</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>大小(&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>自動偵測(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;to 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>外觀比例(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>無(&amp;N)</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>Deinterlace(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation type="unfinished">&amp;Postprocessing</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>自動偵測(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Add n&amp;oise</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>過濾器(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>等化器(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>螢幕擷取(&amp;S)</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>置頂(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>音軌(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>擴展立體聲(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;卡拉OK</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>過濾器(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>預設(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>立體聲(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 環繞</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 環繞</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>聲道(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>左聲道(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>右聲道(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>立體聲模式(&amp;M)</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>静音(&amp;M)</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>音量 &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>音量 &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>延遲 - (&amp;D)</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>延遲 + (&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>選擇(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>載入(&amp;L)...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>延遲 &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>延遲 &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>上移(&amp;U)</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>下移(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>標題(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>章節(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>角度(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>播放清單(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation type="unfinished">Show frame counter(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>停用(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>定位條(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>時間(&amp;T)</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>時間 + 總時間(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>OSD(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>檢視日誌(&amp;V)</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>設定(&amp;R)</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>關於 &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>關於 &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;無&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>播放清單</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>所有檔案</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>選擇一個檔案</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - 資訊</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM / DVD 磁碟尚未設置。
你可以在下面顯現的配置對話框裡設置。</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>選擇一個目錄</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>字幕</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>關於 Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>播放 %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>暫停</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation type="unfinished">De&amp;noise</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>標準(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>軟體(&amp;S)</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>播放 / 暫停</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>暫停 / Frame step</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>卸載(&amp;N)</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - 警告</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>連接埠 %1 已經被其它程序占用。
無法啟動伺服器。</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>在連接埠 %1 的伺服器没有回應。
單實體選項已被停用。</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">退出(&amp;Q)</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>關閉(&amp;L)</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>檢視資訊和內容(&amp;I)...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>縮小(&amp;-)</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>放大(&amp;+)</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>重設(&amp;R)</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>左移(&amp;L)</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>右移(&amp;R)</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>上移(&amp;U)</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>下移(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation type="unfinished">全景瀏覽(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>前一行字幕(&amp;P)</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>後一行字幕(&amp;E)</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>降低音量(2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>增加音量(2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>退出全螢幕</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="unfinished">OSD - 下一級别</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>降低對比度</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>增加對比度</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>降低亮度</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>增加亮度</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>降低色调</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>增加色调</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>降低飽和度</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>降低 Gamma</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>下一音訊</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>下一字幕</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>下一章節</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>前一章節</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>增加飽和度</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>增加 Gamma</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">下一個(&amp;N)</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">上一個(&amp;V)</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer 運行中</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>在系統閘裡顯示圖示(&amp;H)</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>隱藏(&amp;H)</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>恢復(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>最近使用的文件(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">退出(&amp;Q)</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>亮度: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>對比度: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>色調: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>飽和度: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>音量: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>縮放: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>歡迎使用 SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>音量</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>音訊</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>字幕</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>播放清單</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>主工具列(&amp;M)</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>語言工具列(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>工具列(&amp;T)</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Arabic</source>
        <translation>阿拉伯語</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>波羅的海</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>凱爾特語</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cyrillic</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Cyrillic Windows</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>世界語</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>希伯来語</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>日語</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>韓語</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>希臘語</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>波羅的海語</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>俄羅斯語</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>簡體中文</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>斯拉夫語</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>斯拉夫語</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>泰語</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>正體中文</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>土耳其語</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>烏克蘭語</translation>
    </message>
    <message>
        <source>Western European Languages</source>
        <translation>西歐</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>西歐</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation type="unfinished">等化器滑塊</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>圖示</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - 檔案屬性</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>資訊(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>解碼器(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>選擇將用於這個檔案的解碼器(&amp;S):</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>重設(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;視訊編碼</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation type="unfinished">&amp;選擇視訊編碼:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>音訊編碼(&amp;u)</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;選擇音訊編碼:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>&amp;Mplayer 選項</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>選項(&amp;O):</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>在這裡你可以傳遞附加的視訊過濾器。
請用 &quot;,&quot; 分隔它們。不要使用空格!
示例: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>視訊過濾器(&amp;I):</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>最後是音訊過濾器。和視訊過濾器的規則一樣。
示例: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>音訊過濾器(&amp;F):</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>確定(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>套用(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>取消(&amp;C)</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>MPlayer 額外選項</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>在這裡你可以傳遞額外的選項给 Mplayer。
請用空格分隔它們。
示例 : -flip -nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>一般</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>路徑</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>長度</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>解碼器</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>藝術家</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>專輯</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>流派</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>音軌</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>版權</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>注釋</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>軟體</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>剪輯資訊</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>視訊</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>解析度</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>外觀比例</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>位元率</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>幀/秒</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>選擇的編碼解碼器</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>初始化音訊串流</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>比率</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>聲道</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>音訊串流</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>語言</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>空</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>字幕</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>類型</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation type="unfinished">串流標題</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>串流 URL</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>選擇一個目錄</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>&amp;Cancel</source>
        <translation>取消(&amp;C)</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>選擇一個目錄...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>確定(&amp;O)</translation>
    </message>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - 從目錄裡播放 DVD</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>你可以從你的硬碟播放 DVD 。只要選擇包含 VIDEO_TS 和 AUDIO_TS 目錄的資料夾即可。</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation type="unfinished">Choose a filename to save under</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>是否覆寫?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>儲存檔案出錯</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>檔案己存在。
是否覆寫?</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>日誌無法儲存</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>複製到剪貼板</translation>
    </message>
    <message>
        <source>Log Window</source>
        <translation>日誌視窗</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>儲存</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>關閉(&amp;C)</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>All files</source>
        <translation>所有檔案</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>選擇一個目錄</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>選擇一個檔案</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>選擇一個檔名</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>是否覆寫?</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>編輯(&amp;E)</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>編輯名字</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>長度</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>播放(&amp;P)</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>播放清單</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>選擇開啟一個或多個檔案</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>檔案 %1 己存在。
是否覆寫?</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation type="unfinished">給這個檔案輸入一個顯示在播放清單的名字:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>載入(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>儲存(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>下一個(&amp;N)</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>上一個(&amp;V)</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>上移(&amp;U)</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>下移(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>重復(&amp;R)</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>隨機(&amp;H)</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>加入目前的檔案(&amp;C)</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>加入檔案(&amp;F)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>加入目錄(&amp;D)</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>移除已選取的(&amp;S)</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>全部移除(&amp;A)</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - 播放清單</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>新增...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>移除...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>播放清單己修改</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>修改尚未儲存，您想儲存播放清單嗎?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>Advanced</source>
        <translation>進階</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>所有檔案</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>選擇一個 ttf 檔案</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>磁碟</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>可執行</translation>
    </message>
    <message>
        <source>General</source>
        <translation>一般</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>效能</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>選擇一個目錄</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>選擇 Mplayer 的可執行檔</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>字幕</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype 字體</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>短跳躍</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>跳躍</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>長跳躍</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>滑鼠滾輪跳躍</translation>
    </message>
    <message>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>界面</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">滑鼠和鍵盤</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation type="unfinished">這裡你可以設置 SMPlayer 存放截圖的目錄。如果這裡為空，截圖功能將被停用。</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>選擇影像輸出驅動程式。通常 xv (linux) 和 directx (windows) 能提供最佳性能。</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>選擇音訊輸出驅動程式。</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation type="unfinished">如果視訊等化器不被您的顯示卡或選擇的輸出驅動程式支持，您可以勾選此選項。&lt;br&gt;&lt;b&gt;注意:&lt;/b&gt;這個選項可能和一些影像輸出驅動程式不兼容。</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>勾選這個選項以使用軟體混音(不使用音效卡混音)。</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>如果勾選此選項，SMPlayer 將從頭播放所有檔案。</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>如果勾選此選項，所有的視訊將一開始就使用全螢幕模式。</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>勾選此選項將在播放時停用螢幕保護程式。&lt;br&gt;播放結束後螢幕保護程式會重啟。&lt;br&gt;&lt;b&gt;注意:&lt;/b&gt; 這個選項只在 X11 和 Windows 下有效。</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>這裡您必須指定 SMPlayer 要使用的 MPlayer 的可執行文件。&lt;br&gt;SMPlayer 需要至少 1.0rc1 的 MPlayer (推荐 SVN 版)。&lt;br&gt;&lt;b&gt;如果此設定錯誤，SMPlayer 將無法播放任何東西!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>如果勾選，SMPlayer 將儲存 MPlayer 的輸出 (你可以在&lt;b&gt;選項-&gt;查看記錄-&gt;mplayer&lt;/b&gt;查看)。如果出現錯誤，此日誌可能包含重要資訊，所以推荐勾選。</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>如果勾選，SMPlayer 將儲存 SMPlayer 輸出的除錯訊息 (你可以在&lt;b&gt;選項-&gt;查看記錄-&gt;smplayer&lt;/b&gt;查看)。當你找到 bug 時，對於開發者將會是非常重要的資訊。</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>這個選項允許過濾 SMPlayer 將要儲存的日誌。這裡您可以使用任何正則表達式。&lt;br&gt;示例:&lt;i&gt;^Core::..*&lt;/i&gt; 將只顯示以 &lt;i&gt;Core::&lt;/i&gt; 開頭的行</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">日誌</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;注意:&lt;/b&gt; 這個選項是 Windows 專有的。</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>預設</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>為 MPlayer 設置優先級 (根據 Windows 下的命名習慣)。&lt;br&gt;&lt;b&gt;警告:&lt;/b&gt; 使用即時會將您的系统鎖死。</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>預設情况下 SMPlayer 會記住您播放的每一個檔案的設定(選擇的音軌，音量，過濾器...)。如果您不喜歡這個特性，請不要勾選此項。</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished">這裡您可以輸入您喜好的語言和音訊串流。當在媒體裡發現多個音訊串流時，SMPlayer 將試圖使用您的喜好語言。&lt;br&gt;這只在媒體提供語言和音效流資訊時有效, 像 DVD 或 mkv 文件。&lt;br&gt;這裡支持正則表達式。示例: &lt;b&gt;es|esp|spa&lt;/b&gt; 將選擇符合 &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; 或 &lt;i&gt;spa&lt;/i&gt; 的音軌。</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished">這裡您可以輸入您喜好的語言和音效流。當在媒體裡發現多個音效流時, SMPlayer 將試圖使用您的喜好語言。&lt;br&gt;這只在媒體提供語言和音效流資訊時有效, 像 DVD 或 mkv 文件。&lt;br&gt;這裡支持正則表達式。示例: &lt;b&gt;es|esp|spa&lt;/b&gt; 將選擇符合 &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; 或 &lt;i&gt;spa&lt;/i&gt; 的音軌。</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation type="unfinished">這裡指定用於讀取檔案或 URL 的記憶體大小(KB)。對於 Slow Media 特别有用。</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation type="unfinished">在較慢的系统上，跳過一些幀來保證 A/V 同步。</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation type="unfinished">大量幀被跳過(解碼錯誤)。將導致畫面變形!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation type="unfinished">根據音訊延遲來調整 A/V 同步。</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation type="unfinished">Dynamically changes the level of postprocessing depending on the available spare CPU time. 這個數字說明將被用到的最大級别。通常您可以選用較大的數字。</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>捷克語</translation>
    </message>
    <message>
        <source>German</source>
        <translation>德語</translation>
    </message>
    <message>
        <source>English</source>
        <translation>英語</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>西班牙語</translation>
    </message>
    <message>
        <source>French</source>
        <translation>法語</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>匈牙利語</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>意大利語</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>日語</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>喬治亞語</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>荷蘭語</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>波蘭語</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">葡萄牙語</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>俄羅斯語</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>斯洛伐克語</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>烏克蘭語</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>簡體中文</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;自動偵測&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>保加利亞語</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>選擇這個選項可以減少閃爍。但也可能造成視訊不能正常顯示。</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>土耳其語</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>希臘語</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>芬蘭語</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>瑞典語</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>這個選項指定字幕在視訊視窗裡的位置。&lt;i&gt;100&lt;/i&gt;表示底部, &lt;i&gt;0&lt;/i&gt;表示頂部。</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">這裡您可以重設 SSA/ASS 字幕的風格。 在選用 SSA/ASS 庫來演算上色 srt 字幕, 也將使用該設置。&lt;br&gt;示例: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>塞爾維亞語</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>正體中文</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>abovenormal</source>
        <translation>高於標準</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">進階</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation type="unfinished">Allow frame drop</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation type="unfinished">Allow hard frame drop (可能導致圖像變形)</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>所有包含影片名的字幕</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>目錄裡的所有字幕</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="unfinished">最後是音訊過濾器。和視訊過濾器的規則一樣。
示例: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>套用(&amp;A)</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>音訊:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>音訊過濾器:</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>音訊/視訊 自動同步</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>自動載入</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>自動載入字幕檔 (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">自动选择第一个可用的字幕</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Auto quality for postprocessing filter:</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>自動縮放:</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>低於標準</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>邊框顏色:</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">快取:</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(如果不能保證其能够使用，快取將被停用)</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>取消(&amp;C)</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(這裡的變更要在 SMPlayer 重啟後才能生效)</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>選擇...</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>預設字幕編碼:</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>停用螢幕保護程式</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>不要記住目前的播放位置 (從頭開始播放)</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>磁碟</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>因子:</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>快速音軌切換</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>在 DVD 裡快速定位章節</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>儲存截圖的目錄:</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>字體</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">一般</translation>
    </message>
    <message>
        <source>high</source>
        <translation>高</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">最高</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>閒置</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>將字幕包含在截圖裡</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">等级:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">最低</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>主視窗縮放方式:</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>媒體設定</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>鎖定外觀:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>從不</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>無自動縮放</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>標準</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>確定(&amp;O)</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>只在新影片載入後</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>選項:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>輸出磁碟</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>路徑</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>效能</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>優先级:</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>相對於影片的對角線</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>相對於影片的高度</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>相對於影片的寬度</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>即時</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>記住所有檔案的設定 (音軌，字幕...)</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>和影片同名的字幕</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>比例:</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>搜尋...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>選擇...</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>選擇字幕 (和 OSD) 的字體:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>選擇你的 CD 磁碟:</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>選擇你的 DVD 磁碟:</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>設定快取可以改進播放性能</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation type="unfinished">單實體</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - 效能</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation type="unfinished">SMPlayer 會在這個連接埠接收其它實體的命令:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>用全螢幕播放</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>風格:</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">字幕</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>同步</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>系統字體:</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>文字顏色:</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF 字體:</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>只使用一個運行的 SMPlayer 實體</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>使用軟體影像等化器</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>使用軟體音量控制</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>使用 SSA/AAS 庫來演算上色字幕</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>視訊:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>視訊過濾器:</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>當需要的時後</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="unfinished">在這裡你可以傳遞附加的視訊過濾器。
請用 &quot;,&quot; 分隔它們。不要使用空格!
示例: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>現在 SMPlayer 還不能自動檢測光碟機或 DVD 磁碟。所以你必需選擇你的光碟機和 DVD 磁碟，才能播放 CD 或 DVD。</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>圖示</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>最近開啟的檔案</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>最大項數</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>清空清單</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>定位</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>音量</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>預設音量:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">滑鼠</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>按鍵功能:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>双擊</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>左擊</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>視窗大小</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>介面</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>滾輪功能:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>媒體定位</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>音量控制</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">滑鼠和鍵盤</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">鍵盤</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">日誌</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>這個選項主要用於此應用程式的除錯。</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>語言:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>圖示集:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>偏好的音訊和字幕</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>字幕:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>優先級</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>選擇 Mplayer 的可執行檔案:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>讓 Mplayer 在自己的視窗裡運行</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>MPlayer 的附加選項</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished">在這裡你可以傳遞額外的選項给 Mplayer。
請用空格分隔它們。
示例 : -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>選擇 MPlayer 程式的優先級。</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>日誌 MPlayer 的輸出</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>日誌 SMPlayer 的輸出</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>過濾 SMPlayer 的日誌:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>不重繪影像視窗的背景</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>在這裡您可以更改任何快捷鍵。通過在一個快捷鍵單元格双擊或鍵入來設定。
您也可以儲存您的設定，然後分享给他人或載入别的電腦上。</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>選擇第一個可用的字幕</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>字幕在螢幕上的預設位置</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation type="unfinished">Colorkey:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>修改...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>頂部</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>底部</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>風格:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">字幕(&amp;S)</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">視訊</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">音訊</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 秒</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 秒</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 分鐘</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 分鐘 %2 秒鐘</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 分鐘</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 分鐘 1 秒鐘</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 分鐘 %1 秒鐘</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 分鐘 1 秒鐘</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>圖示</translation>
    </message>
    <message>
        <source>label</source>
        <translation>標籤</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Brightness</source>
        <translation>亮度</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>對比度</translation>
    </message>
    <message>
        <source>Equalizer</source>
        <translation>等化器</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>色調</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>飽和度</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>重設(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>設為預設值(&amp;S)</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>將當前值做為新視訊的預設值。</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>全部設置為零。</translation>
    </message>
</context>
</TS>
