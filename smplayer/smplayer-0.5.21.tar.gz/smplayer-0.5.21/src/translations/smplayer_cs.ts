<!DOCTYPE TS><TS>
<defaultcodec></defaultcodec>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Front-end pro MPlayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Soubor k otevření</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Vývojář</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Verze: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt verze: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Tento program je volný software, který můžete šířit a modifikovat pod GNU General Public License publikovanou Free Software Foundation od verze 2, případně pozdější.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Lokalizace:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Německá</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovenská</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italská</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francouzská</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Čínská</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Ruská</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Maďarská</translation>
    </message>
    <message>
        <source>%1 and %2 (Polish)</source>
        <translation type="obsolete">%1 a %2 (Polská)</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonská</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandská</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrajinská</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugalská</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Gragoriánská</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Česká</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo vytvořil %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Nová verze: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>O SMPlayeru</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 a %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polská</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Přeloženo s podporou KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulharská</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Turecké</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Název</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished">&amp;Uložit</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation type="unfinished">&amp;Načíst</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation type="unfinished">Zvolit název souboru</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation type="unfinished">Potvrdit přepsání?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished">Soubor %1 už existuje.
Opravdu jej chcete přepsat?</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="unfinished">Zvolit soubor</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>&amp;File...</source>
        <translation>S&amp;oubor...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>&amp;Adresář...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Seznam...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD z mechaniky</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD z adresáře...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Exit</source>
        <translation type="obsolete">&amp;Konec</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>P&amp;řehrát</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pozastavit</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Krok po snímku</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Spustit / Pozastavit</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pozastavit / Krok po snímku</translation>
    </message>
    <message>
        <source>&amp;-10 seconds</source>
        <translation type="obsolete">&amp;-10 sekund</translation>
    </message>
    <message>
        <source>-1 &amp;minute</source>
        <translation type="obsolete">-1 &amp;minuta</translation>
    </message>
    <message>
        <source>-10 mi&amp;nutes</source>
        <translation type="obsolete">-10 m&amp;inut</translation>
    </message>
    <message>
        <source>&amp;+10 seconds</source>
        <translation type="obsolete">&amp;+10 sekund</translation>
    </message>
    <message>
        <source>+1 m&amp;inute</source>
        <translation type="obsolete">+1 m&amp;inuta</translation>
    </message>
    <message>
        <source>+10 min&amp;utes</source>
        <translation type="obsolete">+10 min&amp;ut</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Opakovat</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normální rychlost</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Poloviční rychlost</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>&amp;Dvojnásobná rychlost</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Rychlost &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Rychlost &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>Rych&amp;lost</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Celá obrazovka</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Kompaktní mód</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizér</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Snímek obrazovky</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>&amp;Vždy na vrchu</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Dodatečné zpracování</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetekce fáze</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Přidat š&amp;um</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>F&amp;iltry</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Ztlumit</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Hlasitost &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Hlasitost &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>&amp;Zpoždění -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>Z&amp;poždění +</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extra Stereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtry</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Načíst...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Zpoždění &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Zpoždění &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Nahoru</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;Dolů</translation>
    </message>
    <message>
        <source>View &amp;info</source>
        <translation type="obsolete">Zobrazit &amp;informace</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Seznam</translation>
    </message>
    <message>
        <source>&amp;Advanced media settings...</source>
        <translation type="obsolete">&amp;Podrobné nastavení médií...</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Zobrazit počítadlo snímků</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Nastavení</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Zobrazit logy</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>O &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>O &amp;SMplayeru</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Otevřít</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Přehrát</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Titulky</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>Navi&amp;gace</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>&amp;Možnosti</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Nápověda</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Naposledy otevřené</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Vyčistit</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Velikost</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Poměr stran</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlace</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>Po&amp;tlačení šumu</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Autodetekce</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;na 16:9</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>Žá&amp;dné</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormální</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Jemné</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;Stopa</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Kanály</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Stereo mód</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;Výchozí</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Levý kanál</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Pravý kanál</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Vybrat</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Titul</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Kapitola</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>Ú&amp;hel</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;vypnuto</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Ukazatel pozice</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>Č&amp;as</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Čas + &amp;Celkový čas</translation>
    </message>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer log</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer log</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;prázdné&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Seznamy</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všechny soubory</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Zvolit soubor</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMplayer - informace</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Mechaniky CDROM/DVD nejsou nastaveny
Bude zobrazeno konfigurační okno.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Zvolit adresář</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <source>About SMplayer</source>
        <translation type="obsolete">O SMplayeru</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation type="obsolete">Verze: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation type="obsolete">Qt verze: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation type="obsolete">Tento program je volný software, který můžete šířit a modifikovat pod GNU General Public License publikovanou Free Software Foundation od verze 2, případně pozdější.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation type="obsolete">Lokalizace:</translation>
    </message>
    <message>
        <source>German</source>
        <translation type="obsolete">Německá</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="obsolete">Slovenská</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="obsolete">Italská</translation>
    </message>
    <message>
        <source>French</source>
        <translation type="obsolete">Francouzská</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation type="obsolete">Čínská</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="obsolete">Maďarská</translation>
    </message>
    <message>
        <source>%1 and %2 (Polish)</source>
        <translation type="obsolete">%1 a %2 (Polsko)</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="obsolete">Japonská</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="obsolete">Holandská</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="obsolete">Ukrajinská</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugalská</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation type="obsolete">Logo vytvořil %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation type="obsolete">Nová verze: %1</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>O Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Přehrávám %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pozastavit</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Varování</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Port %1 používá jiná aplikace.
Server nelze spustit.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Server na portu %1 neodpovídá.
Režim jedné instance bude vypnut.</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>U&amp;volnit</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Konec</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Zavřít</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Zobrazit &amp;info a vlastnosti...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished">&amp;Reset</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation type="unfinished">&amp;Posunout nahoru</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation type="unfinished">Po&amp;sunout dolů</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;Další</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">&amp;Předchozí</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer zde stále běží</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>Z&amp;obrazit ikonu v systémové liště</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Skrýt</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Obnovit</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Naposledy otevřené</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">&amp;Konec</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Jas: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Kontrast: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Odstín: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Saturace: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Hlasitost: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Vítá Vás SMplayer</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Hlavní nástrojová lišta</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Lišta výběru jazyka</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Nástrojové lišty</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Hlasitost</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Seznam</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Západoevropské jazyky</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Západoevropské jazyky s Euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Středoevropské jazyky</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Staré baltské kódování</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cyrilika</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabské</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Moderní řečtina</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turecké</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Baltské</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Keltské</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Hebrejské</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Ruské</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrajinské</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Jednoduchá čínština</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Tradiční čínština</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japonské</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Korejské</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Thajské</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Cyrilika Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Středoevropské Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EQ posuvník</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
</context>
<context>
    <name>FilePreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Advanced media settings</source>
        <translation type="obsolete">SMPlayer - Rozšířené nastavení medií</translation>
    </message>
    <message>
        <source>In this dialog you can set advanced settings for the current file.
These settings will be saved and used when you load this file again.</source>
        <translation type="obsolete">Tento dialog umožňuje další nastavení pro stávající soubor.
Toto nastavení bude uloženo a použito opět při otevření tohoto souboru.</translation>
    </message>
    <message>
        <source>Additional Options</source>
        <translation type="obsolete">Další možnosti</translation>
    </message>
    <message>
        <source>Here you can pass extra options to mplayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="obsolete">Zde můžete zadat extra parametry pro MPlayer.
Oddělujte je mezerami.
Příklad: -flip -nosound</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation type="obsolete">Můžete použít další video filtry.
Oddělujte je čárkou, nepoužívejte mezery.
Příklad: scale=512:-2;eq2=1.1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation type="obsolete">A nakonec audio filtry. Stejná pravidla jako video filtry.
Příklad: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="obsolete">&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="obsolete">&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="obsolete">&amp;Použít</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="obsolete">&amp;Zrušit</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation type="obsolete">&amp;Možnosti MPlayeru</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation type="obsolete">&amp;Možnosti:</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation type="obsolete">V&amp;ideo filtry:</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation type="obsolete">Audio &amp;filtry:</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation type="obsolete">&amp;Dekodér</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation type="obsolete">&amp;Výběr dekodéru který bude použit pro tento soubor:</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation type="obsolete">&amp;Video kodek</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation type="obsolete">Vý&amp;běr video kodeku:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation type="obsolete">A&amp;udio kodek</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation type="obsolete">Výběr &amp;Audio kodeku:</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Vlastnosti souboru</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informace</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Dekodér</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Výběr dekodéru který bude použit pro tento soubor:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;Video kodek</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>Vý&amp;běr video kodeku:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>A&amp;udio kodek</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>Výběr &amp;Audio kodeku:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>&amp;Možnosti MPlayeru</translation>
    </message>
    <message>
        <source>Additional Options</source>
        <translation type="obsolete">Další možnosti</translation>
    </message>
    <message>
        <source>Here you can pass extra options to mplayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="obsolete">Zde můžete zadat extra parametry pro MPlayer.
Oddělujte je mezerami.
Příklad: -flip -nosound</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Možnosti:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Můžete použít další video filtry.
Oddělujte je čárkou, nepoužívejte mezery.
Příklad: scale=512:-2;eq2=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideo filtry:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>A nakonec audio filtry. Stejná pravidla jako video filtry.
Příklad: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>Audio &amp;filtry:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Použít</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Další volby pro MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Zde můžete zadat extra parametry pro MPlayer.
Oddělujte je mezerami.
Příklad: -flip -nosound</translation>
    </message>
</context>
<context>
    <name>Gui</name>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Seznam</translation>
    </message>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation type="obsolete">Vítá Vás SMplayer</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="obsolete">&amp;Otevřít</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation type="obsolete">&amp;Přehrát</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="obsolete">&amp;Video</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation type="obsolete">&amp;Audio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="obsolete">&amp;Titulky</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation type="obsolete">Navi&amp;gace</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation type="obsolete">&amp;Možnosti</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="obsolete">&amp;Nápověda</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation type="obsolete">S&amp;oubor...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation type="obsolete">&amp;Adresář...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation type="obsolete">&amp;Seznam...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation type="obsolete">&amp;DVD z mechaniky</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation type="obsolete">D&amp;VD z adresáře...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation type="obsolete">&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation type="obsolete">&amp;Naposledy otevřené</translation>
    </message>
    <message>
        <source>&amp;Exit</source>
        <translation type="obsolete">&amp;Konec</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation type="obsolete">P&amp;řehrát</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation type="obsolete">&amp;Pozastavit</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation type="obsolete">&amp;Stop</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation type="obsolete">&amp;Krok po snímku</translation>
    </message>
    <message>
        <source>&amp;-10 seconds</source>
        <translation type="obsolete">&amp;-10 sekund</translation>
    </message>
    <message>
        <source>&amp;+10 seconds</source>
        <translation type="obsolete">&amp;+10 sekund</translation>
    </message>
    <message>
        <source>-1 &amp;minute</source>
        <translation type="obsolete">-1 &amp;minuta</translation>
    </message>
    <message>
        <source>+1 m&amp;inute</source>
        <translation type="obsolete">+1 m&amp;inuta</translation>
    </message>
    <message>
        <source>-10 mi&amp;nutes</source>
        <translation type="obsolete">-10 m&amp;inut</translation>
    </message>
    <message>
        <source>+10 min&amp;utes</source>
        <translation type="obsolete">+10 min&amp;ut</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation type="obsolete">&amp;Normální rychlost</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation type="obsolete">&amp;Poloviční rychlost</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation type="obsolete">&amp;Dvojnásobná rychlost</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation type="obsolete">Rychlost &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation type="obsolete">Rychlost &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation type="obsolete">Rych&amp;lost</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation type="obsolete">&amp;Celá obrazovka</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation type="obsolete">&amp;Kompaktní mód</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation type="obsolete">&amp;Autodetekce</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation type="obsolete">&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation type="obsolete">&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation type="obsolete">&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation type="obsolete">16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation type="obsolete">1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation type="obsolete">&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation type="obsolete">4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation type="obsolete">16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation type="obsolete">4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation type="obsolete">4:3 &amp;na 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation type="obsolete">&amp;Poměr stran</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation type="obsolete">Žá&amp;dné</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation type="obsolete">&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation type="obsolete">Linear &amp;Blend</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation type="obsolete">&amp;Deinterlace</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation type="obsolete">&amp;Dodatečné zpracování</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation type="obsolete">&amp;Autodetekce fáze</translation>
    </message>
    <message>
        <source>Denoise (&amp;normal)</source>
        <translation type="obsolete">Odstranění šumu (&amp;normální)</translation>
    </message>
    <message>
        <source>Denoise (&amp;soft)</source>
        <translation type="obsolete">Odstranění šumu (&amp;jemné)</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation type="obsolete">&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation type="obsolete">De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation type="obsolete">Přidat š&amp;um</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation type="obsolete">F&amp;iltry</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation type="obsolete">&amp;Equalizér</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation type="obsolete">&amp;Snímek obrazovky</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation type="obsolete">&amp;Stopa</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation type="obsolete">&amp;Extra Stereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation type="obsolete">&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation type="obsolete">&amp;Filtry</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation type="obsolete">&amp;Výchozí</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation type="obsolete">&amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation type="obsolete">&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation type="obsolete">&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation type="obsolete">&amp;Kanály</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation type="obsolete">&amp;Levý kanál</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation type="obsolete">&amp;Pravý kanál</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation type="obsolete">&amp;Stereo mód</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation type="obsolete">&amp;Ztlumit</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation type="obsolete">Hlasitost &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation type="obsolete">Hlasitost &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation type="obsolete">&amp;Zpoždění -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation type="obsolete">Z&amp;poždění +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation type="obsolete">&amp;Vybrat</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation type="obsolete">&amp;Načíst...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation type="obsolete">Zpoždění &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation type="obsolete">Zpoždění &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation type="obsolete">&amp;Nahoru</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation type="obsolete">&amp;Dolů</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation type="obsolete">&amp;Titul</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation type="obsolete">&amp;Kapitola</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="obsolete">Ú&amp;hel</translation>
    </message>
    <message>
        <source>View &amp;info</source>
        <translation type="obsolete">Zobrazit &amp;informace</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation type="obsolete">&amp;Seznam</translation>
    </message>
    <message>
        <source>&amp;Advanced media settings...</source>
        <translation type="obsolete">&amp;Podrobné nastavení médií...</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation type="obsolete">&amp;Zobrazit počítadlo snímků</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation type="obsolete">&amp;Ukazatel pozice</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation type="obsolete">Č&amp;as</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation type="obsolete">Čas + &amp;Celkový čas</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation type="obsolete">&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation type="obsolete">&amp;Zobrazit logy</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation type="obsolete">&amp;Nastavení</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="obsolete">O &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation type="obsolete">O &amp;SMplayeru</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation type="obsolete">&lt;prázdné&gt;</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation type="obsolete">Seznamy</translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="obsolete">Všechny soubory</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="obsolete">Zvolit soubor</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation type="obsolete">SMplayer - informace</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation type="obsolete">Mechaniky CDROM/DVD nejsou nastaveny
Bude zobrazeno konfigurační okno.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation type="obsolete">Zvolit adresář</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Titulky</translation>
    </message>
    <message>
        <source>About SMplayer</source>
        <translation type="obsolete">O SMplayeru</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation type="obsolete">Verze: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation type="obsolete">Qt verze: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation type="obsolete">Tento program je volný software, který můžete šířit a modifikovat pod GNU General Public License publikovanou Free Software Foundation od verze 2, případně pozdější.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation type="obsolete">Lokalizace:</translation>
    </message>
    <message>
        <source>German</source>
        <translation type="obsolete">Německá</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="obsolete">Slovenská</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="obsolete">Italská</translation>
    </message>
    <message>
        <source>French</source>
        <translation type="obsolete">Francouzská</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation type="obsolete">Čínská</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="obsolete">Ruská</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="obsolete">Maďarská</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation type="obsolete">Nová verze: %1</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="obsolete">O Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation type="obsolete">Přehrávám %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pauza</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Stop</translation>
    </message>
    <message>
        <source>%1 and %2 (Polish)</source>
        <translation type="obsolete">%1 a %2 (Polsko)</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation type="obsolete">&amp;Vyčistit</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation type="obsolete">&amp;Opakovat</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation type="obsolete">Logo vytvořil %1</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="obsolete">Japonská</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="obsolete">Holandská</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation type="obsolete">&amp;Vždy na vrchu</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="obsolete">Ukrajinská</translation>
    </message>
    <message>
        <source>5&amp;0%</source>
        <translation type="obsolete">5&amp;0%</translation>
    </message>
    <message>
        <source>&amp;100%</source>
        <translation type="obsolete">&amp;100%</translation>
    </message>
    <message>
        <source>1&amp;25%</source>
        <translation type="obsolete">1&amp;25%</translation>
    </message>
    <message>
        <source>15&amp;0%</source>
        <translation type="obsolete">15&amp;0%</translation>
    </message>
    <message>
        <source>1&amp;75%</source>
        <translation type="obsolete">1&amp;75%</translation>
    </message>
    <message>
        <source>&amp;200%</source>
        <translation type="obsolete">&amp;200%</translation>
    </message>
    <message>
        <source>&amp;300%</source>
        <translation type="obsolete">&amp;300%</translation>
    </message>
    <message>
        <source>&amp;400%</source>
        <translation type="obsolete">&amp;400%</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation type="obsolete">&amp;Velikost</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation type="obsolete">&amp;vypnuto</translation>
    </message>
    <message>
        <source>7&amp;5%</source>
        <translation type="obsolete">7&amp;5%</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugalská</translation>
    </message>
</context>
<context>
    <name>GuiBase</name>
    <message>
        <source>-10 minutes</source>
        <translation type="obsolete">- 10 minut</translation>
    </message>
    <message>
        <source>-1 minute</source>
        <translation type="obsolete">-1 minuta</translation>
    </message>
    <message>
        <source>-10 seconds</source>
        <translation type="obsolete">-10 sekund</translation>
    </message>
    <message>
        <source>+10 seconds</source>
        <translation type="obsolete">+10 sekund</translation>
    </message>
    <message>
        <source>+1 minute</source>
        <translation type="obsolete">+1 minuta</translation>
    </message>
    <message>
        <source>+10 minutes</source>
        <translation type="obsolete">+10 minut</translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="obsolete">Přehrát</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pozastavit</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Stop</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Seznam</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="obsolete">Předchozí</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">Další</translation>
    </message>
    <message>
        <source>Fullscreen</source>
        <translation type="obsolete">Celá obrazovka</translation>
    </message>
    <message>
        <source>Mute</source>
        <translation type="obsolete">Ztlumit</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="obsolete">Hlasitost</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Hlavní</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Umístění</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Délka</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Dekodér</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Umělec</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Žánr</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Stopa</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentář</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Informace o klipu</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Rozlišení</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Poměr stran</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formát</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Datový tok</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Snímků za sekundu</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Vybraný kodek</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>Výchozí audio stopa</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Hodnocení</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanály</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Audio stopy</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Identification code</comment>
        <translation type="obsolete">ID</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>prázdný</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation></translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoWindow</name>
    <message>
        <source>General</source>
        <translation type="obsolete">Souhrn</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="obsolete">Umístění</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Velikost</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation type="obsolete">%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="obsolete">URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="obsolete">Délka</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation type="obsolete">Dekodér</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="obsolete">Video</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="obsolete">Rozlišení</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation type="obsolete">Poměr stran</translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="obsolete">Formát</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation type="obsolete">Datový tok</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation type="obsolete">%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation type="obsolete">Snímků za sekundu</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation type="obsolete">Vybraný kodek</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="obsolete">Hodnocení</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation type="obsolete">%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation type="obsolete">Kanály</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Název</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation type="obsolete">Umělec</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="obsolete">Autor</translation>
    </message>
    <message>
        <source>Album</source>
        <translation type="obsolete">Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation type="obsolete">Žánr</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">Datum</translation>
    </message>
    <message>
        <source>Track</source>
        <translation type="obsolete">Stopa</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation type="obsolete">Copyright</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Komentář</translation>
    </message>
    <message>
        <source>Software</source>
        <translation type="obsolete">Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation type="obsolete">Informace o klipu</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Jazyk</translation>
    </message>
    <message>
        <source>empty</source>
        <translation type="obsolete">prázdný</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Titulky</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Identification code</comment>
        <translation type="obsolete">ID</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation type="obsolete">Výchozí audio stopa</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation type="obsolete">Audio stopy</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="obsolete">Typ</translation>
    </message>
</context>
<context>
    <name>InfoWindowBase</name>
    <message>
        <source>SMPlayer - Media Info</source>
        <translation type="obsolete">SMPlayer - Informace o souboru</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="obsolete">&amp;Zavřít</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">Zavřít</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Zvolit adresář</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Přehrát DVD z adresáře</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Můžete spustit DVD z adresáře na disku. Prostě vyberte adresář kterýobsahuje složky VIDEO_TS a AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Zvolit adresář...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Zvolit název pod kterým bude soubor uložen </translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Potvrdit přepsání?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Soubor už existuje.
Chcete jej opravdu přepsat?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Chyba při ukládání souboru</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Log nemohl být uložen</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Okno logu</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Zkopírovat do schránky</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zavřít</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Délka</translation>
    </message>
    <message>
        <source>&amp;Current file</source>
        <translation type="obsolete">&amp;Stávající soubor</translation>
    </message>
    <message>
        <source>&amp;File(s)</source>
        <translation type="obsolete">&amp;Soubor(y)</translation>
    </message>
    <message>
        <source>&amp;Directory</source>
        <translation type="obsolete">&amp;Adresář</translation>
    </message>
    <message>
        <source>&amp;Selected</source>
        <translation type="obsolete">&amp;Vybrané</translation>
    </message>
    <message>
        <source>&amp;All</source>
        <translation type="obsolete">&amp;Všechno</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Přehrát</translation>
    </message>
    <message>
        <source>&amp;Remove selected</source>
        <translation type="obsolete">&amp;Zrušit vybrané</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editace</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Seznamy</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Zvolit soubor</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Zvolit název souboru</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Potvrdit přepsání?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Soubor %1 už existuje.
Opravdu jej chcete přepsat?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všechny soubory</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Výběr jednoho nebo více souborů k otevření</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Zvolit adresář</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Změnit název</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Zadat název  pro tento soubor pod kterým bude zobrazován v seznamu:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Načíst</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Uložit</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Další</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Předchozí</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>&amp;Posunout nahoru</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Po&amp;sunout dolů</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Opakovat</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>Ná&amp;hodně</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Přid&amp;at stávající soubor</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Přida&amp;t soubor(y)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Přidat ad&amp;resář</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Ode&amp;brat vybrané</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Odebrat &amp;vše</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Přidat...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Odebrat...</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Seznam</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Seznam změněn</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Byly provedeny změny, chcete je uložit do seznamu?</translation>
    </message>
</context>
<context>
    <name>PlaylistBase</name>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation type="obsolete">SMPlayer - Seznam</translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="obsolete">Načíst</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Uložit</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="obsolete">Přidat</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="obsolete">Odstranit</translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="obsolete">Přehrát</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="obsolete">Předchozí</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">Následující</translation>
    </message>
    <message>
        <source>Repeat</source>
        <translation type="obsolete">Opakovat</translation>
    </message>
    <message>
        <source>Shuffle</source>
        <translation type="obsolete">Náhodně</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="obsolete">Nahoru</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="obsolete">Dolů</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Hlavní</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Mechaniky</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Výkon</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Titulky</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Rozšířené</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Spustitelné</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Všechny soubory</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Výběr spustitelného souboru MPlayeru</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Výběr adresáře</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>TrueType fonty</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Vybrat TTF soubor</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Krátký skok</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Střední skok</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Dlouhý skok</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Skok kolečkem myši</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Prázdný</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Rozhraní</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Myš a klávesnice</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Zde můžete nastavit adresář do kterého se budou ukládat uložené snímky. Pokud není adresář nastaven, nebude tato funkce povolena.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Výběr výstupního video ovladače. Většinou xv (linux) a directx (windows) poskytují nejvyšší výkon.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Výběr výstupního audio ovladače.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Tuto možnost můžete využít pokud není video equalizér podporován vaší grafickou kartou nebo vybraným výstupním video ovladačem. &lt;br&gt;&lt;b&gt; Poznámka: tato možnost může být nekompatibilní s některýmy výstupními video ovladači.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Tato volba umožní použít softwarový mixer místo mixeru zvukové karty.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Povolení této možnosti bude SMplayer přehrávat všechny soubory od začátku.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Pokud bude tato možnost povolena, všechny videa budou přehrávány v režimu celé obrazovky.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Tato možnost zakáže šetřič obrazovky během přehrávání. &lt;br&gt; Šetřič obrazovky bude znovu povolen po ukončení přehrávání. &lt;br&gt;&lt;b&gt; Poznámka: Toto lze použít pouze v systémech X11 a Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Zde musí být nastaven spustitelný soubor MPlayeru který SMplayer bude používat. &lt;br&gt; SMplayer potřebuje MPlayer alespoň ve verzi 1.0rc1 (doporučeno SVN). &lt;br&gt;&lt;b&gt; Pokud bude tato položka špatně nastavena, SMplayer nebude moct nic přehrát!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Pokud je zatrženo, SMPlayer bude ukládat hlášení MPlayeru (lze vidět v &lt;b&gt; Možnosti -&gt; Zobrazit logy -&gt; mplayer&lt;b&gt;). Vpřípadě problémů log obsahuje důležité informace, takže se doporučuje tuto možnost mít povolenou.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Pokud je zatrženo, SMPlayer bude ukládat zprávy SMPlayeru (lze vidět v &lt;b&gt; Možnosti -&gt; Zobrazit logy -&gt; smplayer&lt;b&gt;). Tyto informace jsou velice použitelné pro vývojáře k nalezení chyb.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Tato možnost povolí filtrování zpráv SMPlayeru které jsou ukládány do logu. Můžete zadat rugulární výraz. Například: &lt;i&gt;^Core::.*&lt;/i&gt; zobrazí pouze řádky začínající  &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logy</translation>
    </message>
    <message>
        <source>&lt;Auto&gt;</source>
        <translation type="obsolete">&lt;Automaticky&gt;</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Poznámka:&lt;/b&gt; tato možnost je pouze pro Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Výchozí</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Nastavení změny priority pro MPlayer pod Windows .&lt;br&gt;&lt;b&gt;VAROVÁNÍ:&lt;/b&gt; Použití priority reálného času může způsobit zablokování systému.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Většinou si SMPlayer pamatuje nastavení pro každý přehrávaný soubor (volba zvukové stopy, hlasitost, filtry...). Zrušením této volby nebude tuto možnost používat.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Zde lze zvolit preferovaný jazyk audio stopy. Pokud je ve videu nalezeno více audio stop, SMPlayer zkusí použít tento jazyk. &lt;br&gt; Toto funguje pouze v případě že je v mediu přístupná informace o jazyce v audio stopě, jako jsou DVD nebo mkv soubory. &lt;br&gt; Toto políčko akceptuje regulární výrazy. Například: &lt;b&gt;es|esp|spa&lt;/b&gt; bude vybírat audio stopu odpovídající  &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Zde lze zvolit preferovaný jazyk titulků. Pokud je ve videu nalezeno více titulků, SMPlayer zkusí použít tento jazyk. &lt;br&gt; Toto funguje pouze v případě že je v mediu přístupná informace o jazyce v titulcích, jako jsou DVD nebo mkv soubory. &lt;br&gt; Toto políčko akceptuje regulární výrazy. Například: &lt;b&gt;es|esp|spa&lt;/b&gt; bude vybírat titulky odpovídající  &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Tento parametr specifikuje kolik paměti (v KBytech) je použito pro přednačtení souboru nebo URL. Použitelní hlavně pro pomalá média.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Přeskočí zobrazování některých snímků potřebných pro A/V synchronizaci na pomalých systémech.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Citlivější vypouštění snímků (dekódování mezer). Způsobuje zkreslení obrazu!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Postupně mění A/V synchronizaci založenou na zpožení velikosti audia.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Dynamické změny úrovně dodatečného zpracování závisející na vytížení procesoru. Číslo udává maximální úroveň která může být použita. Většinou je použito nějaké vysoké číslo.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Česká</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Německá</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Anglická</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Španělská</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francouzská</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Maďarská</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italská</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonská</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Gregoriánská</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandská</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polská</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugalská</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Ruská</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovenská</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukrajinská</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Čínská</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Autodetekce&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulharská</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="unfinished">Turecké</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Nastavení</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Použít</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Hlavní</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Umístění</translation>
    </message>
    <message>
        <source>Select the mplayer executable:</source>
        <translation type="obsolete">Výběr spustitelného souboru MPlayeru:</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Najít...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Vybrat...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Adresář pro ukládání snímků:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Výstupní ovladače</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Audio:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Použít softwarový video equalizér</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Použít softwarové ovládání hlasitosti</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Nastavení médií</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Pamatovat nastavení pro všechny soubory (zvukové stopy, titulky...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Nepamatovat si pozici času (soubory budou přehrávány od začátku)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Spustit videa v režimu celé obrazovky</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Titulky</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Font</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Výběr fontu který bude použit pro titulky (a OSD):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF Font:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Zvolit...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Systémový font:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Automatické měřítko:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Bez automatického měřítka</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proporcionálně k výšce videa</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proporcionálně k šířce videa</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proporcionálně k úhlopříčce videa</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Měřítko:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Automatické načtení</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Automaticky vybrat první možné titulky</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Stejný název jako video soubor</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Všechny titulky obsahující název video souboru</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Všechny titulky v adresáři</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Automaticky načíst titulky (*.srt,*.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Výchozí kódování titulků:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Použít SSA/ASS knihovnu pro renderování titulků</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Barva textu:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Barva pozadí:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Snímky včetně titulků</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Rozšířené</translation>
    </message>
    <message>
        <source>Run mplayer in its own window</source>
        <translation type="obsolete">Spustit MPlayer ve vlastním okně</translation>
    </message>
    <message>
        <source>Additional Options</source>
        <translation type="obsolete">Další možnosti</translation>
    </message>
    <message>
        <source>Here you can pass extra options to mplayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="obsolete">Zde můžete zadat extra parametry pro MPlayer.
Oddělujte je mezerami.
Příklad: -flip -nosound</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Možnosti:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Můžete použít další video filtry.
Oddělujte je čárkou, nepoužívejte mezery.
Příklad: scale=512:-2;eq2=1.1</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Video filtry:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>A nakonec audio filtry. Stejná pravidla jako video filtry.
Příklad: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Audio filtry:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Výkon</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorita:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>Reálný čas</translation>
    </message>
    <message>
        <source>high</source>
        <translation>Vysoká</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>Vyšší</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>Normální</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>Nižší</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>Nízká</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Nastavením vyrovnávací paměti lze zvýšit výkon přehrávání z pomalých médií</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Vyrovnávací paměť:</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Povolit vypuštění snímku</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Povolit tvrdé vypuštění snímku (může vést ke zkreslení obrazu)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Synchronizace</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Automatická synchronizace audia s videem</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Automatická kvalita pro filtr dodatečného zpracování:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Úroveň:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Nejnižší</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Nejvyšší</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Rychlé přepínání audio stop</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Rychlé přeskakování kapitol u DVD</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(vypnutí vyrovnávací paměti, není garantováno že to funguje)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Vypnout spořič obrazovky</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Poměr stran monitoru:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Metoda změny velikosti hlavního okna:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nikdy</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Kdykoli je potřeba</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Pouze při načítání nového videa</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Jedna instance</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Povolit spuštění pouze jedné instance SMPlayeru</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer bude naslouchat na tomto portu a přijímat příkazy z ostatních instancí:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(změny v této skupině se projeví po restartu SMPlayeru)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Styl:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Mechaniky</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>Momentálně SMPlayer neumí automaticky detekovat CD a DVD mechaniky. Pokud budete přehrávat z CD nebo DVD mechaniky, musíte je zde nastavit (mohou být stejné).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>Ikona</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Výběr CD mechaniky:</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Výběr DVD mechaniky:</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Neposledy použité soubory</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Max. počet položek</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Vyčistit seznam</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Přetáčení</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Hlasitost</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Výchozí úroveň hlasitosti:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Myš</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Funkce tlačítek:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Dvojitý klik</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Kliknutí levým tlačítkem</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Velikost okna</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Rozhraní</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Funkce kolečka myši:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Přetáčení médií</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Ovládání hlasitosti</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Myš a klávesnice</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Klávesnice</translation>
    </message>
    <message>
        <source>Coming up soon</source>
        <translation type="obsolete">V přípravě</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Logy</translation>
    </message>
    <message>
        <source>Log mplayer output</source>
        <translation type="obsolete">Log výstupu MPlayeru</translation>
    </message>
    <message>
        <source>Log smplayer output</source>
        <translation type="obsolete">Log výstupu SMPlayeru</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Tato možnost je určena pro ladění aplikace.</translation>
    </message>
    <message>
        <source>Filter for smplayer logs:</source>
        <translation type="obsolete">Filtry pro logy SMPlayeru:</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Jazyk:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Set ikon:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Preferované audio a titulky</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Titulky:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorita</translation>
    </message>
    <message>
        <source>Select the priority for the mplayer process.</source>
        <translation type="obsolete">Výběr priority pro proces mplayer.</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation type="unfinished">Další volby pro MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation type="unfinished">Zde můžete zadat extra parametry pro MPlayer.
Oddělujte je mezerami.
Příklad: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">&amp;Titulky</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Audio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
    <message>
        <source>label</source>
        <translation>označení</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Equalizér</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Jas</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Odstín</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Sytost</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Nastavit jako výchozí hodnoty</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Použít stávající hodnoty jako výchozí pro nové videa.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Nastavit všechny ovládací prvky na nulu.</translation>
    </message>
</context>
</TS>
