<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Interfaţă pentru mplayer</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Fişier de deschis</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Dezvoltator</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Ok</source>
        <translation><byte value="x9"/>Înc&amp;hide</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Versiunea: %1</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Versiunea Qt: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Acest program este un produs de tip &quot;free software&quot;: poate fi redistribuit şi/sau modificat respectând termenii licenţei GNU GPL şi publicată de către fundaţia &apos;Free Software Foundation&quot;; fie versiunea 2 a licenţei fie (la alegere) orice versiune ulterioară.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Traducători:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Germană</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovacă</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiană</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Franceză</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chineză simplificată</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Rusă</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Maghiară</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japoneză</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Olandeză</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Uckraineană</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portughză Braziliană</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiană</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Cehă</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo realizat de %1</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Găsiţi actualizări la: %1</translation>
    </message>
    <message>
        <source>About SMPlayer</source>
        <translation>Despre SMPlayer</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 and %2 (%3)</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Poloneză</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>Compilat cu suport KDE</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgară</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turcă</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Suedeză</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Sârbă</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chineză Tradiţională</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Română</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Portugheză - Brazilia</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Portugheză - Portugalia</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>Nume</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descriere</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Acces rapid</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Salvare</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>Î&amp;ncărcare</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Fişiere taste</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Alegere nume fişier</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirmaţi suprascrierea?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Fişierul %1 există deja.Doriţi sa-l suprascrieţi?</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Alegere fişier</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Eroare</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Fişierul nu aputut fi salvat</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Fişierul nu a putut fi încărcat</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>Jurnal SMPlayer - mplayer</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>Jurnal SMPlayer - smplayer</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Deschide</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>Re&amp;dare</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Subtitrare</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Browse</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>Opţi&amp;uni</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ajutor</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>&amp;Fişier...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>D&amp;irector...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>&amp;Listă_titluri...</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>Citire &amp;DVD din DVDROM</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>Citire D&amp;VD din fişier...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>Ş&amp;terge_lista</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>Fişiere dechise &amp;recent</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>Re&amp;dare</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>&amp;Pauză</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Frecvenţă cadre</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>Viteză &amp;Normală</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>R&amp;elanti</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>Viteză &amp;Dublă</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>Viteză &amp;-10%</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>Viteză &amp;+10%</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>Vit&amp;eză</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Repetare</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Fullscreen</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>Mod &amp;Compact</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Dimensiune</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Autodetectare</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Compact</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9  _C&amp;ompact</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 î&amp;n 16:9</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>Raport &amp;aspect</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>Fă&amp;ră</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Amestec &amp;Liniar</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deîntreţesere</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocesare</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetectare fază</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>Adăugare &amp;zgomot</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>F&amp;iltre</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Egalizor</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>&amp;Captură_ecran</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>&amp;Fixat deasupra</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>C&amp;oloană_sonoră</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtre</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>I&amp;mplicit</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Canale</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>Canal &amp;Stânga</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>Canal &amp;Dreapta</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>Mod &amp;Stereo</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Mute</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Volum &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Volum &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>Întâ&amp;rziere -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>Întâr&amp;ziere +</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Selectare</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>Î&amp;ncărcare...</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>Întârziere &amp;-</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>Întârziere &amp;+</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>&amp;Sus</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>&amp;Jos</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Titlu</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Capitol</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Unghi</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Listă</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>&amp;Arată contor cadre</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Inactivat</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>&amp;Bară căutare</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Durată</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Durată + &amp;Durată totală</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>&amp;Arhivă jurnale</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>P&amp;referinţe</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Despre &amp;Qt</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>Despre &amp;SMPlayer</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;gol&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Liste_titluri</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Toate fişierele</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Alegere fişier</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Informaţii</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Driverele pentru CDROM/DVD nu sunt configurate încă.
O fereastră de dialog va fi afişată pentru a putea face configurarea.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Alegere director</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Subtitrări</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Despre Qt</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>Redare %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pauză</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>De&amp;noise</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormal</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Fin</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Redare / Pauză</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Pauză / Pas cadre</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>Atenţionare - SMPlayer</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>Portul %1 este deja folosit de altă aplicaţie.
Nu se poate porni serverul.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>Serverul de la portul %1 nu răspunde.
Opţiunea pentru o singură sesiune a fost inactivată.</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Înch&amp;ide fereastra</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>Vezi &amp;informaţii şi proprietăţi...</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Resetare</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Deplasare la &amp;stânga</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>Deplasare la &amp;dreapta</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Deplasare în s&amp;us</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Deplasare în &amp;jos</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Linia anterioară a subtitrării</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>&amp;Următoarea linie a subtitrării</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Reducere volum (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Creştere volum (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Eşire mod fullscreen</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Nivel următor</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Reducere contrast</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Creştere contrast</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Reducere strălucire</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Creştere strălucire</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Reducere culoare</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Creştere culoare</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Reducere saturaţie</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Reducere gamma</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Coloana sonoră următoare</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Următoarea subtitrare</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Capitol următor</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Capitol anterior</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Creştere saturaţie</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Creştere gamma</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation>Î&amp;ncărcare fişier extern...</translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normal)</translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (frecvenţă cadre dublă)</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Următorul</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>A&amp;nteriorul</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Normalizare volum</translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation>CD &amp;Audio</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer încă funcţionează de aici</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>A&amp;fişază iconiţă în system tray</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Ascunde</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Restaurare_fereastră</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>Fişiere &amp;recente</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>Î&amp;nchide program</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Luminozitate: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Contrast: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Culoare: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Saturaţie: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Volum: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>Bun venit la SMPlayer</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volum</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Subtitrare</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Listă_Titluri</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Bară_principală  unelte</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>Bară_unelte &amp;limbă</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>B&amp;are_unelte</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Limbi Vest Europene</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Limbi Vest Europene cu Euro</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Limbi Slave/Central Europene</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galiţiană, Malteză, Turcă</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Caractere Vechi Baltice</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Alfabet Chirilic</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabă</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Greacă Modernă</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turcă</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Baltică</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Celtă</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>Alfabet Ebraic</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Rusă</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ucraineană, Belarusă</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Alfabet Chinez Simplificat</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Alfabet Chinez Tradiţional</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Alfabet Japonez</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Alfabet Corean</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Alfabet Tailandez</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Alfabet Chirilic Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Alfabet Slavon/Central European Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>icon</source>
        <translation>Iconiţă</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - fişier proprietăţi</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informaţii</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Selectare demuxer care va fi utilizat pentru acest fişier:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Valori_implicite</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>Codec &amp;video</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Selectare codec video:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>Codec a&amp;udio</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Selectare codec audio:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>Opţiuni &amp;MPlayer</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Opţiuni:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Puteţi introduce filtre video suplimentare
Separaţi-le prin &quot;,&quot;.Nu utilizaţi spaţii!
Exemplu: scale=512:-2,eq=1.1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>Filtre V&amp;ideo:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Şi, în sfârşit, filtrele audio.Se folosesc aceleaşi reguli ca pentru filtrele video.
Exemplu: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>&amp;Filtre audio:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>Î&amp;nchide</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>V&amp;alidare</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Renunţare</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opţiuni suplimentare pentru SMPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Aici se pot adăuga opţiuni suplimentare pentru MPlayer.
Opţiunile trebuie separate prin spaţii.
Exemplu: -flip nosound</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Cale</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensiune</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Durată</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nume</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Artist</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Gen </translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dată</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Coloană sonoră</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Licenţă</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentariu</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Informaţii Clip</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Rezoluţie</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>Raport aspect</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Viteză_transfer</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Cadre pe secundă</translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Codec-ul selectat</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation></translation>
    </message>
    <message>
        <source>Rate</source>
        <translation></translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation></translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation></translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Limbă</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>gol</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Subtitrări</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipul</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>Cod Identificare</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation></translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation></translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Alegere director</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Încarcă DVD dintr-un director</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Puteţi viziona un dvd de pe hard disc.Selectaţi directorul care conţine fişierele VIDEO_TS şi AUDIO_TS.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Alegere director...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>V&amp;alidare</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>R&amp;enunţare</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Alegere nume fişier de salvat</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Se confirmă suprascrierea?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Un fişier cu acelaşi nume există deja.
Se doreşte suprascrierea lui?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Eroare la salvarea fisierului</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Jurnalul nu a putut fi salvat</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Fereastră Jurnal</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salvare</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Copiere pe clipboard</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Închide</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>În&amp;chide</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nume</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Durată</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Redare</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editare</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Liste_Titluri</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Alegere fişier</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Alegere nume fişier</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Confirmaţi suprascrierea?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Fişierul %1 există.
Doriţi suprascrierea?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Toate fişierele</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Selectaţi unul sau mai multe fişiere pentru a le deschide</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Alegere director</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>Editare nume</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Tastaţi numele care va fi afişat în Listă pentru acest fişier:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>Î&amp;ncărcare</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Salvare</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Următorul</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>Ant&amp;eriorul</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>Mutare în s&amp;us</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>Mutare în &amp;jos</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Repetare</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>A&amp;leator</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>Adăugare fişier &amp;curent</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>Adăugare &amp;fişier(e)</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>Adăugare &amp;director</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>Ştergeţi &amp;selecţie</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>Ştergeţi &amp;tot</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Listă _titluri</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Adăugare...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Înlăturare...</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Listă_titluri modificată</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Există modificări nesalvate, doriţi să salvaţi lista?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Reglaje_generale</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Drivere</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Caracteristici</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Subtitrări</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Opţiuni_avansate</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Executabile</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Toate fişierele</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Selectare executabil mplayer</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Selectare director</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Caractere Truetype</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Alegere fişier ttf</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Salt scurt</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Salt mediu</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Salt lung</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Avans rapid din rotiţă</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nimic</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfaţă</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Aici se poate specifica directorul în care vor fi stocate instantaneele de ecran luate cu ajutorul lui smplayer.Dacă acest câmp este lăsat liber atunci opţiunea de salvare va fi dezactivată.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Selectare driver ieşire video.De regulă xv pentru linux şi directx pentru windows oferă cele mai bune rezultate.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Selectare driver ieşire audio.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Se poate selecta această opţiune dacă egalizorul video nu este suportat de placa grafică sau de driverul de ieşire video.&lt;br&gt;&lt;b&gt;Atenţie:&lt;/b&gt; această opţiune poate fi incompatibilă cu unele drivere de ieşire video.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Selectaţi aceasta opţiune pentru a folosi mixerul software, în locul mixerului plăcii de sunet.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Selectarea acestei opţiuni va indica smplayer să redea toate fişierele de la începutul lor.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Selectarea acestei opţiuni va indica redarea fişierelor video în mod fullscreen.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Se selectează această opţiune pentru a dezactiva funcţia sistemului de protejare a monitorului (screensaver).&lt;br&gt;Funcţia va fi reactivată după ce se termină redarea fişierului.&lt;br&gt;,b&gt;Atenţie:&lt;/b&gt;Această opţiune funcţionează numai pentru X11 şi Windows.</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Aici se poate specifica executabilul mplayer pe care îl va folosi smplayer.&lt;br&gt;smplayer necesită cel puţin varianta mplayer 1.0rc1 (recomandare svn).&lt;br&gt;&lt;b&gt;Dacă selecţia este grşită, smplayer nu va putea reda nimic!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Dacă această opţiune este selectată, smplayer va stoca mesajele de depanare furnizate de smplayer (pot fi consultate ulterior în &lt;b&gt;Opţiuni-&gt;Vezi jurnale-&gt;smplayer&lt;/b&gt;).Aceste informaţii pot fi utile dezvoltatorilor în cazul descoperirii unei probleme.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Selectarea acestei opţiuni permite filtrarea mesajelor smplayer care vor fi stocate în jurnal. Aici se pot scrie expresii standard.&lt;br&gt;De exemplu: &lt;i&gt;^Core::.*&lt;/i&gt; va afişa doar liniile care încep cu &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Atenţie:&lt;/b&gt; Această opţiune este valabilă doar pentru Windows.</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Valori implicite</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Selectare priorităţi pentru procesele mplayer în concordanţă cu priorităţile implicite disponibile sub Windows.&lt;br&gt;&lt;b&gt;ATENŢIONARE:&lt;/b&gt;Folosirea priorităţii &quot;în timp real&quot; poate duce la blocarea sistemului.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>În mod normal smplayer va reţine reglajele făcute pentru fiecare fişier redat (coloana sonoră - pista - selectată, nivelul volumului,filtrele aplicate...).Se poate deselecta aici această opţiune dacă nu se doreşte funcţia.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Aici se poate selecta lima preferată pentru coloana sonoră.Când un fişier media cu multiple coloane sonore este găsit, smplayer va încerca să folosească limba preferată.&lt;br&gt;Această funcţie este valabilă doar pentru fişiere media care furnizează informaţii despre coloana sonoră, precum DVD-urile sau fişierele mkv.&lt;br&gt;Acest câmp acceptă expresii obişnuite. Exemplu: &lt;b&gt;es|esp|spa|&lt;/b&gt; va selecta coloana sonoră identificată cu &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; sau &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Aici se poate selecta limba preferată pentru subtitrare.Când este găsit un fişier media ce conţine subtitrări în mai multe limbi, smplayer va încerca să folosească limbă selectată ca preferată.&lt;br&gt;Această opţiune funcţionează doar pentru fişiere media care oferă informaţii despre limba folosită în subtitrare, precum DVD - urile sau fişierele mkv.&lt;br&gt;Acest câmp acceptă expresii standard. Exemplu: &lt;b&gt;es|esp|spa&lt;/b&gt; va avea ca efect selectarea subtitrării identificate cu &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; sau &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Selectarea acestei opţiuni va specifica câtă memorie (în kBytes) se va folosi la pre-încărcarea unui fişier sau URL. Acest lucru se dovedeşte util pentru suporturi media lente.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Se sare peste afişarea unor cadre pentru a menţine sincronizarea A/V pe sisteme lente.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Omiterea mai multor cadre (strică decodarea). Conduce la distorsionarea imaginii!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Ajustare graduală a sincronizării A/V prin măsurarea întârzierii audio.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Modificarea dinamică a nivelului postprocesării funcţie de încărcarea CPU. Numărul specificat  va reprezenta valoarea maximă a nivelului folosit.</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Cehă</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Germană</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Engleză</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Spaniolă</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Franceză</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Maghiară</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiană</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japoneză</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiană</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Olandeză</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Poloneză</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Portugheză Braziliană</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Rusă</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovacă</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraineană</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Chineză Simplificată</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Autodetectare&gt;</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgară</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Selectarea acestei opţiuni va reduce tremurul imaginii, dar, totodată poate produce afişarea incorectă a fişierului video.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turcă</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Greacă</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Finlandeză</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Suedeză</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Această opţiune specifică poziţia subtitrării pe ecran. &lt;i&gt;100&lt;/i&gt; reprezintă partea de jos, în timp ce &lt;i&gt;0&lt;/i&gt; reprezintă partea de sus a ecranului.</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Sârbă</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chineză Tradiţională</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation>Aici se poate shimba stilul pentru subtitrările de tip SSA/ASS. Folosind această bibliotecă se pot face retuşări ale subtitrărilor de tip SUB şi SRT. &lt;br&gt;Exemplu: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation>Tastatură şi mouse</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Română</translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation>Portugheză - Brazilia</translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation>Portugheză - Portugalia</translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Opţiuni_Preferate</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>Î&amp;nchide</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Validare</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Renunţare</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Opţiuni_Generale</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Selectare căi</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Căutare...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Selectare...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Director pentru stocarea instantaneelor:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Drivere ieşire</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Audio:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Folosire egalizor software pentru video</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Folosire control volum prin software</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Reglaje media</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Memorare reglaje pentru toate tipurile de fişiere (coloană sonoră, subtitrare...)</translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Nu se va reţine valoarea contorului de durată (fişierele vor fi redate de la început)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Redare fişier video în mod fullscreen</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Caractere</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Selectarea caracterelor ce vor fi folosite pentru subtitrări (şi OSD):</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>Caractere TTF:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Selectare...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Caractere implicite ale sistemului:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensiune</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Autoscalare:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Fără autoscalare</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Proporţională cu înălţimea filmului</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Proporţională cu lăţimea filmului</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Proporţională cu diagonala filmului</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Dimensiune caracter:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Încărcare automată</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Acelaşi nume ca şi filmul</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Subtitrările care conţin numele filmului</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Toate subtitrările din director</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Încărcare automată fişiere subtitrări (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Codificarea implicită pentru subtitrare:</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Foloseşte biblioteca SSA/ASS pentru randarea subtitrării</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Culoare text:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Culoare chenar:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Include subtitrarea în captura de ecran</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opţiuni:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Puteţi introduce filtre video suplimentare.
Opţiunile se vor separa prin &quot;,&quot; (virgulă).Nu se utilizează spaţii!
Exemplu: scale=512:-2,eq=1.1</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Filtre video:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Filtre audio.Se folosesc aceleaşi reguli ca la filtrele video.
Exemplu: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Filtre audio:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Performanţe</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioritate:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>timp_real</translation>
    </message>
    <message>
        <source>high</source>
        <translation>înaltă</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>peste_normal</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>sub_normal</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>inactiv</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Setarea cache-ului poate îmbunătăţii performanţele pentru fişiere media lente</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Acordă permisiunea programului să renunţe la unele cadre</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Permite programului să renunţe la mai multa cadre (poate duce la imagini distorsionate)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Sincronizare</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Sincronizare automată Audio/Video</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Factor:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Calitatea filtrului automat folosit în postprocesare:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Nivel:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">Inferior</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">Superior</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Comutare rapidă a coloanei sonore</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>Căutare rapidă a capitolelor în dvd</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(cache va fi inactivat şi nu este garantat că acest lucru chiar va funcţiona)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Dezactivare captură ecran</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Aspectul monitorului:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Metoda redimensionării ferestrei principale:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Niciodată</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Oricând este nevoie</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Numai la încăcarea unui fişier video nou</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Sesiune unică</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Foloseşte o singură sesiune pornită pentru SMPlayer</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer va monitoriza acest port pentru a recepţiona comenzi de la alte sesiuni:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(modificările făcute în acest grup necesită repornirea SMPlayer)</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Stil:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Drivere</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>În versiunea actuală SMPlayer nu detectează automat dispozitivele cdrom sau dvd.Pentru a putea reda cdromuri sau dvduri aici se pot selecta driverele pentru cdrom sau dvd (pot fi aceleaşi).</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>Iconiţă</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>Selectare dispozitiv redare CD:</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>Selectare dispozitiv redare DVD:</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Fişiere recente</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>Nr. maxim</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Şterge lista</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Căutare</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volum</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Volum implicit:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Funcţii butoane:</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Dublu clic</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Clic stânga</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Dimensiune fereastră</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfaţă</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Funcţie rotiţă:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Căutare media</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Control volum</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Această opţiune se adresează în principal depanării aplicaţiei.</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Limbă:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>Set iconiţe:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Opţiuni preferate pentru sonor şi subtitrări</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Subtitrări:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritate</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Selectarea executabilului MPlayer:</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>Rulează MPlayer în fereastra proprie</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Opţiuni suplimentare pentru MPlayer</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Aici se pot introduce opţiuni suplimentare pentru MPlayer.
Opţiunile se vor scrie separate de spaţii.
Exemplu: -flip -nosound</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Selectare priorităţi pentru procesele MPlayer.</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>Înscrie în jurnal datele furnizate de MPlayer</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>Înscrie în jurnal datele furnizate de SMPlayer</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>Filtrare date înscrise în jurnalul SMPlayer:</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Fără modificarea culorii fundalului ferestrei video</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Aici se pot modifica tastele pentru acces rapid.Pentru a face acest lucru executaţi clic dublu sau tastaţi peste celula în care se menţionează tipul de acces rapid.Opţional se poate salva lista pentru a o împărtăşi cu prietenii sau pentru folosirea în alt caculator.</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Selectarea primei subtitrări disponibile</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Poziţionare</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Poziţionarea implicită a subtitrării pe ecran</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Cod_Culoare:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Modificare...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Sus</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Jos</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Stil:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation>Foloseşte cache</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Dimensiune:</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation>AC3/DTS direcţionat către S/PDIF</translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation>Sfârşit fişier:</translation>
    </message>
    <message>
        <source>No video:</source>
        <translation>Fără video:</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>&amp;Subtitrări</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation>A se folosi opţiunea -subfont (cerinţă impusă de versiunile recente ale Mplayer)</translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation>Bibliotecă SSA/&amp;ASS</translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation>Noua bibliotecă SSA/ASS va furniza stiluri mai frumoase pentru subtitrări pentru fişiere externe de subtitrări SSA/ASS şi Matroska. Dar va fi folosită de asemenea pentru randarea altor formate precum SUB şi SRT.</translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation>Nivel_&amp;Avansat</translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation>&amp;Jurnale</translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation>Limbă &amp;MPlayer</translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;Romanian&lt;br&gt;(new line)
The drop-down lists may provide already made regular expression for several languages.</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation>&amp;Tastatură</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation>&amp;Mouse</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation>Zoom video</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation>Valoare maximă amplificare:</translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation>Normalizare video</translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Calitatea:</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation>Aici se poate shimba stilul pentru subtitrările de tip SSA/ASS. Folosind această bibliotecă se pot face retuşări ale subtitrărilor de tip SUB şi SRT. Exemplu: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 secundă</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 secunde</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 minute</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 minute şi %2 secunde</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 minut</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 minut şi 1 secundă</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 minut şi %1 secunde</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 minute şi 1 secundă</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation></translation>
    </message>
    <message>
        <source>icon</source>
        <translation>iconiţă</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etichetă</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Egalizor</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Contrast</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Strălucire</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Culoare</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Saturaţie</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Valori_implicite</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Selectează ca valoari implicite</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Folosire valori curente ca valori implicite pentru fişiere video noi.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Selectează butoanele de control la zero.</translation>
    </message>
</context>
</TS>
