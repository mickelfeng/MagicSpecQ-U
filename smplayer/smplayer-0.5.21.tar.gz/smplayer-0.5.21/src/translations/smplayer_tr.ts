<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Front-end for mplayer</source>
        <translation>Mplayer ön yüzü</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Geliştirici</translation>
    </message>
    <message>
        <source>File to open</source>
        <translation>Açılacak dosya</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>About SMPlayer</source>
        <translation>SMPlayer hakkında</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Tamam</translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation>Sürüm: %1</translation>
    </message>
    <message>
        <source>Compiled with KDE support</source>
        <translation>KDE desteği ile derlenmiştir</translation>
    </message>
    <message>
        <source>Qt version: %1</source>
        <translation>Qt sürümü: %1</translation>
    </message>
    <message>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</source>
        <translation>Bu ücretsiz bir yazılımdır; &quot;Free Software Foundation&quot; tarafından yayınlanan GNU lisansının -isteğinize bağlı olarak- 2. veya daha ileriki bir sürümünün koşullarını gözeterek çoğaltabilir ve/veya değiştirebilirsiniz.</translation>
    </message>
    <message>
        <source>Translators:</source>
        <translation>Çevirenler:</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Almanca</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovakça</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>İtalyanca</translation>
    </message>
    <message>
        <source>%1 and %2 (%3)</source>
        <translation>%1 ve %2 (%3)</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Fransızca</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Basitleştirilmiş Çince</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Rusça</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Macarca</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Lehçe</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonca</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Felemenkçe</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukraynaca</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Brezilya Portegizcesi</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Gürcüce</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Çekçe</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgarca</translation>
    </message>
    <message>
        <source>Logo designed by %1</source>
        <translation>Logo %1 tarafından tasarlanmıştır</translation>
    </message>
    <message>
        <source>Get updates at: %1</source>
        <translation>Güncellemeleri edinin: %1</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Türkçe</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>İsveççe</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Tanım</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Kısayol</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Kaydet</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Yükle</translation>
    </message>
    <message>
        <source>Key files</source>
        <translation>Anahtar dosyaları</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Bir dosya ismi seçin</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Üstüne yazmayı onaylıyor musunuz?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>%1 dosyası zaten var. 
Üstüne yazmak istiyor musunuz?</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be saved</source>
        <translation>Dosya kaydedilemedi</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Bir dosya seçin</translation>
    </message>
    <message>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Dosya yüklenemedi</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <source>SMPlayer - Warning</source>
        <translation>SMPlayer - Uyarı</translation>
    </message>
    <message>
        <source>Port %1 is already used by another application.
Cannot start server.</source>
        <translation>%1 bağlantı noktası şu an başka bir uygulama tarafından kullanılıyor.
Sunucu başlatılamadı.</translation>
    </message>
    <message>
        <source>Server at port %1 does not respond.
The single instance option has been disabled.</source>
        <translation>%1 bağlantı noktasındaki sunucu yanıt vermiyor.
Single instance seçeneği geçersiz kılındı.</translation>
    </message>
    <message>
        <source>&amp;File...</source>
        <translation>Dosy&amp;a...</translation>
    </message>
    <message>
        <source>D&amp;irectory...</source>
        <translation>&amp;Klasör...</translation>
    </message>
    <message>
        <source>&amp;Playlist...</source>
        <translation>Oynatma &amp;Listesi...</translation>
    </message>
    <message>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <source>&amp;DVD from drive</source>
        <translation>Sabit diskteki &amp;DVD</translation>
    </message>
    <message>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD&apos;yi klasörden aç...</translation>
    </message>
    <message>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="obsolete">&amp;Çıkış</translation>
    </message>
    <message>
        <source>P&amp;lay</source>
        <translation>&amp;Oynat</translation>
    </message>
    <message>
        <source>&amp;Pause</source>
        <translation>Du&amp;raklat</translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Durdur</translation>
    </message>
    <message>
        <source>&amp;Frame step</source>
        <translation>&amp;Bir kare ilerle</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation>Oynat / Duraklat</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation>Duraklat / Bir kare ilerle</translation>
    </message>
    <message>
        <source>&amp;-10 seconds</source>
        <translation type="obsolete">&amp;-10 saniye</translation>
    </message>
    <message>
        <source>-1 &amp;minute</source>
        <translation type="obsolete">-1 &amp;dakika</translation>
    </message>
    <message>
        <source>-10 mi&amp;nutes</source>
        <translation type="obsolete">-10 da&amp;kika</translation>
    </message>
    <message>
        <source>&amp;+10 seconds</source>
        <translation type="obsolete">&amp;+10 saniye</translation>
    </message>
    <message>
        <source>+1 m&amp;inute</source>
        <translation type="obsolete">+1 dak&amp;ika</translation>
    </message>
    <message>
        <source>+10 min&amp;utes</source>
        <translation type="obsolete">+10 d&amp;akika</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Tekrarla</translation>
    </message>
    <message>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normal Hızda</translation>
    </message>
    <message>
        <source>&amp;Halve speed</source>
        <translation>&amp;Yarı Hızda</translation>
    </message>
    <message>
        <source>&amp;Double speed</source>
        <translation>İki ka&amp;t hızlı</translation>
    </message>
    <message>
        <source>Speed &amp;-10%</source>
        <translation>%10 Yava&amp;şlat</translation>
    </message>
    <message>
        <source>Speed &amp;+10%</source>
        <translation>%10 Hı&amp;zlandır</translation>
    </message>
    <message>
        <source>Sp&amp;eed</source>
        <translation>&amp;Hız</translation>
    </message>
    <message>
        <source>&amp;Fullscreen</source>
        <translation>Tam &amp;ekran</translation>
    </message>
    <message>
        <source>&amp;Compact mode</source>
        <translation>&amp;Büyük ekran</translation>
    </message>
    <message>
        <source>&amp;Equalizer</source>
        <translation>&amp;Eşitleyici</translation>
    </message>
    <message>
        <source>&amp;Screenshot</source>
        <translation>Ekran görüntü&amp;sü</translation>
    </message>
    <message>
        <source>S&amp;tay on top</source>
        <translation>Her zaman &amp;üstte</translation>
    </message>
    <message>
        <source>Zoom &amp;-</source>
        <translation>Uzaklaştır &amp;-</translation>
    </message>
    <message>
        <source>Zoom &amp;+</source>
        <translation>Yakınlaştır &amp;+</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Sıfırla</translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation>Sol&amp;a taşı</translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation>&amp;Sağa taşı</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>&amp;Yukarı taşı</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>&amp;Aşağı taşı</translation>
    </message>
    <message>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocessing</translation>
    </message>
    <message>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetect phase</translation>
    </message>
    <message>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <source>Add n&amp;oise</source>
        <translation>N&amp;oise ekle</translation>
    </message>
    <message>
        <source>F&amp;ilters</source>
        <translation>F&amp;iltreler</translation>
    </message>
    <message>
        <source>&amp;Mute</source>
        <translation>&amp;Sessiz</translation>
    </message>
    <message>
        <source>Volume &amp;-</source>
        <translation>Ses &amp;-</translation>
    </message>
    <message>
        <source>Volume &amp;+</source>
        <translation>Ses &amp;+</translation>
    </message>
    <message>
        <source>&amp;Delay -</source>
        <translation>İler&amp;i al -</translation>
    </message>
    <message>
        <source>D&amp;elay +</source>
        <translation>&amp;Geri al +</translation>
    </message>
    <message>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <source>&amp;Filters</source>
        <translation>&amp;Filtreler</translation>
    </message>
    <message>
        <source>&amp;Load...</source>
        <translation>&amp;Yükle...</translation>
    </message>
    <message>
        <source>U&amp;nload</source>
        <translation>&amp;Kaldır</translation>
    </message>
    <message>
        <source>Delay &amp;-</source>
        <translation>İler&amp;i al -</translation>
    </message>
    <message>
        <source>Delay &amp;+</source>
        <translation>&amp;Geri al +</translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation>Y&amp;ukarı</translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation>A&amp;şağı</translation>
    </message>
    <message>
        <source>&amp;Playlist</source>
        <translation>&amp;Oynatma listesi</translation>
    </message>
    <message>
        <source>View &amp;info and properties...</source>
        <translation>&amp;Bilgi ve özelliklere bak...</translation>
    </message>
    <message>
        <source>&amp;Show frame counter</source>
        <translation>Kare &amp;sayacını göster</translation>
    </message>
    <message>
        <source>P&amp;references</source>
        <translation>&amp;Özellikler</translation>
    </message>
    <message>
        <source>&amp;View logs</source>
        <translation>Kay&amp;ıtlara bak</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>&amp;Qt Hakkında</translation>
    </message>
    <message>
        <source>About &amp;SMPlayer</source>
        <translation>&amp;SMPlayer Hakkında</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Aç</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Oynat</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>V&amp;ideo</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Ses</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation>Alt &amp;yazı</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>&amp;Gezin</translation>
    </message>
    <message>
        <source>Op&amp;tions</source>
        <translation>S&amp;eçenekler</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Yardım</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Son dosyalar</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Temizle</translation>
    </message>
    <message>
        <source>Si&amp;ze</source>
        <translation>&amp;Boyut</translation>
    </message>
    <message>
        <source>&amp;Aspect ratio</source>
        <translation>En/boy or&amp;anı</translation>
    </message>
    <message>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlace</translation>
    </message>
    <message>
        <source>De&amp;noise</source>
        <translation>De&amp;noise</translation>
    </message>
    <message>
        <source>&amp;Pan &amp;&amp; scan</source>
        <translation>&amp;Pan &amp;&amp; scan</translation>
    </message>
    <message>
        <source>&amp;Autodetect</source>
        <translation>&amp;Otomatik</translation>
    </message>
    <message>
        <source>&amp;4:3</source>
        <translation>&amp;4:3</translation>
    </message>
    <message>
        <source>&amp;5:4</source>
        <translation>&amp;5:4</translation>
    </message>
    <message>
        <source>&amp;14:9</source>
        <translation>&amp;14:9</translation>
    </message>
    <message>
        <source>16:&amp;9</source>
        <translation>16:&amp;9</translation>
    </message>
    <message>
        <source>1&amp;6:10</source>
        <translation>1&amp;6:10</translation>
    </message>
    <message>
        <source>&amp;2.35:1</source>
        <translation>&amp;2.35:1</translation>
    </message>
    <message>
        <source>4:3 &amp;Letterbox</source>
        <translation>4:3 &amp;Letterbox</translation>
    </message>
    <message>
        <source>16:9 L&amp;etterbox</source>
        <translation>16:9 L&amp;etterbox</translation>
    </message>
    <message>
        <source>4:3 &amp;Panscan</source>
        <translation>4:3 &amp;Panscan</translation>
    </message>
    <message>
        <source>4:3 &amp;to 16:9</source>
        <translation>4:3 &amp;to 16:9</translation>
    </message>
    <message>
        <source>&amp;None</source>
        <translation>&amp;Hiçbiri</translation>
    </message>
    <message>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <source>&amp;Yadif</source>
        <translation type="obsolete">&amp;Yadif</translation>
    </message>
    <message>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <source>N&amp;ormal</source>
        <translation>N&amp;ormal</translation>
    </message>
    <message>
        <source>&amp;Soft</source>
        <translation>&amp;Hafif</translation>
    </message>
    <message>
        <source>&amp;Track</source>
        <translation>&amp;İz</translation>
    </message>
    <message>
        <source>&amp;Channels</source>
        <translation>&amp;Kanallar</translation>
    </message>
    <message>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Stereo mode</translation>
    </message>
    <message>
        <source>&amp;Default</source>
        <translation>&amp;Varsayılan</translation>
    </message>
    <message>
        <source>&amp;Stereo</source>
        <translation>&amp;Steryo</translation>
    </message>
    <message>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <source>&amp;Left channel</source>
        <translation>&amp;Sol kanal</translation>
    </message>
    <message>
        <source>&amp;Right channel</source>
        <translation>&amp;Sağ kanal</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Seç</translation>
    </message>
    <message>
        <source>&amp;Title</source>
        <translation>&amp;Başlık</translation>
    </message>
    <message>
        <source>&amp;Chapter</source>
        <translation>&amp;Bölüm</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Açı</translation>
    </message>
    <message>
        <source>&amp;OSD</source>
        <translation>&amp;OSD</translation>
    </message>
    <message>
        <source>&amp;Disabled</source>
        <translation>&amp;Devredışı</translation>
    </message>
    <message>
        <source>&amp;Seek bar</source>
        <translation>G&amp;ezinme çubuğu</translation>
    </message>
    <message>
        <source>&amp;Time</source>
        <translation>&amp;Süre</translation>
    </message>
    <message>
        <source>Time + T&amp;otal time</source>
        <translation>Süre + T&amp;oplam süre</translation>
    </message>
    <message>
        <source>SMPlayer - mplayer log</source>
        <translation>SMPlayer - mplayer kaydı</translation>
    </message>
    <message>
        <source>SMPlayer - smplayer log</source>
        <translation>SMPlayer - smplayer kaydı</translation>
    </message>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;boş&gt;</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Ses</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Oynatma listesi</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tüm dosyalar</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Bir dosya seçin</translation>
    </message>
    <message>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Bilgi</translation>
    </message>
    <message>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM / DVD cihazları henüz yapılandırılmadı.
Tamama bastığınızda ayarları yapabileceğiniz ekran açılacak.</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Bir klasör seçin</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Alt yazılar</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Qt Hakkında</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation>%1&apos;i oynatıyor</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Duraklat</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Durdur</translation>
    </message>
    <message>
        <source>&amp;Previous line in subtitles</source>
        <translation>Bir &amp;önceki satır</translation>
    </message>
    <message>
        <source>N&amp;ext line in subtitles</source>
        <translation>Bir &amp;sonraki satır</translation>
    </message>
    <message>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <source>Dec volume (2)</source>
        <translation>Sesi kıs (2)</translation>
    </message>
    <message>
        <source>Inc volume (2)</source>
        <translation>Sesi yükselt (2)</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation>Tam ekrandan çık</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation>OSD - Sonraki seviye</translation>
    </message>
    <message>
        <source>Dec contrast</source>
        <translation>Zıtlığı azalt</translation>
    </message>
    <message>
        <source>Inc contrast</source>
        <translation>Zıtlığı arttır</translation>
    </message>
    <message>
        <source>Dec brightness</source>
        <translation>Parlaklığı azalt</translation>
    </message>
    <message>
        <source>Inc brightness</source>
        <translation>Barlaklığı arttır</translation>
    </message>
    <message>
        <source>Dec hue</source>
        <translation>Renk tonunu azalt</translation>
    </message>
    <message>
        <source>Inc hue</source>
        <translation>Renk tonunu arttır</translation>
    </message>
    <message>
        <source>Dec saturation</source>
        <translation>Doygunluğu azalt</translation>
    </message>
    <message>
        <source>Dec gamma</source>
        <translation>Gamayı azalt</translation>
    </message>
    <message>
        <source>Next audio</source>
        <translation>Bir sonraki ses</translation>
    </message>
    <message>
        <source>Next subtitle</source>
        <translation>Bir sonraki alt yazı</translation>
    </message>
    <message>
        <source>Next chapter</source>
        <translation>Bir sonraki bölüm</translation>
    </message>
    <message>
        <source>Previous chapter</source>
        <translation>Bir önceki bölüm</translation>
    </message>
    <message>
        <source>Inc saturation</source>
        <translation>Doygunluğu arttır</translation>
    </message>
    <message>
        <source>Inc gamma</source>
        <translation>Gamayı arttır</translation>
    </message>
    <message>
        <source>Toggle double size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Kerndeint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yadif (normal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y&amp;adif (double framerate)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation type="unfinished">&amp;Sonraki</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished">&amp;Önceki</translation>
    </message>
    <message>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio CD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer zaten çalışıyor</translation>
    </message>
    <message>
        <source>S&amp;how icon in system tray</source>
        <translation>İkonu system tray&apos;de &amp;göster</translation>
    </message>
    <message>
        <source>&amp;Recent files</source>
        <translation>&amp;Son açılan dosyalar</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Gizle</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>Ge&amp;ri yükle</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">&amp;Çıkış</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <source>Brightness: %1</source>
        <translation>Parlaklık: %1</translation>
    </message>
    <message>
        <source>Contrast: %1</source>
        <translation>Zıtlık: %1</translation>
    </message>
    <message>
        <source>Gamma: %1</source>
        <translation>Gama: %1</translation>
    </message>
    <message>
        <source>Hue: %1</source>
        <translation>Renk tonu: %1</translation>
    </message>
    <message>
        <source>Saturation: %1</source>
        <translation>Doygunluk: %1</translation>
    </message>
    <message>
        <source>Volume: %1</source>
        <translation>Ses: %1</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation>Yakınlık: %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to SMPlayer</source>
        <translation>SMPlayer&apos;a Hoş Geldiniz</translation>
    </message>
    <message>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Ana araç çubuğu</translation>
    </message>
    <message>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Dil araç çubuğu</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Araç çubukları</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Ses</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Ses</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Alt yazı</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Oynatma listesi</translation>
    </message>
</context>
<context>
    <name>Encodings</name>
    <message>
        <source>Western European Languages</source>
        <translation>Batı Avrupa Dilleri</translation>
    </message>
    <message>
        <source>Western European Languages with Euro</source>
        <translation>Batı Avrupa Dilleri (€ içeren)</translation>
    </message>
    <message>
        <source>Slavic/Central European Languages</source>
        <translation>Slav/Orta Avrupa Dilleri</translation>
    </message>
    <message>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galiçyaca, Maltaca, Türkçe</translation>
    </message>
    <message>
        <source>Old Baltic charset</source>
        <translation>Eski Baltık Alfabesi</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Kiril Alfabesi</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arapça</translation>
    </message>
    <message>
        <source>Modern Greek</source>
        <translation>Çağdaş Yunanca</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Türkçe</translation>
    </message>
    <message>
        <source>Baltic</source>
        <translation>Baltık Alfabesi</translation>
    </message>
    <message>
        <source>Celtic</source>
        <translation>Keltçe</translation>
    </message>
    <message>
        <source>Hebrew charsets</source>
        <translation>İbranice</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Rusça</translation>
    </message>
    <message>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukraynaca, Beyaz Rusça</translation>
    </message>
    <message>
        <source>Simplified Chinese charset</source>
        <translation>Basitleştirilmiş Çin Alfabesi</translation>
    </message>
    <message>
        <source>Traditional Chinese charset</source>
        <translation>Geleneksel Çin Alfabesi</translation>
    </message>
    <message>
        <source>Japanese charsets</source>
        <translation>Japon Alfabesi</translation>
    </message>
    <message>
        <source>Korean charset</source>
        <translation>Kore Alfabesi</translation>
    </message>
    <message>
        <source>Thai charset</source>
        <translation>Tay Alfabesi</translation>
    </message>
    <message>
        <source>Cyrillic Windows</source>
        <translation>Kiril Alfabesi Windows</translation>
    </message>
    <message>
        <source>Slavic/Central European Windows</source>
        <translation>Slav/Orta Avrupa Windows</translation>
    </message>
</context>
<context>
    <name>EqSliderBase</name>
    <message>
        <source>EqSlider</source>
        <translation>EqSlider</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialogBase</name>
    <message>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Dosya özellikleri</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Bilgi</translation>
    </message>
    <message>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>Bu do&amp;sya için kullanılacak demuxer&apos;ı seçin:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Sıfırla</translation>
    </message>
    <message>
        <source>&amp;Video codec</source>
        <translation>&amp;Video kodlayıcı</translation>
    </message>
    <message>
        <source>&amp;Select the video codec:</source>
        <translation>Video kodlayıcısını &amp;seçin:</translation>
    </message>
    <message>
        <source>A&amp;udio codec</source>
        <translation>&amp;Ses kodlayıcısı</translation>
    </message>
    <message>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Ses kodlayıcısını seçin:</translation>
    </message>
    <message>
        <source>&amp;MPlayer options</source>
        <translation>&amp;MPlayer seçenekleri</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>Mplayer için İlave Seçenekler</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Burada mplayer&apos;a fazladan özellikler ekleyebilirsiniz.
Özellikler arasında boşluk bırakmayı unutmayın.
Örnek: -flip -nosound</translation>
    </message>
    <message>
        <source>&amp;Options:</source>
        <translation>&amp;Seçenekler:</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>İlave video filtreleri de ekleyebilirsiniz.
Filtreleri &quot;,&quot; ile ayırın. Boşluk kullanmayın!
Örnek: scale=512:-2,eq2=1</translation>
    </message>
    <message>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideo filtreleri:</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Ve son olarak ses filtreleri. Video filtrelerinde geçerli olan kurallar burada da geçerli.
Örnek: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Audio &amp;filters:</source>
        <translation>Ses &amp;filtreleri:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Tamam</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Uygula</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Vazgeç</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <source>General</source>
        <translation>Genel</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Yol</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Boyut</translation>
    </message>
    <message>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Süre</translation>
    </message>
    <message>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation>Oyuncu</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Yazar</translation>
    </message>
    <message>
        <source>Album</source>
        <translation>Albüm</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Tür</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Tarih</translation>
    </message>
    <message>
        <source>Track</source>
        <translation>Parça</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Telif Hakkı</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Yorum</translation>
    </message>
    <message>
        <source>Software</source>
        <translation>Yazılım</translation>
    </message>
    <message>
        <source>Clip info</source>
        <translation>Parça hakkında bilgi</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Çözünürlük</translation>
    </message>
    <message>
        <source>Aspect ratio</source>
        <translation>En/Boy Oranı</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Biçim</translation>
    </message>
    <message>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <source>%1 kbps</source>
        <translation>Saniyede %1 kb</translation>
    </message>
    <message>
        <source>Frames per second</source>
        <translation>Kare/saniye </translation>
    </message>
    <message>
        <source>Selected codec</source>
        <translation>Seçilen kodlayıcı</translation>
    </message>
    <message>
        <source>Initial Audio Stream</source>
        <translation>İlk Ses Akımı</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation>Oran</translation>
    </message>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Kanallar</translation>
    </message>
    <message>
        <source>Audio Streams</source>
        <translation>Ses Akımları</translation>
    </message>
    <message>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Dil</translation>
    </message>
    <message>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>boş</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Alt yazılar</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tür</translation>
    </message>
    <message>
        <source>Stream title</source>
        <translation>Yayının başlığı</translation>
    </message>
    <message>
        <source>Stream URL</source>
        <translation>Yayının URL&apos;si</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <source>Choose a directory</source>
        <translation>Bir klasör seçin</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectoryBase</name>
    <message>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Sabit diskteki DVD&apos;yi oynat</translation>
    </message>
    <message>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Sabit diskinizde bulunan bir DVD&apos;yi oynatabilirsiniz. VIDEO_TS ve AUDIO_TS klasörlerini içeren klasörü seçmeniz yeterli.</translation>
    </message>
    <message>
        <source>Choose a directory...</source>
        <translation>Bir klasör seçin...</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Tamam</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Vazgeç</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <source>Choose a filename to save under</source>
        <translation>Kayıt dosyası için bir isim seçin</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Üstüne yazmayı onaylıyor musunuz?</translation>
    </message>
    <message>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Dosya zaten var.
Üstüne yazmak istiyor musunuz?</translation>
    </message>
    <message>
        <source>Error saving file</source>
        <translation>Dosyayı kaydederken hata oluştu</translation>
    </message>
    <message>
        <source>The log couldn&apos;t be saved</source>
        <translation>Kayıt bilgisi kaydedilemedi</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <source>Log Window</source>
        <translation>Kayıt Penceresi</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Kaydet</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation>Panoya kopyala</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Süre</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>&amp;Oynat</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Düzelt</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Oynatma Listeleri</translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation>Bir dosya seçin</translation>
    </message>
    <message>
        <source>Choose a filename</source>
        <translation>Bir dosya ismi seçin</translation>
    </message>
    <message>
        <source>Confirm overwrite?</source>
        <translation>Üstüne yazmayı onaylıyor musunuz?</translation>
    </message>
    <message>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>%1 dosyası zaten var. 
Üstüne yazmak istiyor musunuz?</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tüm dosyalar</translation>
    </message>
    <message>
        <source>Select one or more files to open</source>
        <translation>Açmak üzere bir veya daha fazla dosya seçin</translation>
    </message>
    <message>
        <source>Choose a directory</source>
        <translation>Bir klasör seçin</translation>
    </message>
    <message>
        <source>Edit name</source>
        <translation>İsmi değiştirin</translation>
    </message>
    <message>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Bu dosyanın oynatma listesinde gösterileceği ismi yazın:</translation>
    </message>
    <message>
        <source>&amp;Load</source>
        <translation>&amp;Yükle</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Kaydet</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Sonraki</translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation>&amp;Önceki</translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation>&amp;Yukarı taşı</translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation>&amp;Aşağı taşı</translation>
    </message>
    <message>
        <source>&amp;Repeat</source>
        <translation>&amp;Tekrarla</translation>
    </message>
    <message>
        <source>S&amp;huffle</source>
        <translation>&amp;Karışık</translation>
    </message>
    <message>
        <source>Add &amp;current file</source>
        <translation>&amp;Hâlihazır dosyayı ekle</translation>
    </message>
    <message>
        <source>Add &amp;file(s)</source>
        <translation>&amp;Dosya(ları) ekle</translation>
    </message>
    <message>
        <source>Add &amp;directory</source>
        <translation>&amp;Klasör ekle</translation>
    </message>
    <message>
        <source>Remove &amp;selected</source>
        <translation>&amp;Seçileni kaldır</translation>
    </message>
    <message>
        <source>Remove &amp;all</source>
        <translation>&amp;Hepsini kaldır</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Ekle...</translation>
    </message>
    <message>
        <source>Remove...</source>
        <translation>Kaldır...</translation>
    </message>
    <message>
        <source>SMPlayer - Playlist</source>
        <translation>SMPlayer - Oynatma listesi</translation>
    </message>
    <message>
        <source>Playlist modified</source>
        <translation>Oynatma listesi değiştirildi</translation>
    </message>
    <message>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Kaydedilmemiş değişiklikler var. Oynatma listesini kaydetmek ister misiniz?</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>General</source>
        <translation>Genel</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Sürücüler</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Başarım</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation>Alt Yazı</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Gelişmiş</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation>Çalıştırılabilirler</translation>
    </message>
    <message>
        <source>All files</source>
        <translation>Tüm dosyalar</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation>Çalıştırılabilir mplayer dosyasını seçin</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation>Bir klasör seçin</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation>Truetype Fontlar</translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation>Bir ttf dosyası seçin</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgarca</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Çekçe</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Almanca</translation>
    </message>
    <message>
        <source>English</source>
        <translation>İngilizce</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>İspanyolca</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Fransızca</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Macarca</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>İtalyanca</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonca</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Gürcüce</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Felemenkçe</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Lehçe</translation>
    </message>
    <message>
        <source>Brazilian Portuguese</source>
        <translation type="obsolete">Brezilya Portegizcesi</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Rusça</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovakça</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukraynaca</translation>
    </message>
    <message>
        <source>Simplified-Chinese</source>
        <translation>Basitleştirilmiş Çince</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Otomatik&gt;</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Arayüz</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Fare ve klavye</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Kayıtlar</translation>
    </message>
    <message>
        <source>Short jump</source>
        <translation>Kısa</translation>
    </message>
    <message>
        <source>Medium jump</source>
        <translation>Orta</translation>
    </message>
    <message>
        <source>Long jump</source>
        <translation>Uzun</translation>
    </message>
    <message>
        <source>Mouse wheel jump</source>
        <translation>Fare tekeriyle</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Hiçbiri</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Geçerli</translation>
    </message>
    <message>
        <source>Here you must specify the mplayer executable that smplayer will use.&lt;br&gt;smplayer requires at least mplayer 1.0rc1 (svn recommended).&lt;br&gt;&lt;b&gt;If this setting is wrong, smplayer won&apos;t be able to play anything!&lt;/b&gt;</source>
        <translation>Burada smplayer&apos;ın kullanacağı çalıştırılabilir mplayer dosyasını seçmelisiniz.&lt;br&gt;smplayer en azından mplayer 1.0rc1&apos;e gerek duymaktadır (svn tavsiye edilir).&lt;br&gt;&lt;b&gt;Eğer bu ayar yanlışsa, smplayer hiçbir dosyayı çalıştıramaz!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Here you can specify a folder where the screenshots taken by smplayer will be stored. If this field is empty the screenshot feature will be disabled.</source>
        <translation>Burada yakaladığınız ekran görüntülerinin tutulacağı klasörü belirleyebilirsiniz. Eğer bir klasör seçmezseniz görüntü yakalama özelliği devredışı bırakılacak.</translation>
    </message>
    <message>
        <source>Select the video output driver. Usually xv (linux) and directx (windows) provide the best performance.</source>
        <translation>Video çıktısı için sürücü seçin. Genellikle xv (linux) ve directx (windows) en iyi başarımı sağlayacaklardır.</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation>Ses çıktısı içim sürücü seçin.</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Eğer video eşitleyici özelliği ekran kartınız veya seçtiğiniz video çıktısı sürücüsü tarafından desteklenmiyorsa bu seçeneği işaretleyin.&lt;br&gt;&lt;b&gt;Not:&lt;/b&gt; Bu seçenek bazı video çıktısı sürücüleri ile uyumsuzluk gösterebilir.</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Eğer ses kartı tabanlı değil yazılım tabanlı mixer kullanıyorsanız bu seçeneği işaretleyin.</translation>
    </message>
    <message>
        <source>Usually smplayer will remember the settings for each file you play (audio track selected, volume, filters...). Uncheck this option if you don&apos;t like this feature.</source>
        <translation>Smplayer çoğu dosya için belirlediğiniz ayarları (seçilen ses izi, ses, filtreler...) hatırlayacaktır. Eğer bu özelliği istemiyorsanız işareti kaldırın.</translation>
    </message>
    <message>
        <source>If you check this option, smplayer will play all files from the beginning.</source>
        <translation>Bu seçeneği işaretlerseniz, dosyalar son kaldıkları yerden değil en baştan itibaren oynatılacak.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Bu seçeneği işaretlerseniz, videolar tam ekran kipinde açılacak.</translation>
    </message>
    <message>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option works only in X11 and Windows.</source>
        <translation>Herhangi bir dosya oynatılırken ekran koruyucuyu devredışı bırakmak için bu seçeneği işaretleyin.&lt;br&gt;Oynatma işlemi bittiğinde ekran koruyucu tekrar çalıştırılacak.&lt;br&gt;&lt;b&gt;Not:&lt;/b&gt; Bu seçenek sadece X11 ve Windows&apos;ta çalışır.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Burada ses akımları için tercih ettiğiniz dili seçebilirsiniz. Birden fazla ses akımı içeren bir ortam bulunduğunda, smplayer tercih edilen dildekini kullanmaya çalışacaktır.&lt;br&gt;Bu özellik sadece ses akımlarının dili hakkında bilgi içeren, DVDler, mkv dosyaları gibi ortamlar için geçerlidir.&lt;br&gt;Diller için alışılagelmiş kısaltmaları kullanabilirsiniz. Örnek: &lt;b&gt;es|esp|spa&lt;/b&gt; yazdığınızda smplayer mümkünse &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; veya &lt;i&gt;spa&lt;/i&gt; içeren ses izlerini kullanacaktır.</translation>
    </message>
    <message>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, smplayer will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Burada alt yazılar için tercih ettiğiniz dili seçebilirsiniz. Birden fazla alt yazı içeren bir ortam bulunduğunda, smplayer tercih edilen dildekini kullanmaya çalışacaktır.&lt;br&gt;Bu özellik sadece alt yazıların dili hakkında bilgi içeren, DVDler, mkv dosyaları gibi ortamlar için geçerlidir.&lt;br&gt;Diller için alışılagelmiş kısaltmaları kullanabilirsiniz. Örnek: &lt;b&gt;es|esp|spa&lt;/b&gt; yazdığınızda smplayer mümkünse &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; veya &lt;i&gt;spa&lt;/i&gt; içeren alt yazıları kullanacaktır.</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;WARNING:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Windows&apos;da öntanımlı önceliklere göre Mplayer için geçerli olacak işlem önceliğini seçin.
&lt;br&gt;&lt;b&gt;Uyarı:&lt;b&gt; Gerçek zamanlı öncelik sisteminizin kitlenmesine yol açabilir.</translation>
    </message>
    <message>
        <source>&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; This option is for Windows only.</source>
        <translation>&lt;br&gt;&lt;b&gt;Not:&lt;/b&gt;Bu seçenek sadece Windows için geçerlidir.</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file or URL. Especially useful on slow media.</source>
        <translation>Bu seçenek bir dosya veya URL önbelleğe atılırken ne kadar bellek (kByte) kullanılacağını belirler. Özellikle yavaş çalışan ortamlar için seçilmelidir.</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Yavaş sistemlerde ses/görüntü uyumunu sağlamak için bazı kareleri atla.</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Daha yoğun kare es geçme. Görüntünün bozulmasına yol açar!</translation>
    </message>
    <message>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Ses gecikmesi hesaplamalarına dayanarak, ses/görüntü uyumunu aşama aşama gerçekleştir.</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Atıl işlemci gücüne bağlı olarak önişlem seviyesini değiştir. Belirlediğiniz sayı en yüksek seviye kabul edilecektir. Genellikle büyük bir sayı seçebilirsiniz.</translation>
    </message>
    <message>
        <source>If checked, smplayer will store the output of mplayer (you can see it in &lt;b&gt;Options-&gt;View logs-&gt;mplayer&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Bu seçeneği işaretlerseniz, smplayer mplayer&apos;ın çıktısını kaydedecek (kayıta &lt;b&gt;Seçenekler-&gt;Kayıtlara bak-&gt;mplayer&lt;/b&gt;&apos;dan bakabilirsiniz). Bir sorunla karşılaştığınızda kayıtlardaki bilgiler işinize yarayabilir. Bu yüzden seçeneğin işaretli olması tavsiye edilir.</translation>
    </message>
    <message>
        <source>If this option is checked, smplayer will store the debugging messages that smplayer outputs (you can see the log in &lt;b&gt;Options-&gt;View logs-&gt;smplayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Bu seçeneği işaretlerseniz, smplayer debugging mesajlarını kaydedecek (kayıta &lt;b&gt;Seçenekler-&gt;Kayıtlara bak-&gt;smplayer&lt;/b&gt;&apos;dan bakabilirsiniz). Bu kayıttaki bilgiler bir bug bulmanız halinde smplayer&apos;ı geliştirenlerin işine yarayacaktır.</translation>
    </message>
    <message>
        <source>This option allows to filter the smplayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Bu seçenek kaydedilecek smplayer mesajlarının filtrelenmesini sağlar. &lt;br&gt;Örnek: &lt;i&gt;^Core::.*&lt;/i&gt; sadece &lt;i&gt;Core::&lt;/i&gt; ile başlayan satırları gösterecektir</translation>
    </message>
    <message>
        <source>Checking this option may reduce flickering, but it also might produce that the video won&apos;t be displayed properly.</source>
        <translation>Bu seçeneği işaretlemek görüntüdeki titremeyi azaltabilir, fakat videonun bozuk görüntülenmesine de yol açabilir.</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Türkçe</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Yunanca</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Fince</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>İsveççe</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation>Bu seçenek alt yazıların ekranda bulunacağı yeri belirlemenizi sağlar. En alt için &lt;i&gt;100&lt;/i&gt; , en üst için &lt;i&gt;0&lt;/i&gt;&apos;ı seçin.</translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine tunning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="obsolete">Burada SSA/ASS alt yazılarının stillerini geçersiz kılabilirsiniz. Ayrıca SSA/ASS kütüphanesi aracılığıyla srt ve sub türü alt yazıların nasıl taranacağını belirleyebilirsiniz. &lt;br&gt;Örnek: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of srt and sub subtitles by the SSA/ASS library.&lt;br&gt;Example: &lt;b&gt;Bold=1,Outline=2,Shadow=2&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Brazil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese - Portugal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialogBase</name>
    <message>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Özellikler</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Genel</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Yollar</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Ara...</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Seç...</translation>
    </message>
    <message>
        <source>Folder for storing screenshots:</source>
        <translation>Yakalanan ekran görüntülerinin tutulacağı klasör:</translation>
    </message>
    <message>
        <source>Output drivers</source>
        <translation>Çıktı sürücüleri</translation>
    </message>
    <message>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <source>Audio:</source>
        <translation>Ses:</translation>
    </message>
    <message>
        <source>Use software video equalizer</source>
        <translation>Yazılım tabanlı video eşitleyici kullan</translation>
    </message>
    <message>
        <source>Use software volume control</source>
        <translation>Yazılım tabanlı ses eşitleyici kullan</translation>
    </message>
    <message>
        <source>Media settings</source>
        <translation>Ortam ayarları</translation>
    </message>
    <message>
        <source>Remember settings for all files (audio track, subtitles...)</source>
        <translation>Tüm dosyalar için ayarları hatırla (alt yazılar, ses izi...) </translation>
    </message>
    <message>
        <source>Don&apos;t remember time position (files start playing from the beginning)</source>
        <translation>Konumu hatırlama (dosyaları oynatmaya son kaldıkları yerden değil sıfırdan başlar)</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation>Videoları tam ekran başlat</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Alt yazılar</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Font</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation>Alt yazılar (ve OSD) için kullanılacak fontu seçin:</translation>
    </message>
    <message>
        <source>TTF font:</source>
        <translation>TTF fontu:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Seçin...</translation>
    </message>
    <message>
        <source>System font:</source>
        <translation>Sistem fontu:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Boyut</translation>
    </message>
    <message>
        <source>Autoscale:</source>
        <translation>Orantılama:</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation>Orantılama yok</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation>Filmin yüksekliğiyle orantılı</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation>Filmin genişliğiyle orantılı</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation>Filmin köşegen uzunluğuyla orantılı</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Orantı:</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation>Otomatik yükle</translation>
    </message>
    <message>
        <source>Automatically select first available subtitle</source>
        <translation type="obsolete">Seçeneğe uyan ilk alt yazıyı kendiliğinden seç</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation>Film ismiyle aynı isimde</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation>Filmin ismini içeren tüm alt yazılar</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation>Klasördeki tüm alt yazılar</translation>
    </message>
    <message>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation>Alt yazıları kendiliğinden yükle (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Default subtitle encoding:</source>
        <translation>Geçerli alt yazı kodlaması:</translation>
    </message>
    <message>
        <source>SSA/ASS</source>
        <translation type="obsolete">SSA/ASS</translation>
    </message>
    <message>
        <source>Use SSA/ASS library for subtitle rendering</source>
        <translation>Alt yazı dönüştürmesi için SSA/ASS kütüphanesini kullan</translation>
    </message>
    <message>
        <source>Text color:</source>
        <translation>Yazı rengi:</translation>
    </message>
    <message>
        <source>Border color:</source>
        <translation>Çerçeve rengi:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="obsolete">Gelişmiş</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Seçenekler:</translation>
    </message>
    <message>
        <source>Video filters:</source>
        <translation>Video filtreleri:</translation>
    </message>
    <message>
        <source>Audio filters:</source>
        <translation>Ses filtreleri:</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Başarım</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Öncelik:</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation>gerçek zamanlı</translation>
    </message>
    <message>
        <source>high</source>
        <translation>yüksek</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation>normal üstü</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation>normal altı</translation>
    </message>
    <message>
        <source>idle</source>
        <translation>âtıl</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Kaşe belleği kullanmak başarımı arttırabilir</translation>
    </message>
    <message>
        <source>Cache:</source>
        <translation type="obsolete">Kaşe belleği:</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation>Frame drop&apos;a izin ver</translation>
    </message>
    <message>
        <source>Allow hard frame drop (can lead to image distortion)</source>
        <translation>Hard frame drop&apos;a izin ver (görüntünün bozulmasına yol açabilir)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Uyum</translation>
    </message>
    <message>
        <source>Audio/video auto synchronization</source>
        <translation>Otomatik ses/görüntü uyumu</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Çarpan:</translation>
    </message>
    <message>
        <source>Auto quality for postprocessing filter:</source>
        <translation type="obsolete">Postprocessing filtresinin kalitesi:</translation>
    </message>
    <message>
        <source>Level:</source>
        <translation type="obsolete">Seviye:</translation>
    </message>
    <message>
        <source>Lowest</source>
        <translation type="obsolete">En düşük</translation>
    </message>
    <message>
        <source>Highest</source>
        <translation type="obsolete">En yüksek</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation>Ses izini hızlı değiştirebilme</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation>DVD bölümlerini hızlı gezinebilme</translation>
    </message>
    <message>
        <source>(cache will be disabled and it&apos;s not guaranteed that it really works)</source>
        <translation>(bellek kaşesi devredışı bırakılacak. çalışıp çalışmayacağı kesin değildir)</translation>
    </message>
    <message>
        <source>Disable screensaver</source>
        <translation>Ekran koruyucuyu devredışı bırak</translation>
    </message>
    <message>
        <source>Monitor aspect:</source>
        <translation>Ekran en/boy oranı:</translation>
    </message>
    <message>
        <source>Main window resize method:</source>
        <translation>Ana pencere boyutlandırma yöntemi:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Asla</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation>Gerektiğinde</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation>Sadece yeni bir video yüklendiğinde</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Stil:</translation>
    </message>
    <message>
        <source>Drives</source>
        <translation>Sürücüler</translation>
    </message>
    <message>
        <source>Select your DVD device:</source>
        <translation>DVD çalarınızı seçin:</translation>
    </message>
    <message>
        <source>Select your CD device:</source>
        <translation>CD çalarınızı seçin:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Tamam</translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation>&amp;Uygula</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Vazgeç</translation>
    </message>
    <message>
        <source>Select the MPlayer executable:</source>
        <translation>Çalıştırılabilir mplayer dosyasını seçin:</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation>Tercih edilen ses ve alt yazılar</translation>
    </message>
    <message>
        <source>Subtitles:</source>
        <translation>Alt yazılar:</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation>Alt yazılar yakalanan ekranlarda gözüksün</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
    <message>
        <source>Run MPlayer in its own window</source>
        <translation>MPlayer kendi penceresinde çalıştır</translation>
    </message>
    <message>
        <source>Additional Options for MPlayer</source>
        <translation>MPlayer için Ek Seçenekler</translation>
    </message>
    <message>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Burada mplayer&apos;a fazladan özellikler ekleyebilirsiniz.
Özellikler arasında boşluk bırakmayı unutmayın.
Örnek: -flip -nosound</translation>
    </message>
    <message>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>İlave video filtreleri de ekleyebilirsiniz.
Filtreleri &quot;,&quot; ile ayırın. Boşluk kullanmayın!
Örnek: scale=512:-2,eq2=1</translation>
    </message>
    <message>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Ve son olarak ses filtreleri. Video filtrelerinde geçerli olan kurallar burada da geçerli.
Örnek: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <source>Don&apos;t repaint the background of the video window</source>
        <translation>Video penceresinin arka planını yeniden oluşturma</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Öncelik</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation>Mplayer için geçerli olacak önceliği seçin.</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Arayüz</translation>
    </message>
    <message>
        <source>Seeking</source>
        <translation>Gezinme</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Ses</translation>
    </message>
    <message>
        <source>Default volume:</source>
        <translation>Geçerli ses:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Window size</source>
        <translation>Pencere boyutu</translation>
    </message>
    <message>
        <source>Single instance</source>
        <translation>Tek durum</translation>
    </message>
    <message>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Smplayer için sadece bir durum kullan</translation>
    </message>
    <message>
        <source>SMPlayer will listen to this port to receive commands from other instances:</source>
        <translation>SMPlayer diğer durumlardan komut almak için bu bağlantı noktasını dinleyecek:</translation>
    </message>
    <message>
        <source>(changes in this group require SMPlayer to be restarted)</source>
        <translation>(bu grupta değişiklik yaparsanız SMPlayer&apos;ı yeniden başlatmanız gerekmektedir)</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation>Son dosyalar</translation>
    </message>
    <message>
        <source>Max. items</source>
        <translation>En fazla</translation>
    </message>
    <message>
        <source>Clear list</source>
        <translation>Listeyi temizle</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Dil:</translation>
    </message>
    <message>
        <source>Icon set:</source>
        <translation>İkon seti:</translation>
    </message>
    <message>
        <source>Currently SMPlayer does not autodetect cdrom or dvd devices. So in order to play cdroms or dvds you must first select here your cdrom and dvd drives (can be the same).</source>
        <translation>SMPlayer CDROM ve DVD cihazlarınızı henüz otomatik olarak bulamamaktadır. CD veya DVD&apos;lerinizi oynatabilmek için önce buradan bir cihaz seçmeniz gerekmektedir (ikisi için aynı cihaz olabilir).</translation>
    </message>
    <message>
        <source>Mouse and keyboard</source>
        <translation type="obsolete">Fare ve klavye</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Fare</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation>Buton özellikleri:</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation>Sol tık</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation>Sağ tık</translation>
    </message>
    <message>
        <source>Wheel function:</source>
        <translation>Tekerin görevi:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation>Gezinme</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation>Ses kontrolü</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Klavye</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Burada, değiştirmek istediğiniz kısayola çift tıklayarak veya üzerine gelip yazmaya başlayarak, tüm kısayolları değiştirebilirsiniz. Ayrıca, hazırladığınız listeyi kaydedip insanlarla paylaşabilir veya başka bir bilgisayarda kullanabilirsiniz.</translation>
    </message>
    <message>
        <source>Logs</source>
        <translation type="obsolete">Kayıtlar</translation>
    </message>
    <message>
        <source>Log MPlayer output</source>
        <translation>MPlayer çıktısının kaydını tut</translation>
    </message>
    <message>
        <source>Log SMPlayer output</source>
        <translation>SMPlayer çıktısının kaydını tut</translation>
    </message>
    <message>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Bu seçenek esas olarak debugging amaçlıdır.</translation>
    </message>
    <message>
        <source>Filter for SMPlayer logs:</source>
        <translation>SMPlayer kayıtlarını filtrele:</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation>Seçeneğe uyan ilk yazıyı kendiliğinden seç</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Konum</translation>
    </message>
    <message>
        <source>Default position of the subtitles on screen</source>
        <translation>Alt yazıların konumu</translation>
    </message>
    <message>
        <source>Colorkey:</source>
        <translation>Anahtar renk:</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation>Değiştir...</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>En üst</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>En alt</translation>
    </message>
    <message>
        <source>Styles:</source>
        <translation>Stiller:</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="unfinished">Alt &amp;yazı</translation>
    </message>
    <message>
        <source>Use -subfont option (required by recent MPlayer releases)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSA/&amp;ASS library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new SSA/ASS library will provide nice styled subtitles for external SSA/ASS subtitles files and Matroska tracks. But it will be used too for rendering other formats like SUB and SRT files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;MPlayer language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer needs to read and parse the output of MPlayer and sometimes it relies on English text. If you are using a MPlayer translated into another language, then you need to change the texts that SMPlayer looks for. (Technically you should enter regular expressions)&lt;br&gt;&lt;br&gt;
The drop-down lists may provide already made regular expression for several languages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished">Video</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished">Ses</translation>
    </message>
    <message>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable postprocessing for all videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can override styles for SSA/ASS subtitles. It can be also used for fine-tuning the rendering of SRT and SUB subtitles by the SSA/ASS library. Example: &lt;b&gt;Bold=1,Outline=2,Shadow=4&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>1 second</source>
        <translation>1 saniye</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 saniye</translation>
    </message>
    <message>
        <source>1 minute</source>
        <translation>1 dakika</translation>
    </message>
    <message>
        <source>1 minute and 1 second</source>
        <translation>1 dakika ve 1 saniye</translation>
    </message>
    <message>
        <source>1 minute and %1 seconds</source>
        <translation>1 dakika ve %1 saniye</translation>
    </message>
    <message>
        <source>%1 minutes</source>
        <translation>%1 dakika</translation>
    </message>
    <message>
        <source>%1 minutes and 1 second</source>
        <translation>%1 dakika ve 1 saniye</translation>
    </message>
    <message>
        <source>%1 minutes and %2 seconds</source>
        <translation>%1 dakika ve %2 saniye</translation>
    </message>
</context>
<context>
    <name>SeekWidgetBase</name>
    <message>
        <source>SeekWidgetBase</source>
        <translation>SeekWidgetBase</translation>
    </message>
    <message>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etiket</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <source>Equalizer</source>
        <translation>Eşitleyici</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Zıtlık</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Parlaklık</translation>
    </message>
    <message>
        <source>Hue</source>
        <translation>Renk tonu</translation>
    </message>
    <message>
        <source>Saturation</source>
        <translation>Doygunluk</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gama</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Sıfırla</translation>
    </message>
    <message>
        <source>&amp;Set as default values</source>
        <translation>&amp;Varsayılan yap</translation>
    </message>
    <message>
        <source>Use the current values as default values for new videos.</source>
        <translation>Bu değerleri tüm yeni videolar için kullan.</translation>
    </message>
    <message>
        <source>Set all controls to zero.</source>
        <translation>Tüm kontrolleri sıfırla.</translation>
    </message>
</context>
</TS>
