#! /bin/sh
yes a | qt3to4 smplayer.pro
qmake
