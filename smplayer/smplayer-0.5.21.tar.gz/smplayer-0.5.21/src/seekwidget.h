
#ifndef _SEEKWIDGET_H_
#define _SEEKWIDGET_H_

#include "seekwidgetbase.h"
#include <qpixmap.h>
#include <qstring.h>

class SeekWidget : public SeekWidgetBase
{
    Q_OBJECT
	Q_PROPERTY(QPixmap icon READ icon WRITE setIcon)
	Q_PROPERTY(QString label READ label WRITE setLabel)
	Q_PROPERTY(int time READ time WRITE setTime)

public:
    SeekWidget( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~SeekWidget();

	int time() const;
	const QPixmap * icon() const;
	QString label() const;

public slots:
	void setIcon(QPixmap icon);
	void setLabel(QString text);
	void setTime(int secs);

protected slots:
	virtual void languageChange();
};


#endif
