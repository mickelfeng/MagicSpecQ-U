
#include "mytable.h"

MyTable::MyTable( QWidget * parent, const char * name )
	: QTable(parent, name) 
{
	size_hint = QSize(0,0);
}

MyTable::MyTable(int numRows, int numCols, QWidget * parent, const char * name)
	: QTable(numRows, numCols, parent, name)
{
	size_hint = QSize(0,0);
}

void MyTable::setSizeHint(QSize s) {
	size_hint = s;
}

QSize MyTable::sizeHint() const {
	if (size_hint == QSize(0,0))
		return QTable::sizeHint();
	else
		return size_hint;
}

