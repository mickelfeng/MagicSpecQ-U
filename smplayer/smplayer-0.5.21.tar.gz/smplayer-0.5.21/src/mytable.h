
#ifndef _MYTABLE_H_
#define _MYTABLE_H_

#include <qtable.h>
#include <qsize.h>

class MyTable : public QTable
{
public:
	MyTable( QWidget * parent = 0, const char * name = 0 );
	MyTable( int numRows, int numCols, QWidget * parent = 0, const char * name = 0 );

	void setSizeHint( QSize s );
	virtual QSize sizeHint () const;

private:
	QSize size_hint;
};


#endif

